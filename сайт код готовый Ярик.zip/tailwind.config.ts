import type { Config } from 'tailwindcss';

export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        gray: {
          900: '#000000',
          800: '#1a1a1a',
          700: '#2d2d2d',
        },
      },
    },
  },
  plugins: [],
} satisfies Config;
