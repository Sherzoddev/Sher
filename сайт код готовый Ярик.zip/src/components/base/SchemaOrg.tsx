import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

const SITE_URL = import.meta.env.VITE_SITE_URL || 'https://example.com';

interface SchemaOrgProps {
  type?: 'home' | 'catalog' | 'portfolio' | 'product' | 'contact' | 'faq' | 'calculator';
}

export const SchemaOrg = ({ type = 'home' }: SchemaOrgProps) => {
  const location = useLocation();

  useEffect(() => {
    // Remove existing schema
    const existingSchemas = document.querySelectorAll('script[type="application/ld+json"]');
    existingSchemas.forEach(schema => schema.remove());

    const schemas: any[] = [];

    // Organization schema (for all pages)
    const organizationSchema = {
      '@context': 'https://schema.org',
      '@type': 'Organization',
      name: 'Baths&Home Module',
      url: SITE_URL,
      logo: `${SITE_URL}/logo.png`,
      description: 'Производство и продажа модульных бань и домов под ключ',
      address: {
        '@type': 'PostalAddress',
        addressCountry: 'RU'
      },
      contactPoint: {
        '@type': 'ContactPoint',
        contactType: 'customer service',
        availableLanguage: 'Russian'
      }
    };

    switch (type) {
      case 'home':
        schemas.push({
          '@context': 'https://schema.org',
          '@type': 'WebSite',
          name: 'Baths&Home Module',
          url: SITE_URL,
          description: 'Производство и продажа модульных бань и домов под ключ. Быстрое строительство за 2-4 недели, высокое качество, доступные цены.',
          publisher: organizationSchema
        });
        
        // Add FAQPage schema for home page
        schemas.push({
          '@context': 'https://schema.org',
          '@type': 'FAQPage',
          mainEntity: [
            {
              '@type': 'Question',
              name: 'Сколько времени занимает строительство модульной бани?',
              acceptedAnswer: {
                '@type': 'Answer',
                text: 'Строительство модульной бани занимает от 2 до 4 недель в зависимости от размера и комплектации.'
              }
            },
            {
              '@type': 'Question',
              name: 'Какая гарантия на модульные бани?',
              acceptedAnswer: {
                '@type': 'Answer',
                text: 'Мы предоставляем гарантию 5 лет на все модульные бани и дома.'
              }
            },
            {
              '@type': 'Question',
              name: 'Можно ли использовать модульную баню круглый год?',
              acceptedAnswer: {
                '@type': 'Answer',
                text: 'Да, наши модульные бани утеплены и предназначены для круглогодичного использования.'
              }
            }
          ]
        });
        break;

      case 'catalog':
        schemas.push({
          '@context': 'https://schema.org',
          '@type': 'CollectionPage',
          name: 'Каталог модульных бань и домов',
          url: `${SITE_URL}${location.pathname}`,
          description: 'Полный каталог модульных бань и домов. Одномодульные и двухмодульные бани, модульные дома, гриль-зоны.',
          publisher: organizationSchema
        });
        break;

      case 'portfolio':
        schemas.push({
          '@context': 'https://schema.org',
          '@type': 'CollectionPage',
          name: 'Портфолио готовых проектов',
          url: `${SITE_URL}${location.pathname}`,
          description: 'Наши реализованные проекты модульных бань и домов. Фото готовых объектов, отзывы клиентов.',
          publisher: organizationSchema
        });
        break;

      case 'product':
        schemas.push({
          '@context': 'https://schema.org',
          '@type': 'Product',
          name: 'Модульная баня',
          description: 'Модульная баня под ключ с быстрой установкой',
          brand: {
            '@type': 'Brand',
            name: 'Baths&Home Module'
          },
          offers: {
            '@type': 'AggregateOffer',
            priceCurrency: 'RUB',
            lowPrice: '300000',
            highPrice: '2000000',
            availability: 'https://schema.org/InStock'
          }
        });
        break;

      case 'contact':
        schemas.push({
          '@context': 'https://schema.org',
          '@type': 'ContactPage',
          name: 'Контакты',
          url: `${SITE_URL}${location.pathname}`,
          description: 'Свяжитесь с нами для консультации и заказа модульной бани или дома',
          publisher: organizationSchema
        });
        break;

      case 'calculator':
        schemas.push({
          '@context': 'https://schema.org',
          '@type': 'WebApplication',
          name: 'Калькулятор стоимости модульной бани',
          url: `${SITE_URL}${location.pathname}`,
          description: 'Рассчитайте стоимость модульной бани или дома онлайн. Выберите тип строения, площадь, комплектацию и получите точную цену.',
          applicationCategory: 'UtilityApplication',
          operatingSystem: 'Any',
          offers: {
            '@type': 'Offer',
            price: '0',
            priceCurrency: 'RUB'
          }
        });
        break;

      case 'faq':
        schemas.push({
          '@context': 'https://schema.org',
          '@type': 'FAQPage',
          mainEntity: [
            {
              '@type': 'Question',
              name: 'Сколько времени занимает строительство модульной бани?',
              acceptedAnswer: {
                '@type': 'Answer',
                text: 'Строительство модульной бани занимает от 2 до 4 недель в зависимости от размера и комплектации.'
              }
            },
            {
              '@type': 'Question',
              name: 'Какая гарантия на модульные бани?',
              acceptedAnswer: {
                '@type': 'Answer',
                text: 'Мы предоставляем гарантию 5 лет на все модульные бани и дома.'
              }
            },
            {
              '@type': 'Question',
              name: 'Можно ли использовать модульную баню круглый год?',
              acceptedAnswer: {
                '@type': 'Answer',
                text: 'Да, наши модульные бани утеплены и предназначены для круглогодичного использования.'
              }
            }
          ]
        });
        break;
    }

    // Add all schemas to the page
    schemas.forEach(schema => {
      const script = document.createElement('script');
      script.type = 'application/ld+json';
      script.text = JSON.stringify(schema);
      document.head.appendChild(script);
    });
  }, [location.pathname, type]);

  return null;
};
