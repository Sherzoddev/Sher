import React, { useState, useEffect } from 'react';

const WhatsAppCatalogPopup: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isClosing, setIsClosing] = useState(false);

  useEffect(() => {
    console.log('WhatsAppCatalogPopup mounted');
    
    // Проверяем, показывали ли окно в этой сессии
    const hasSeenPopup = sessionStorage.getItem('whatsappPopupSeen');
    console.log('hasSeenPopup:', hasSeenPopup);
    
    if (!hasSeenPopup) {
      // Показываем окно через 3 секунды (уменьшил для быстрой проверки)
      const timer = setTimeout(() => {
        console.log('Showing popup');
        setIsVisible(true);
      }, 3000);

      return () => clearTimeout(timer);
    }
  }, []);

  const handleClose = () => {
    setIsClosing(true);
    setTimeout(() => {
      setIsVisible(false);
      sessionStorage.setItem('whatsappPopupSeen', 'true');
    }, 300);
  };

  const handleWhatsAppClick = () => {
    window.open(
      'https://api.whatsapp.com/send/?phone=79115098818&text=Здравствуйте!+Хочу+получить+каталог+проектов&type=phone_number&app_absent=0',
      '_blank'
    );
    handleClose();
  };

  if (!isVisible) return null;

  return (
    <div 
      className={`fixed inset-0 bg-black/50 flex items-center justify-center p-4 transition-opacity duration-300 ${
        isClosing ? 'opacity-0' : 'opacity-100'
      }`}
      style={{ zIndex: 99999 }}
    >
      <div 
        className={`bg-white rounded-2xl max-w-md w-full p-8 relative shadow-2xl transition-all duration-300 ${
          isClosing ? 'scale-90 opacity-0' : 'scale-100 opacity-100'
        }`}
      >
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors cursor-pointer w-8 h-8 flex items-center justify-center"
          aria-label="Закрыть"
        >
          <i className="ri-close-line text-2xl"></i>
        </button>

        <div className="text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="ri-whatsapp-fill text-green-600 text-5xl"></i>
          </div>

          <h2 className="text-2xl font-bold text-gray-900 mb-3">
            Получите каталог проектов
          </h2>
          
          <p className="text-gray-600 mb-6">
            Отправим полный каталог наших модульных домов и бань с ценами прямо в WhatsApp
          </p>

          <button
            onClick={handleWhatsAppClick}
            className="w-full bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-xl font-semibold transition-all transform hover:scale-105 flex items-center justify-center gap-3 cursor-pointer whitespace-nowrap mb-3"
          >
            <i className="ri-whatsapp-fill text-2xl"></i>
            Получить каталог в WhatsApp
          </button>

          <button
            onClick={handleClose}
            className="text-gray-500 hover:text-gray-700 text-sm transition-colors cursor-pointer whitespace-nowrap"
          >
            Нет, спасибо
          </button>
        </div>
      </div>
    </div>
  );
};

export default WhatsAppCatalogPopup;
