import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { getPageSEO } from '../../utils/seoData';

export const SEOHead = () => {
  const location = useLocation();

  useEffect(() => {
    const seo = getPageSEO(location.pathname);
    
    // Update title
    document.title = seo.title;
    
    // Update meta tags
    const updateMetaTag = (name: string, content: string, isProperty = false) => {
      const attribute = isProperty ? 'property' : 'name';
      let element = document.querySelector(`meta[${attribute}="${name}"]`);
      
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attribute, name);
        document.head.appendChild(element);
      }
      
      element.setAttribute('content', content);
    };
    
    updateMetaTag('description', seo.description);
    updateMetaTag('keywords', seo.keywords);
    
    // Update canonical
    let canonical = document.querySelector('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      document.head.appendChild(canonical);
    }
    canonical.setAttribute('href', seo.canonical);
    
    // Update Open Graph tags
    updateMetaTag('og:title', seo.title, true);
    updateMetaTag('og:description', seo.description, true);
    updateMetaTag('og:url', seo.canonical, true);
    
    // Update Twitter tags
    updateMetaTag('twitter:title', seo.title, true);
    updateMetaTag('twitter:description', seo.description, true);
    updateMetaTag('twitter:url', seo.canonical, true);
    
    // Update last-modified
    const today = new Date().toISOString().split('T')[0];
    updateMetaTag('last-modified', today);
  }, [location.pathname]);

  return null;
};
