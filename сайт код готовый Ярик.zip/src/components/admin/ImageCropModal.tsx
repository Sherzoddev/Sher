import React, { useState, useRef } from 'react';
import ReactCrop, { Crop, PixelCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';

interface ImageCropModalProps {
  imageUrl: string;
  onSave: (croppedImageUrl: string) => void;
  onClose: () => void;
}

const ImageCropModal: React.FC<ImageCropModalProps> = ({ imageUrl, onSave, onClose }) => {
  const [crop, setCrop] = useState<Crop>({
    unit: '%',
    width: 90,
    height: 90,
    x: 5,
    y: 5,
  });
  const [completedCrop, setCompletedCrop] = useState<PixelCrop | null>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const [processing, setProcessing] = useState(false);

  const getCroppedImg = async (): Promise<string> => {
    if (!imgRef.current) {
      return imageUrl;
    }

    const image = imgRef.current;
    const canvas = document.createElement('canvas');
    
    // Используем полный размер оригинального изображения
    canvas.width = image.naturalWidth;
    canvas.height = image.naturalHeight;
    const ctx = canvas.getContext('2d');

    if (!ctx) {
      return imageUrl;
    }

    // Рисуем полное изображение без обрезки
    ctx.drawImage(
      image,
      0,
      0,
      image.naturalWidth,
      image.naturalHeight,
      0,
      0,
      image.naturalWidth,
      image.naturalHeight
    );

    return canvas.toDataURL('image/jpeg', 0.95);
  };

  const handleSave = async () => {
    setProcessing(true);
    try {
      const croppedImageUrl = await getCroppedImg();
      onSave(croppedImageUrl);
    } catch (error) {
      console.error('Error cropping image:', error);
      alert('Ошибка при обрезке изображения');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/90 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        <div className="p-6 border-b border-gray-200 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-slate-900">Предварительный просмотр</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center cursor-pointer hover:bg-gray-100 rounded-full transition-colors"
          >
            <i className="ri-close-line text-xl text-gray-500"></i>
          </button>
        </div>

        <div className="flex-1 overflow-auto p-6 flex items-center justify-center bg-gray-50">
          <img
            ref={imgRef}
            src={imageUrl}
            alt="Preview"
            className="max-w-full max-h-[60vh] object-contain"
            crossOrigin="anonymous"
          />
        </div>

        <div className="p-6 border-t border-gray-200 flex gap-3">
          <button
            onClick={handleSave}
            disabled={processing}
            className="flex-1 bg-slate-900 hover:bg-slate-800 text-white py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {processing ? (
              <>
                <i className="ri-loader-4-line animate-spin mr-2"></i>
                Обработка...
              </>
            ) : (
              <>
                <i className="ri-check-line mr-2"></i>
                Сохранить
              </>
            )}
          </button>
          <button
            onClick={onClose}
            disabled={processing}
            className="px-6 border-2 border-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap disabled:opacity-50"
          >
            Отмена
          </button>
        </div>
      </div>
    </div>
  );
};

export default ImageCropModal;
