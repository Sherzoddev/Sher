import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import MultiImageUploader from './MultiImageUploader';

const supabaseUrl = import.meta.env.VITE_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseAnonKey);

interface PortfolioItem {
  id: number;
  title: string;
  category: string;
  images: string[];
  order_index: number;
  is_active: boolean;
  created_at: string;
}

const PortfolioPhotosManager: React.FC = () => {
  const [items, setItems] = useState<PortfolioItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingItem, setEditingItem] = useState<PortfolioItem | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    category: '',
    images: [] as string[],
  });

  useEffect(() => {
    loadItems();
  }, []);

  const loadItems = async () => {
    try {
      const { data, error } = await supabase
        .from('portfolio_items')
        .select('*')
        .order('order_index', { ascending: true });

      if (error) throw error;
      setItems(data || []);
    } catch (error) {
      console.error('Ошибка загрузки портфолио:', error);
      alert('Ошибка загрузки данных');
    } finally {
      setLoading(false);
    }
  };

  const handleAdd = async () => {
    if (!formData.title.trim() || !formData.category.trim() || formData.images.length === 0) {
      alert('Заполните все поля и добавьте хотя бы одно изображение');
      return;
    }

    try {
      const maxOrder = items.length > 0 ? Math.max(...items.map(i => i.order_index)) : 0;

      const { error } = await supabase
        .from('portfolio_items')
        .insert({
          title: formData.title,
          category: formData.category,
          images: formData.images,
          order_index: maxOrder + 1,
          is_active: true,
        });

      if (error) throw error;

      alert('Проект успешно добавлен!');
      setShowAddModal(false);
      setFormData({ title: '', category: '', images: [] });
      loadItems();
    } catch (error) {
      console.error('Ошибка добавления:', error);
      alert('Ошибка при добавлении проекта');
    }
  };

  const handleUpdate = async () => {
    if (!editingItem) return;

    if (!formData.title.trim() || !formData.category.trim() || formData.images.length === 0) {
      alert('Заполните все поля и добавьте хотя бы одно изображение');
      return;
    }

    try {
      const { error } = await supabase
        .from('portfolio_items')
        .update({
          title: formData.title,
          category: formData.category,
          images: formData.images,
        })
        .eq('id', editingItem.id);

      if (error) throw error;

      alert('Проект успешно обновлён!');
      setEditingItem(null);
      setFormData({ title: '', category: '', images: [] });
      loadItems();
    } catch (error) {
      console.error('Ошибка обновления:', error);
      alert('Ошибка при обновлении проекта');
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Вы уверены, что хотите удалить этот проект?')) return;

    try {
      const { error } = await supabase
        .from('portfolio_items')
        .delete()
        .eq('id', id);

      if (error) throw error;

      alert('Проект удалён!');
      loadItems();
    } catch (error) {
      console.error('Ошибка удаления:', error);
      alert('Ошибка при удалении проекта');
    }
  };

  const handleToggleActive = async (item: PortfolioItem) => {
    try {
      const { error } = await supabase
        .from('portfolio_items')
        .update({ is_active: !item.is_active })
        .eq('id', item.id);

      if (error) throw error;
      loadItems();
    } catch (error) {
      console.error('Ошибка изменения статуса:', error);
      alert('Ошибка при изменении статуса');
    }
  };

  const handleMoveUp = async (item: PortfolioItem, index: number) => {
    if (index === 0) return;

    const prevItem = items[index - 1];
    try {
      await supabase
        .from('portfolio_items')
        .update({ order_index: prevItem.order_index })
        .eq('id', item.id);

      await supabase
        .from('portfolio_items')
        .update({ order_index: item.order_index })
        .eq('id', prevItem.id);

      loadItems();
    } catch (error) {
      console.error('Ошибка перемещения:', error);
    }
  };

  const handleMoveDown = async (item: PortfolioItem, index: number) => {
    if (index === items.length - 1) return;

    const nextItem = items[index + 1];
    try {
      await supabase
        .from('portfolio_items')
        .update({ order_index: nextItem.order_index })
        .eq('id', item.id);

      await supabase
        .from('portfolio_items')
        .update({ order_index: item.order_index })
        .eq('id', nextItem.id);

      loadItems();
    } catch (error) {
      console.error('Ошибка перемещения:', error);
    }
  };

  const openEditModal = (item: PortfolioItem) => {
    setEditingItem(item);
    setFormData({
      title: item.title,
      category: item.category,
      images: item.images,
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-12 h-12 border-4 border-slate-900 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-slate-900">Портфолио (фотографии)</h2>
        <button
          onClick={() => setShowAddModal(true)}
          className="px-6 py-3 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap"
        >
          <i className="ri-add-line mr-2"></i>
          Добавить проект
        </button>
      </div>

      <div className="grid gap-4">
        {items.map((item, index) => (
          <div
            key={item.id}
            className={`bg-white rounded-xl border-2 p-6 ${
              item.is_active ? 'border-gray-200' : 'border-red-200 bg-red-50'
            }`}
          >
            <div className="flex gap-6">
              <div className="flex-shrink-0">
                {item.images.length > 0 ? (
                  <img
                    src={item.images[0]}
                    alt={item.title}
                    className="w-32 h-32 object-contain bg-gray-100 rounded-lg"
                  />
                ) : (
                  <div className="w-32 h-32 bg-gray-100 rounded-lg flex items-center justify-center">
                    <i className="ri-image-line text-4xl text-gray-400"></i>
                  </div>
                )}
              </div>

              <div className="flex-1">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h3 className="text-xl font-bold text-slate-900 mb-1">{item.title}</h3>
                    <p className="text-sm text-gray-600">
                      <i className="ri-folder-line mr-1"></i>
                      {item.category}
                    </p>
                    <p className="text-sm text-gray-500 mt-1">
                      <i className="ri-image-line mr-1"></i>
                      {item.images.length} {item.images.length === 1 ? 'фото' : 'фотографий'}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleMoveUp(item, index)}
                      disabled={index === 0}
                      className="w-8 h-8 flex items-center justify-center cursor-pointer hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                      title="Переместить вверх"
                    >
                      <i className="ri-arrow-up-line text-lg"></i>
                    </button>
                    <button
                      onClick={() => handleMoveDown(item, index)}
                      disabled={index === items.length - 1}
                      className="w-8 h-8 flex items-center justify-center cursor-pointer hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                      title="Переместить вниз"
                    >
                      <i className="ri-arrow-down-line text-lg"></i>
                    </button>
                  </div>
                </div>

                <div className="flex gap-2 mt-4">
                  <button
                    onClick={() => handleToggleActive(item)}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap ${
                      item.is_active
                        ? 'bg-green-100 text-green-700 hover:bg-green-200'
                        : 'bg-red-100 text-red-700 hover:bg-red-200'
                    }`}
                  >
                    <i className={`${item.is_active ? 'ri-eye-line' : 'ri-eye-off-line'} mr-1`}></i>
                    {item.is_active ? 'Активен' : 'Скрыт'}
                  </button>
                  <button
                    onClick={() => openEditModal(item)}
                    className="px-4 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-edit-line mr-1"></i>
                    Редактировать
                  </button>
                  <button
                    onClick={() => handleDelete(item.id)}
                    className="px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-delete-bin-line mr-1"></i>
                    Удалить
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}

        {items.length === 0 && (
          <div className="text-center py-12 bg-gray-50 rounded-xl">
            <i className="ri-gallery-line text-6xl text-gray-300 mb-4"></i>
            <p className="text-gray-500">Нет проектов в портфолио</p>
          </div>
        )}
      </div>

      {(showAddModal || editingItem) && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200 flex justify-between items-center sticky top-0 bg-white">
              <h3 className="text-2xl font-bold text-slate-900">
                {editingItem ? 'Редактировать проект' : 'Добавить проект'}
              </h3>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setEditingItem(null);
                  setFormData({ title: '', category: '', images: [] });
                }}
                className="w-8 h-8 flex items-center justify-center cursor-pointer hover:bg-gray-100 rounded-full transition-colors"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>

            <div className="p-6 space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Название проекта
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                  placeholder="Например: Баня 6x6"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Категория
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent cursor-pointer"
                >
                  <option value="">Выберите категорию</option>
                  <option value="Модульные дома">Модульные дома</option>
                  <option value="Каркасные дома">Каркасные дома</option>
                  <option value="Модульные бани">Модульные бани</option>
                  <option value="Гриль-дома">Гриль-дома</option>
                  <option value="Беседки">Беседки</option>
                  <option value="Хозпостройки">Хозпостройки</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Фотографии проекта
                </label>
                <MultiImageUploader
                  images={formData.images}
                  onChange={(images) => setFormData({ ...formData, images })}
                />
              </div>
            </div>

            <div className="p-6 border-t border-gray-200 flex gap-3">
              <button
                onClick={editingItem ? handleUpdate : handleAdd}
                className="flex-1 bg-slate-900 text-white py-3 rounded-lg font-semibold hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-check-line mr-2"></i>
                {editingItem ? 'Сохранить изменения' : 'Добавить проект'}
              </button>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setEditingItem(null);
                  setFormData({ title: '', category: '', images: [] });
                }}
                className="px-6 border-2 border-gray-300 text-gray-700 py-3 rounded-lg font-semibold hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap"
              >
                Отмена
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PortfolioPhotosManager;
