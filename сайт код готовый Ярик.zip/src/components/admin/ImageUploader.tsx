
import React, { useState, useCallback } from 'react';
import { uploadImage } from '../../utils/supabaseStorage';
import ImageCropModal from './ImageCropModal';

interface ImageUploaderProps {
  currentImage?: string;
  onUpload: (url: string) => void;
  label?: string;
}

const ImageUploader: React.FC<ImageUploaderProps> = ({
  currentImage,
  onUpload,
  label = 'Загрузить изображение',
}) => {
  const [uploading, setUploading] = useState(false);
  const [showCrop, setShowCrop] = useState(false);
  const [tempImage, setTempImage] = useState<string>('');

  const handleFileSelect = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      alert('Пожалуйста, выберите файл изображения');
      return;
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      alert('Размер файла не должен превышать 10MB');
      return;
    }

    // Show preview for cropping
    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        setTempImage(reader.result);
        setShowCrop(true);
      }
    };
    reader.onerror = () => {
      alert('Ошибка при чтении файла');
    };
    reader.readAsDataURL(file);
  }, []);

  const handleCropSave = useCallback(async (croppedUrl: string) => {
    if (!croppedUrl) {
      console.error('No cropped URL provided');
      return;
    }

    setUploading(true);
    try {
      // Convert base64 to blob
      const response = await fetch(croppedUrl);
      if (!response.ok) {
        throw new Error('Failed to fetch image data');
      }
      const blob = await response.blob();
      
      if (blob.size === 0) {
        throw new Error('Empty image data');
      }

      const file = new File([blob], 'cropped-image.jpg', { type: 'image/jpeg' });
      
      // Upload cropped image
      const uploadedUrl = await uploadImage(file);
      
      if (uploadedUrl) {
        onUpload(uploadedUrl);
      } else {
        throw new Error('Upload failed - no URL returned');
      }
    } catch (error) {
      console.error('Error uploading image:', error);
      alert('Ошибка загрузки изображения: ' + (error instanceof Error ? error.message : 'Неизвестная ошибка'));
    } finally {
      setUploading(false);
      setShowCrop(false);
      setTempImage('');
    }
  }, [onUpload]);

  const handleRemove = useCallback(() => {
    onUpload('');
  }, [onUpload]);

  const handleCloseCrop = useCallback(() => {
    setShowCrop(false);
    setTempImage('');
  }, []);

  return (
    <>
      <div className="space-y-3">
        {currentImage ? (
          <div className="relative aspect-video bg-gray-100 rounded-lg overflow-hidden group">
            <img
              src={currentImage}
              alt="Preview"
              className="w-full h-full object-cover"
              onError={(e) => {
                console.error('Image failed to load');
                e.currentTarget.src = '';
              }}
            />
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
              <label className="px-4 py-2 bg-white rounded-lg cursor-pointer hover:bg-gray-100 transition-colors text-sm font-medium whitespace-nowrap">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileSelect}
                  className="hidden"
                  disabled={uploading}
                />
                <i className="ri-crop-line mr-1"></i>
                Изменить
              </label>
              <button
                type="button"
                onClick={handleRemove}
                className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors text-sm font-medium cursor-pointer whitespace-nowrap"
                disabled={uploading}
              >
                <i className="ri-delete-bin-line mr-1"></i>
                Удалить
              </button>
            </div>
          </div>
        ) : (
          <label className="relative aspect-video bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 hover:border-slate-900 transition-colors cursor-pointer flex flex-col items-center justify-center">
            <input
              type="file"
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
              disabled={uploading}
            />
            {uploading ? (
              <>
                <div className="w-12 h-12 border-4 border-slate-900 border-t-transparent rounded-full animate-spin mb-3"></div>
                <span className="text-sm text-gray-600">Загрузка...</span>
              </>
            ) : (
              <>
                <i className="ri-upload-cloud-line text-4xl text-gray-400 mb-3"></i>
                <span className="text-sm font-medium text-gray-700">{label}</span>
                <span className="text-xs text-gray-500 mt-1">Нажмите для выбора файла</span>
              </>
            )}
          </label>
        )}
      </div>

      {showCrop && tempImage && (
        <ImageCropModal
          imageUrl={tempImage}
          onSave={handleCropSave}
          onClose={handleCloseCrop}
        />
      )}
    </>
  );
};

export default ImageUploader;
