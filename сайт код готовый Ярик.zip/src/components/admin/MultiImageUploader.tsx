
import React, { useState } from 'react';
import { uploadImage } from '../../utils/supabaseStorage';
import ImageCropModal from './ImageCropModal';

interface MultiImageUploaderProps {
  images: string[];
  onImagesChange: (images: string[]) => void;
  maxImages?: number;
}

const MultiImageUploader: React.FC<MultiImageUploaderProps> = ({
  images,
  onImagesChange,
  maxImages = 10,
}) => {
  const [uploading, setUploading] = useState(false);
  const [cropImage, setCropImage] = useState<{ url: string; index: number } | null>(null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    if (images.length + files.length > maxImages) {
      alert(`Максимум ${maxImages} изображений`);
      return;
    }

    setUploading(true);

    try {
      const uploadPromises = Array.from(files).map((file) => uploadImage(file));
      const urls = await Promise.all(uploadPromises);
      onImagesChange([...images, ...urls.filter((url): url is string => url !== null)]);
    } catch (error) {
      console.error('Error uploading images:', error);
      alert('Ошибка загрузки изображений');
    } finally {
      setUploading(false);
    }
  };

  const handleRemove = (index: number) => {
    const newImages = images.filter((_, i) => i !== index);
    onImagesChange(newImages);
  };

  const handleCrop = (index: number) => {
    setCropImage({ url: images[index], index });
  };

  const handleCropSave = async (croppedUrl: string) => {
    if (!cropImage) return;

    setUploading(true);
    try {
      // Convert base64 to blob
      const response = await fetch(croppedUrl);
      const blob = await response.blob();
      const file = new File([blob], 'cropped-image.jpg', { type: 'image/jpeg' });
      
      // Upload cropped image
      const uploadedUrl = await uploadImage(file);
      
      if (uploadedUrl) {
        const newImages = [...images];
        newImages[cropImage.index] = uploadedUrl;
        onImagesChange(newImages);
      }
    } catch (error) {
      console.error('Error saving cropped image:', error);
      alert('Ошибка сохранения изображения');
    } finally {
      setUploading(false);
      setCropImage(null);
    }
  };

  const moveImage = (fromIndex: number, toIndex: number) => {
    const newImages = [...images];
    const [movedImage] = newImages.splice(fromIndex, 1);
    newImages.splice(toIndex, 0, movedImage);
    onImagesChange(newImages);
  };

  return (
    <>
      <div className="space-y-4">
        <div className="grid grid-cols-3 gap-4">
          {images.map((url, index) => (
            <div
              key={index}
              className="relative aspect-square bg-gray-100 rounded-lg overflow-hidden group"
            >
              <img
                src={url}
                alt={`Image ${index + 1}`}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                {index > 0 && (
                  <button
                    type="button"
                    onClick={() => moveImage(index, index - 1)}
                    className="w-8 h-8 bg-white rounded-lg flex items-center justify-center cursor-pointer hover:bg-gray-100 transition-colors"
                    title="Переместить влево"
                  >
                    <i className="ri-arrow-left-line text-gray-700"></i>
                  </button>
                )}
                {index < images.length - 1 && (
                  <button
                    type="button"
                    onClick={() => moveImage(index, index + 1)}
                    className="w-8 h-8 bg-white rounded-lg flex items-center justify-center cursor-pointer hover:bg-gray-100 transition-colors"
                    title="Переместить вправо"
                  >
                    <i className="ri-arrow-right-line text-gray-700"></i>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => handleCrop(index)}
                  className="w-8 h-8 bg-white rounded-lg flex items-center justify-center cursor-pointer hover:bg-gray-100 transition-colors"
                  title="Обрезать"
                >
                  <i className="ri-crop-line text-gray-700"></i>
                </button>
                <button
                  type="button"
                  onClick={() => handleRemove(index)}
                  className="w-8 h-8 bg-red-500 rounded-lg flex items-center justify-center cursor-pointer hover:bg-red-600 transition-colors"
                  title="Удалить"
                >
                  <i className="ri-delete-bin-line text-white"></i>
                </button>
              </div>
              <div className="absolute top-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
                {index + 1}
              </div>
            </div>
          ))}

          {images.length < maxImages && (
            <label className="relative aspect-square bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 hover:border-slate-900 transition-colors cursor-pointer flex flex-col items-center justify-center">
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={handleFileSelect}
                className="hidden"
                disabled={uploading}
              />
              {uploading ? (
                <>
                  <div className="w-8 h-8 border-4 border-slate-900 border-t-transparent rounded-full animate-spin mb-2"></div>
                  <span className="text-sm text-gray-600">Загрузка...</span>
                </>
              ) : (
                <>
                  <i className="ri-upload-cloud-line text-3xl text-gray-400 mb-2"></i>
                  <span className="text-sm text-gray-600">Добавить фото</span>
                  <span className="text-xs text-gray-400 mt-1">
                    {images.length}/{maxImages}
                  </span>
                </>
              )}
            </label>
          )}
        </div>

        {images.length > 0 && (
          <p className="text-xs text-gray-500">
            <i className="ri-information-line mr-1"></i>
            Наведите на изображение для редактирования. Используйте стрелки для изменения порядка.
          </p>
        )}
      </div>

      {cropImage && (
        <ImageCropModal
          imageUrl={cropImage.url}
          onSave={handleCropSave}
          onClose={() => setCropImage(null)}
        />
      )}
    </>
  );
};

export default MultiImageUploader;
