import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-50 dark:bg-black border-t border-gray-200 dark:border-gray-800 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Logo & Address */}
          <div className="lg:col-span-1">
            <img 
              src="https://static.readdy.ai/image/0cf44aa0cc15a2a90aea4d375f9c5b69/a013b1a81d4df57824f98bbead4b6790.png"
              alt="Baths&Home Module" 
              className="h-14 w-auto mb-6 dark:hidden"
            />
            <img 
              src="https://static.readdy.ai/image/0cf44aa0cc15a2a90aea4d375f9c5b69/087fc59f430f054c72c81b9877d49dc4.png"
              alt="Baths&Home Module" 
              className="h-14 w-auto mb-6 hidden dark:block"
            />
            <div className="space-y-4 mb-6">
              <div>
                <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-1 uppercase tracking-wide">Адрес</p>
                <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed">
                  Вологодская область, Вологодский район, деревня Юрово
                </p>
              </div>
              <div>
                <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-1 uppercase tracking-wide">График работы</p>
                <p className="text-gray-600 dark:text-gray-300 text-sm">
                  Ежедневно с 9:00 до 21:00
                </p>
              </div>
            </div>
            <div className="flex space-x-3">
              <a
                href="https://vk.com/club234167565"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 flex items-center justify-center rounded-full bg-white dark:bg-gray-900 hover:bg-blue-50 dark:hover:bg-gray-800 transition-colors cursor-pointer shadow-sm"
              >
                <i className="ri-vk-fill text-blue-600 dark:text-blue-400 text-xl"></i>
              </a>
              <a
                href="https://api.whatsapp.com/send/?phone=79115098818&text=Добрый+день%21+Хочу+получить+консультацию&type=phone_number&app_absent=0"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 flex items-center justify-center rounded-full bg-white dark:bg-gray-900 hover:bg-green-50 dark:hover:bg-gray-800 transition-colors cursor-pointer shadow-sm"
              >
                <i className="ri-whatsapp-fill text-green-600 dark:text-green-400 text-xl"></i>
              </a>
              <a
                href="https://t.me/+79115098818"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 flex items-center justify-center rounded-full bg-white dark:bg-gray-900 hover:bg-blue-50 dark:hover:bg-gray-800 transition-colors cursor-pointer shadow-sm"
              >
                <i className="ri-telegram-fill text-blue-500 dark:text-blue-400 text-xl"></i>
              </a>
            </div>
          </div>

          {/* Catalog */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-5">Каталог проектов</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/catalog" className="text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 text-sm transition-colors cursor-pointer">
                  Все проекты
                </Link>
              </li>
              <li>
                <Link to="/modulnye-doma" className="text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 text-sm transition-colors cursor-pointer">
                  Модульные дома
                </Link>
              </li>
              <li>
                <Link to="/dvumodulnye" className="text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 text-sm transition-colors cursor-pointer">
                  Двумодульные
                </Link>
              </li>
              <li>
                <Link to="/odnomodulnye-bani" className="text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 text-sm transition-colors cursor-pointer">
                  Одномодульные бани
                </Link>
              </li>
              <li>
                <Link to="/grill-zones" className="text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 text-sm transition-colors cursor-pointer">
                  Гриль-зоны
                </Link>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-5">Компания</h3>
            <ul className="space-y-3">
              <li>
                <Link to="/komplektaciya" className="text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 text-sm transition-colors cursor-pointer">
                  Комплектация
                </Link>
              </li>
              <li>
                <Link to="/portfolio" className="text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 text-sm transition-colors cursor-pointer">
                  Портфолио
                </Link>
              </li>
              <li>
                <Link to="/contacts" className="text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 text-sm transition-colors cursor-pointer">
                  Контакты
                </Link>
              </li>
              <li>
                <Link to="/calculator" className="text-gray-600 dark:text-gray-300 hover:text-green-600 dark:hover:text-green-400 text-sm transition-colors cursor-pointer">
                  Калькулятор
                </Link>
              </li>
            </ul>
          </div>

          {/* Contacts */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-5">Контакты</h3>
            <ul className="space-y-4">
              <li>
                <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-1 uppercase tracking-wide">Телефон</p>
                <a href="tel:+79115098818" className="text-gray-900 dark:text-white hover:text-green-600 dark:hover:text-green-400 font-medium transition-colors cursor-pointer">
                  +7 911 509 88 18
                </a>
              </li>
              <li>
                <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-1 uppercase tracking-wide">Email</p>
                <a href="mailto:bathsandhome@mail.ru" className="text-gray-900 dark:text-white hover:text-green-600 dark:hover:text-green-400 font-medium transition-colors cursor-pointer break-all">
                  bathsandhome@mail.ru
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-gray-200 dark:border-gray-800">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              © 2025 Baths&Home Module. Все права защищены.
            </p>
            <div className="flex items-center gap-4">
              <Link 
                to="/admin" 
                className="text-gray-500 dark:text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 text-xs transition-colors cursor-pointer"
              >
                Админ-панель
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
