
import React, { useState } from 'react';
import { Link } from 'react-router-dom';

interface HeaderProps {
  isDarkMode: boolean;
  toggleTheme: () => void;
}

const Header: React.FC<HeaderProps> = ({ isDarkMode, toggleTheme }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCatalogOpen, setIsCatalogOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
    setIsCatalogOpen(false);
  };

  const toggleCatalog = () => {
    setIsCatalogOpen(!isCatalogOpen);
  };

  const closeCatalog = () => {
    setIsCatalogOpen(false);
  };

  const closeAllMenus = () => {
    setIsMenuOpen(false);
    setIsCatalogOpen(false);
  };

  const navItems = [
    { name: 'Главная', path: '/' },
    { name: 'Комплектация', path: '/komplektaciya' },
    { name: 'Портфолио', path: '/portfolio' },
    { name: 'Контакты', path: '/contacts' },
    { name: 'Калькулятор', path: '/calculator' },
  ];

  return (
    <header className="bg-white dark:bg-black shadow-sm sticky top-0 z-50 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16 gap-6">
          {/* Logo */}
          <Link to="/" className="flex items-center flex-shrink-0" onClick={closeAllMenus}>
            <img 
              src={isDarkMode ? "https://static.readdy.ai/image/0cf44aa0cc15a2a90aea4d375f9c5b69/087fc59f430f054c72c81b9877d49dc4.png" : "https://static.readdy.ai/image/0cf44aa0cc15a2a90aea4d375f9c5b69/a013b1a81d4df57824f98bbead4b6790.png"}
              alt="Baths&Home Module" 
              className="h-10 w-auto"
            />
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-6 flex-1">
            <Link to="/" className="text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white transition-colors whitespace-nowrap cursor-pointer">
              Главная
            </Link>
            
            <div className="relative group">
              <Link to="/catalog" className="flex items-center gap-1 text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white transition-colors whitespace-nowrap cursor-pointer">
                Каталог проектов
                <i className="ri-arrow-down-s-line"></i>
              </Link>
              
              <div className="absolute top-full left-0 mt-2 w-56 bg-white dark:bg-black rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-50">
                <div className="py-2">
                  <Link to="/catalog" className="block px-4 py-2 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-900 hover:text-gray-900 dark:hover:text-white transition-colors whitespace-nowrap cursor-pointer">
                    Все проекты
                  </Link>
                  <Link to="/modulnye-doma" className="block px-4 py-2 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-900 hover:text-gray-900 dark:hover:text-white transition-colors whitespace-nowrap cursor-pointer">
                    Модульные дома
                  </Link>
                  <Link to="/dvumodulnye" className="block px-4 py-2 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-900 hover:text-gray-900 dark:hover:text-white transition-colors whitespace-nowrap cursor-pointer">
                    Двумодульные
                  </Link>
                  <Link to="/odnomodulnye-bani" className="block px-4 py-2 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-900 hover:text-gray-900 dark:hover:text-white transition-colors whitespace-nowrap cursor-pointer">
                    Одномодульные бани
                  </Link>
                  <Link to="/grill-zones" className="block px-4 py-2 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-900 hover:text-gray-900 dark:hover:text-white transition-colors whitespace-nowrap cursor-pointer">
                    Гриль-дома
                  </Link>
                </div>
              </div>
            </div>

            <Link
              to="/komplektaciya"
              className="text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white text-sm font-medium whitespace-nowrap cursor-pointer"
              onClick={closeAllMenus}
            >
              Комплектация
            </Link>
            <Link
              to="/portfolio"
              className="text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white text-sm font-medium whitespace-nowrap cursor-pointer"
              onClick={closeAllMenus}
            >
              Портфолио
            </Link>
            <Link
              to="/contacts"
              className="text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white text-sm font-medium whitespace-nowrap cursor-pointer"
              onClick={closeAllMenus}
            >
              Контакты
            </Link>
            <Link
              to="/calculator"
              className="text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white text-sm font-medium whitespace-nowrap cursor-pointer"
              onClick={closeAllMenus}
            >
              Калькулятор
            </Link>
          </nav>

          {/* Contact Info, Social & Theme Toggle */}
          <div className="flex items-center space-x-3 flex-shrink-0">
            <a href="tel:+79115098818" className="hidden lg:block text-gray-900 dark:text-white font-medium text-sm whitespace-nowrap cursor-pointer">
              +7 911 509 88 18
            </a>
            <div className="hidden lg:flex items-center space-x-2">
              <a
                href="https://vk.com/club234167565"
                target="_blank"
                rel="noopener noreferrer"
                className="w-7 h-7 flex items-center justify-center cursor-pointer"
              >
                <i className="ri-vk-fill text-blue-600 dark:text-blue-400 text-xl"></i>
              </a>
              <a
                href="https://api.whatsapp.com/send/?phone=79115098818&text=Добрый+день%21+Хочу+получить+консультацию&type=phone_number&app_absent=0"
                target="_blank"
                rel="noopener noreferrer"
                className="w-7 h-7 flex items-center justify-center cursor-pointer"
              >
                <i className="ri-whatsapp-fill text-green-600 dark:text-green-400 text-xl"></i>
              </a>
              <a
                href="https://t.me/+79115098818"
                target="_blank"
                rel="noopener noreferrer"
                className="w-7 h-7 flex items-center justify-center cursor-pointer"
              >
                <i className="ri-telegram-fill text-blue-500 dark:text-blue-400 text-xl"></i>
              </a>
            </div>
            
            {/* Theme Toggle Button */}
            <button
              onClick={toggleTheme}
              type="button"
              className="w-9 h-9 flex items-center justify-center rounded-full bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 transition-all cursor-pointer active:scale-95 relative z-10"
              aria-label="Переключить тему"
            >
              {isDarkMode ? (
                <i className="ri-sun-line text-white text-xl pointer-events-none"></i>
              ) : (
                <i className="ri-moon-line text-gray-700 text-xl pointer-events-none"></i>
              )}
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center">
            <button
              onClick={toggleMenu}
              type="button"
              className="w-10 h-10 flex items-center justify-center cursor-pointer touch-manipulation active:scale-95 transition-transform z-50 relative"
            >
              <i className={`${isMenuOpen ? 'ri-close-line' : 'ri-menu-line'} text-gray-700 dark:text-gray-200 text-2xl pointer-events-none`}></i>
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="lg:hidden border-t border-gray-200 dark:border-gray-800 py-4 relative z-50 bg-white dark:bg-black">
            <div className="space-y-2">
              <div>
                <button
                  onClick={toggleCatalog}
                  className="w-full text-left px-3 py-2 text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white text-sm font-medium flex items-center justify-between cursor-pointer touch-manipulation active:bg-gray-50 dark:active:bg-gray-900"
                >
                  Каталог проектов
                  <i className={`ri-arrow-down-s-line transition-transform ${isCatalogOpen ? 'rotate-180' : ''}`}></i>
                </button>
                {isCatalogOpen && (
                  <div className="pl-6 space-y-1">
                    <Link
                      to="/catalog"
                      className="block px-3 py-2 text-sm text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white cursor-pointer touch-manipulation active:bg-gray-50 dark:active:bg-gray-900"
                      onClick={closeAllMenus}
                    >
                      Все проекты
                    </Link>
                    <Link
                      to="/modulnye-doma"
                      className="block px-3 py-2 text-sm text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white cursor-pointer touch-manipulation active:bg-gray-50 dark:active:bg-gray-900"
                      onClick={closeAllMenus}
                    >
                      Модульные дома
                    </Link>
                    <Link
                      to="/dvumodulnye"
                      className="block px-3 py-2 text-sm text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white cursor-pointer touch-manipulation active:bg-gray-50 dark:active:bg-gray-900"
                      onClick={closeAllMenus}
                    >
                      Двумодульные
                    </Link>
                    <Link
                      to="/odnomodulnye-bani"
                      className="block px-3 py-2 text-sm text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white cursor-pointer touch-manipulation active:bg-gray-50 dark:active:bg-gray-900"
                      onClick={closeAllMenus}
                    >
                      Одномодульные бани
                    </Link>
                    <Link
                      to="/grill-zones"
                      className="block px-3 py-2 text-sm text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white cursor-pointer touch-manipulation active:bg-gray-50 dark:active:bg-gray-900"
                      onClick={closeAllMenus}
                    >
                      Гриль-дома
                    </Link>
                  </div>
                )}
              </div>
              <Link
                to="/komplektaciya"
                className="block px-3 py-2 text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white text-sm font-medium cursor-pointer touch-manipulation active:bg-gray-50 dark:active:bg-gray-900"
                onClick={closeAllMenus}
              >
                Комплектация
              </Link>
              <Link
                to="/portfolio"
                className="block px-3 py-2 text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white text-sm font-medium cursor-pointer touch-manipulation active:bg-gray-50 dark:active:bg-gray-900"
                onClick={closeAllMenus}
              >
                Портфолио
              </Link>
              <Link
                to="/contacts"
                className="block px-3 py-2 text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white text-sm font-medium cursor-pointer touch-manipulation active:bg-gray-50 dark:active:bg-gray-900"
                onClick={closeAllMenus}
              >
                Контакты
              </Link>
              <Link
                to="/calculator"
                className="block px-3 py-2 text-gray-700 dark:text-gray-200 hover:text-gray-900 dark:hover:text-white text-sm font-medium cursor-pointer touch-manipulation active:bg-gray-50 dark:active:bg-gray-900"
                onClick={closeAllMenus}
              >
                Калькулятор
              </Link>
              
              {/* Mobile Contact Info */}
              <div className="pt-4 border-t border-gray-200 dark:border-gray-800">
                <a href="tel:+79115098818" className="block px-3 py-2 text-gray-900 dark:text-white font-medium text-sm cursor-pointer touch-manipulation active:bg-gray-50 dark:active:bg-gray-900">
                  +7 911 509 88 18
                </a>
                <div className="flex items-center space-x-4 px-3 py-2">
                  <a
                    href="https://vk.com/club234167565"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 flex items-center justify-center cursor-pointer touch-manipulation active:scale-95 transition-transform"
                  >
                    <i className="ri-vk-fill text-blue-600 dark:text-blue-400 text-2xl"></i>
                  </a>
                  <a
                    href="https://api.whatsapp.com/send/?phone=79115098818&text=Добрый+день%21+Хочу+получить+консультацию&type=phone_number&app_absent=0"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 flex items-center justify-center cursor-pointer touch-manipulation active:scale-95 transition-transform"
                  >
                    <i className="ri-whatsapp-fill text-green-600 dark:text-green-400 text-2xl"></i>
                  </a>
                  <a
                    href="https://t.me/+79115098818"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-10 h-10 flex items-center justify-center cursor-pointer touch-manipulation active:scale-95 transition-transform"
                  >
                    <i className="ri-telegram-fill text-blue-500 dark:text-blue-400 text-2xl"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
