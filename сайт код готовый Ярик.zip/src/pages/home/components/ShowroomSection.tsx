
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import ConsultationModal from '../../../components/base/ConsultationModal';

const ShowroomSection: React.FC = () => {
  const [isConsultationModalOpen, setIsConsultationModalOpen] = useState(false);

  const handleExcursionClick = () => {
    setIsConsultationModalOpen(true);
  };

  return (
    <>
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="text-white">
              <h2 className="text-3xl lg:text-4xl font-bold mb-6">
                Приходите в гости — мы покажем ваш будущий дом
              </h2>
              <p className="text-lg text-gray-300 mb-6">
                На Дне открытых дверей вы сможете увидеть готовые модульные дома вживую, пройтись по комнатам, оценить качество и задать вопросы нашим экспертам
              </p>
              <p className="text-lg text-gray-300 mb-8">
                Оставьте заявку и мы пригласим вас на ближайший День открытых дверей
              </p>
              <button 
                onClick={handleExcursionClick}
                className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
              >
                Записаться на экскурсию
              </button>
            </div>

            {/* Right Content - Video */}
            <div className="relative">
              <div className="bg-gray-800 rounded-xl overflow-hidden">
                <iframe
                  src="https://kinescope.io/embed/0N7K7sdxoyqsJK6Z2CDT1N"
                  allow="autoplay; fullscreen; picture-in-picture; encrypted-media; gyroscope; accelerometer; clipboard-write; screen-wake-lock;"
                  frameBorder="0"
                  allowFullScreen
                  className="w-full h-64 lg:h-80"
                  title="Экскурсия по выставочному дому"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <ConsultationModal 
        isOpen={isConsultationModalOpen}
        onClose={() => setIsConsultationModalOpen(false)}
      />
    </>
  );
};

export default ShowroomSection;
