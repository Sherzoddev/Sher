import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { createClient } from '@supabase/supabase-js';
import ConsultationModal from '../../../components/base/ConsultationModal';

const supabase = createClient(
  import.meta.env.VITE_PUBLIC_SUPABASE_URL,
  import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY
);

interface PortfolioVideo {
  id: string;
  video_id: string;
  title: string;
  button_text: string;
  button_action: string;
  display_order: number;
}

const PortfolioSection: React.FC = () => {
  const navigate = useNavigate();
  const [isConsultationModalOpen, setIsConsultationModalOpen] = useState(false);
  const [portfolioVideos, setPortfolioVideos] = useState<PortfolioVideo[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadVideos();
  }, []);

  const loadVideos = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('portfolio_videos')
      .select('*')
      .eq('is_active', true)
      .order('display_order', { ascending: true });

    if (!error && data) {
      setPortfolioVideos(data);
    }
    setLoading(false);
  };

  const handleButtonAction = (action: string) => {
    if (action === 'portfolio') {
      navigate('/portfolio');
    } else if (action === 'consultation') {
      setIsConsultationModalOpen(true);
    } else if (action === 'calculator') {
      navigate('/calculator');
    }
  };

  if (loading) {
    return (
      <section className="py-20 bg-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="w-16 h-16 border-4 border-amber-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-gray-600">Загрузка...</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <>
      <section className="py-20 bg-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
              Посмотрите, как выглядят дома HUTS внутри и снаружи
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Каждый ролик — это полноценный тур: от фасада до спальни. Убедитесь сами в качестве и удобстве наших домов
            </p>
          </div>

          {/* Desktop Grid */}
          <div className="hidden md:grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {portfolioVideos.map((video) => (
              <div key={video.id} className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
                <div className="relative aspect-video">
                  <iframe
                    src={`https://vk.com/video_ext.php?oid=-119716720&id=${video.video_id}&color=ffffff1&hd=2&js_api=1`}
                    width="100%"
                    height="100%"
                    frameBorder="0"
                    allowFullScreen
                    allow="clipboard-write; autoplay; encrypted-media; fullscreen; picture-in-picture; screen-wake-lock;"
                    className="w-full h-full"
                    title={video.title}
                  />
                </div>
                <div className="p-4">
                  <div className="flex gap-2">
                    <button 
                      onClick={() => handleButtonAction(video.button_action)}
                      className="flex-1 bg-amber-600 text-white py-2 px-4 rounded-lg hover:bg-amber-700 transition-colors text-sm font-medium whitespace-nowrap cursor-pointer"
                    >
                      {video.button_text}
                    </button>
                    <button 
                      onClick={() => navigate('/calculator')}
                      className="flex-1 border border-amber-600 text-amber-600 py-2 px-4 rounded-lg hover:bg-amber-50 transition-colors text-sm font-medium whitespace-nowrap cursor-pointer"
                    >
                      Калькулятор
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Mobile Slider */}
          <div className="md:hidden">
            <div className="flex overflow-x-auto space-x-4 pb-4">
              {portfolioVideos.map((video) => (
                <div key={video.id} className="flex-shrink-0 w-80 bg-white rounded-xl overflow-hidden shadow-lg">
                  <div className="relative aspect-video">
                    <iframe
                      src={`https://vk.com/video_ext.php?oid=-119716720&id=${video.video_id}&color=ffffff1&hd=2&js_api=1`}
                      width="100%"
                      height="100%"
                      frameBorder="0"
                      allowFullScreen
                      allow="clipboard-write; autoplay; encrypted-media; fullscreen; picture-in-picture; screen-wake-lock;"
                      className="w-full h-full"
                      title={video.title}
                    />
                  </div>
                  <div className="p-4">
                    <div className="flex gap-2">
                      <button 
                        onClick={() => handleButtonAction(video.button_action)}
                        className="flex-1 bg-amber-600 text-white py-2 px-4 rounded-lg hover:bg-amber-700 transition-colors text-sm font-medium whitespace-nowrap cursor-pointer"
                      >
                        {video.button_text}
                      </button>
                      <button 
                        onClick={() => navigate('/calculator')}
                        className="flex-1 border border-amber-600 text-amber-600 py-2 px-4 rounded-lg hover:bg-amber-50 transition-colors text-sm font-medium whitespace-nowrap cursor-pointer"
                      >
                        Калькулятор
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="text-center mt-12">
            <button 
              onClick={() => navigate('/portfolio')}
              className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-colors whitespace-nowrap cursor-pointer"
            >
              Смотреть все проекты
            </button>
          </div>
        </div>
      </section>

      <ConsultationModal 
        isOpen={isConsultationModalOpen}
        onClose={() => setIsConsultationModalOpen(false)}
      />
    </>
  );
};

export default PortfolioSection;
