import React, { useState } from 'react';

const FAQSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      question: "Что входит в базовую комплектацию бани?",
      answer: "Базовая комплектация включает: силовой каркас из калиброванной доски с антисептиком, кровлю металл-профиль С-21, утепление каменной ватой 100мм, наружную отделку имитацией бруса с покраской, внутреннюю отделку парной осиной, комнаты отдыха вагонкой, входную дверь ПВХ с замком, межкомнатные стеклянные термостойкие двери, окна с москитными сетками, электрику с щитком и автоматами, светильники, розетки, банную печь с дымоходом и камнями 40кг, двухуровневые полки из осины, вентиляцию. Опционально: вынос топки, сантехника."
    },
    {
      question: "Холодно ли зимой в модульном доме?",
      answer: "Нет, совсем не холодно! Наши дома утеплены по стандартам северных регионов и рассчитаны на эксплуатацию при температуре до -45°C. Мы используем качественную каменную вату толщиной 150-200мм в стенах и 200-250мм в кровле. Все стыки тщательно герметизируются, устанавливаются энергоэффективные окна. Многие наши клиенты живут в домах круглый год и отмечают, что зимой тепло и комфортно, а расходы на отопление минимальны."
    },
    {
      question: "Насколько долговечны модульные дома?",
      answer: "Срок эксплуатации каркасных домов составляет более 80 лет при соблюдении правил. Но не стоит забывать, что срок службы также зависит от отношения владельца к собственному дому. Дом нужно любить и ухаживать за ним."
    },
    {
      question: "Входит в стоимость?",
      answer: "В стоимость входит: внутренняя и внешняя отделка, межкомнатные двери, окна, сантехника, отделка плиткой в мокрых зонах, доставка и установка в радиусе 30 км от Вологды, лестница на террасу (при её заказе) или в дом (3 ступени, шириной до 2-х метров), датчики протечек, решётка от грызунов."
    },
    {
      question: "Что не входит в стоимость?",
      answer: "Не входит в стоимость: аренда дополнительной спецтехники (кран, бульдозер, генераторы и т. д.), камин (отопительная печь) и комплектующие, кухня, мебель и бытовая техника, настилы, веранды и т. д., организация и подключение водоснабжения, канализации, электричества на участке."
    },
    {
      question: "Какой срок производства?",
      answer: "Стандартные сроки поставки, которые мы фиксируем в договоре — 90 календарных дней (без учета загруженности производства). Стандартные сроки монтажа дома на участке — 2−3 дня. Удаленность, рельеф участка, подъездные пути, комплектация дома, погодные условия могут внести свои коррективы."
    },
    {
      question: "Есть ли гарантии?",
      answer: "Мы уверены в качестве производимых нами изделий, поэтому даем до 2 лет гарантии на конструкционную прочность дома и внутреннюю отделку."
    },
    {
      question: "Доставка и установка",
      answer: "Мы осуществляем доставку по всей России. Доставка и установка в радиусе 30 км от Вологды — бесплатно за счет компании. Для более удаленных объектов стоимость доставки рассчитывается индивидуально."
    }
  ];

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-20 bg-white dark:bg-gray-900 transition-colors duration-300">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 dark:text-white mb-6 transition-colors duration-300">
            Часто задаваемые вопросы
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 transition-colors duration-300">
            Как всё происходит? Что входит в стоимость?<br />
            Ответили на самые частые вопросы, чтобы вам было проще разобраться.
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div key={index} className="border border-gray-300 dark:border-gray-700 rounded-lg overflow-hidden transition-colors duration-300">
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full px-6 py-4 text-left bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:bg-gray-50 dark:focus:bg-gray-700 transition-colors cursor-pointer"
              >
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white pr-4 transition-colors duration-300">
                    {faq.question}
                  </h3>
                  <div className="flex-shrink-0">
                    <div className={`w-6 h-6 rounded-full border-2 border-[#222222] dark:border-gray-400 flex items-center justify-center transition-all duration-300 ${openIndex === index ? 'rotate-45' : ''}`}>
                      <div className="w-3 h-0.5 bg-[#222222] dark:bg-gray-400 transition-colors duration-300" />
                      <div className={`w-0.5 h-3 bg-[#222222] dark:bg-gray-400 absolute transition-all duration-300 ${openIndex === index ? 'opacity-0' : 'opacity-100'}`} />
                    </div>
                  </div>
                </div>
              </button>
              
              {openIndex === index && (
                <div className="px-6 pb-4 bg-white dark:bg-gray-800 transition-colors duration-300">
                  <div className="text-gray-600 dark:text-gray-300 leading-relaxed transition-colors duration-300">
                    {faq.answer}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
