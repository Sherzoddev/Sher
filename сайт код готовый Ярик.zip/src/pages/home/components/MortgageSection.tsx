
import React from 'react';

const MortgageSection: React.FC = () => {
  const banks = [
    {
      name: "Альфабанк",
      logo: "https://static.tildacdn.com/tild3961-6433-4164-b734-343532353963/noroot.png"
    },
    {
      name: "ВТБ банк", 
      logo: "https://static.tildacdn.com/tild6135-3232-4661-a636-656436353534/noroot.png"
    },
    {
      name: "Дом рф",
      logo: "https://static.tildacdn.com/tild3832-3966-4234-a532-306261303131/noroot.png"
    },
    {
      name: "РСХБ",
      logo: "https://static.tildacdn.com/tild3963-3364-4634-b138-373531306238/noroot.png"
    },
    {
      name: "СБЕР банк",
      logo: "https://static.tildacdn.com/tild6564-6161-4466-b732-653164303865/noroot.png"
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
              дома с настоящей ипотекой от ведущих банков
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              Оформляем любой дом в ипотеку от 3%
            </p>
            
            {/* Bank Logos */}
            <div className="grid grid-cols-3 md:grid-cols-5 gap-6 mb-8">
              {banks.map((bank, index) => (
                <div key={index} className="flex items-center justify-center p-4 bg-gray-50 rounded-lg">
                  <img 
                    src={bank.logo}
                    alt={bank.name}
                    className="h-8 w-auto object-contain"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Right Content */}
          <div className="bg-gray-50 rounded-xl p-8">
            <div className="space-y-6">
              <p className="text-lg text-gray-700 mb-6">
                Мы аккредитованы в крупнейших банках страны и предлагаем ипотеку на лучших условиях:
              </p>
              
              <ul className="space-y-4">
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Семейная ипотека от <strong>6%</strong></span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Сельская ипотека от <strong>3%</strong></span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Кредитные программы от наших партнёров</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Работаем по эскроу-счетам, поэтому ваши деньги под надёжной защитой банка</span>
                </li>
              </ul>

              <button className="w-full bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer">
                Получить консультацию по ипотеке
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MortgageSection;
