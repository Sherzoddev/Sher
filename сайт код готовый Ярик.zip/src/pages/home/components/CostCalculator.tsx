
import React, { useState } from 'react';

const CostCalculator: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>();
  const [showContactForm, setShowContactForm] = useState(false);
  const [formData, setFormData] = useState({ name: '', phone: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');

  const questions = [
    {
      id: 'houseType',
      title: 'Какой дом вам нужен?',
      options: ['Дом', 'Баня', 'Дом и баня', 'Свой вариант']
    },
    {
      id: 'landAvailability',
      title: 'Наличие участка',
      options: ['Есть', 'Нет']
    },
    {
      id: 'roofType',
      title: 'Тип кровли',
      options: ['Гибкая черепица', 'Металлический профнастил С20/21', 'Кликфальц']
    },
    {
      id: 'address',
      title: 'Адрес производства',
      options: ['Юрова', 'Другой адрес']
    },
    {
      id: 'paymentMethod',
      title: 'Как вы планируете приобретать дом/баню?',
      options: ['Ипотека', 'Наличные']
    }
  ];

  const handleAnswer = (questionId: string, answer: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: answer }));
    
    if (currentStep < questions.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setShowContactForm(true);
    }
  };

  const resetCalculator = () => {
    setCurrentStep(0);
    setAnswers({});
    setShowContactForm(false);
    setFormData({ name: '', phone: '' });
    setSubmitMessage('');
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const formDataToSend = new FormData();
      formDataToSend.append('name', formData.name);
      formDataToSend.append('phone', formData.phone);
      formDataToSend.append('houseType', answers.houseType || '');
      formDataToSend.append('landAvailability', answers.landAvailability || '');
      formDataToSend.append('roofType', answers.roofType || '');
      formDataToSend.append('address', answers.address || '');
      formDataToSend.append('paymentMethod', answers.paymentMethod || '');
      
      const response = await fetch('https://readdy.ai/api/form/d3pltgknmar9en36ndg0', {
        method: 'POST',
        body: formDataToSend
      });
      
      if (response.ok) {
        setSubmitMessage('Спасибо! Ваш расчет готов. Мы свяжемся с вами в ближайшее время.');
        setFormData({ name: '', phone: '' });
      } else {
        setSubmitMessage('Произошла ошибка. Попробуйте еще раз.');
      }
    } catch (error) {
      setSubmitMessage('Произошла ошибка. Попробуйте еще раз.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  if (showContactForm) {
    return (
      <section className="py-20 bg-gray-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl p-8">
            {submitMessage && (
              <div className={`mb-6 p-4 rounded-lg ${submitMessage.includes('Спасибо') ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                {submitMessage}
              </div>
            )}
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Left - Consultant */}
              <div className="flex items-center space-x-4">
                <img 
                  src="https://static.tildacdn.com/tild3238-3861-4436-b239-663231633438/YDV_5633_1.png"
                  alt="Николай Александрович"
                  className="w-20 h-20 rounded-full object-cover"
                />
                <div>
                  <h3 className="font-semibold text-gray-900">Николай Александрович</h3>
                  <p className="text-sm text-gray-600">Руководитель коммерческого отдела</p>
                </div>
              </div>

              {/* Right - Contact Form */}
              <div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">
                  Отлично! До результата остался последний шаг
                </h3>
                <form onSubmit={handleFormSubmit} className="space-y-4" data-readdy-form id="calculator-form">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Ваше имя:
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      placeholder="Имя"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Ваш телефон:
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                      placeholder="+7 (000) 000-00-00"
                      required
                    />
                  </div>
                  
                  <div className="bg-gray-50 rounded-lg p-4 mt-4">
                    <h4 className="font-semibold text-gray-900 mb-2">Стоимость производства</h4>
                    <p className="text-sm text-gray-600 mb-2">Предварительная стоимость: от 850 000 ₽</p>
                    <p className="text-xs text-gray-500">Стоимость работ уже включена в итоговую цену</p>
                  </div>
                  
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
                  >
                    {isSubmitting ? 'Отправляем...' : 'Получить расчет'}
                  </button>
                </form>
                <button
                  onClick={resetCalculator}
                  className="mt-4 text-sm text-gray-500 hover:text-gray-700 cursor-pointer"
                >
                  Начать заново
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-20 bg-gray-900">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-3">
            {/* Left Sidebar - Consultant */}
            <div className="bg-gray-50 p-8 flex flex-col items-center text-center">
              <img 
                src="https://static.tildacdn.com/tild3238-3861-4436-b239-663231633438/YDV_5633_1.png"
                alt="Николай Александрович"
                className="w-24 h-24 rounded-full object-cover mb-4"
              />
              <h3 className="font-semibold text-gray-900 mb-1">Николай Александрович</h3>
              <p className="text-sm text-gray-600 mb-4">Руководитель коммерческого отдела</p>
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <p className="text-sm text-gray-700">
                  Подберите модель дома и рассчитайте его стоимость
                </p>
              </div>
            </div>

            {/* Right Content - Quiz */}
            <div className="lg:col-span-2 p-8">
              {/* Progress Bar */}
              <div className="mb-8">
                <div className="flex justify-between text-sm text-gray-600 mb-2">
                  <span>Шаг: {currentStep + 1}/{questions.length}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-green-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${((currentStep + 1) / questions.length) * 100}%` }}
                  />
                </div>
              </div>

              {/* Current Question */}
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-8">
                  {questions[currentStep].title}
                </h2>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {questions[currentStep].options.map((option, index) => (
                    <button
                      key={index}
                      onClick={() => handleAnswer(questions[currentStep].id, option)}
                      className="p-4 text-left border-2 border-gray-200 rounded-lg hover:border-green-500 hover:bg-green-50 transition-colors cursor-pointer"
                    >
                      {option}
                    </button>
                  ))}
                </div>
              </div>

              {/* Navigation */}
              <div className="flex justify-between mt-8">
                <button
                  onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                  disabled={currentStep === 0}
                  className="px-6 py-2 text-gray-600 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                >
                  Назад
                </button>
                <span className="text-sm text-gray-500">
                  {currentStep + 1} из {questions.length}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CostCalculator;
