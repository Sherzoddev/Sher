import React, { useState } from 'react';

const ContactFormSection: React.FC = () => {
  const [formData, setFormData] = useState({
    phone: '',
    agreement: false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const formDataToSend = new URLSearchParams();
      formDataToSend.append('phone', formData.phone);
      formDataToSend.append('agreement', formData.agreement ? 'yes' : 'no');
      
      const response = await fetch('https://readdy.ai/api/form/d4i55cmusuhg53kqal20', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formDataToSend.toString()
      });
      
      if (response.ok) {
        setSubmitMessage('Спасибо! Ваша заявка отправлена. Мы свяжемся с вами в ближайшее время.');
        setFormData({ phone: '', agreement: false });
      } else {
        setSubmitMessage('Произошла ошибка. Попробуйте еще раз.');
      }
    } catch (error) {
      setSubmitMessage('Произошла ошибка. Попробуйте еще раз.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  return (
    <section className="py-20 bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="relative">
            <img 
              src="https://static.tildacdn.com/tild3630-3262-4565-b433-663031663832/YDV_5633.png"
              alt="Консультант Николай Александрович"
              className="w-full h-auto rounded-xl shadow-lg"
            />
            <div className="absolute bottom-6 left-6 bg-white rounded-lg p-4 shadow-lg max-w-xs">
              <h4 className="font-semibold text-gray-900 mb-1">Николай Александрович</h4>
              <p className="text-sm text-gray-600">Руководитель коммерческого отдела</p>
            </div>
          </div>

          {/* Right Content - Form */}
          <div className="bg-white rounded-xl p-8 shadow-lg">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Сделайте первый шаг — получите бесплатный расчёт
            </h2>
            
            <div className="mb-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">
                Получите бесплатную консультацию нашего специалиста
              </h3>
              <p className="text-gray-600 mb-6">
                Введите номер, и наш специалист перезвонит, чтобы рассчитать стоимость и подсказать оптимальный вариант
              </p>
            </div>

            {submitMessage && (
              <div className={`mb-6 p-4 rounded-lg ${submitMessage.includes('Спасибо') ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                {submitMessage}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6" data-readdy-form id="consultation-form">
              <div>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  placeholder="Номер телефона"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  required
                />
              </div>

              <div className="flex items-start">
                <input
                  type="checkbox"
                  name="agreement"
                  checked={formData.agreement}
                  onChange={handleInputChange}
                  className="mt-1 mr-3 h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                  required
                />
                <label className="text-sm text-gray-600">
                  Я принимаю условия{' '}
                  <a href="/privatpoicy" className="text-blue-600 underline" target="_blank">
                    Политики Конфиденциальности
                  </a>{' '}
                  и даю{' '}
                  <a href="https://docs.google.com/document/d/1IJ3990Y3votR_O_4E--jSAj50-eCd_pM/edit" className="text-blue-600 underline" target="_blank">
                    согласие на обработку персональных данных
                  </a>
                </label>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white px-8 py-4 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
              >
                {isSubmitting ? 'Отправляем...' : 'Подобрать дом'}
              </button>
            </form>

            <div className="mt-8 space-y-4">
              <ul className="space-y-3">
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Бесплатная консультация и расчёт стоимости</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Подбор проекта под ваши пожелания</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Ответы на все вопросы — честно и подробно</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactFormSection;