import React from 'react';

const TopFeaturesSection: React.FC = () => {
  const features = [
    {
      number: '01',
      title: 'Быстрая установка',
      description: 'Монтаж модульного дома или бани занимает всего 1 день. Вы сразу можете начать пользоваться!'
    },
    {
      number: '02',
      title: 'Готовность под ключ',
      description: 'Все коммуникации, отделка и мебель уже включены. Просто заезжайте и наслаждайтесь!'
    },
    {
      number: '03',
      title: 'Энергоэффективность',
      description: 'Современные материалы и технологии обеспечивают минимальные расходы на отопление'
    },
    {
      number: '04',
      title: 'Экологичность',
      description: 'Используем только натуральные и безопасные материалы для вашего здоровья'
    },
    {
      number: '05',
      title: 'Индивидуальный проект',
      description: 'Адаптируем любой проект под ваши пожелания и особенности участка'
    },
    {
      number: '06',
      title: 'Гарантия качества',
      description: 'Официальная гарантия 12 месяцев и постгарантийное обслуживание'
    },
    {
      number: '07',
      title: 'Доступная цена',
      description: 'Собственное производство позволяет предлагать лучшие цены на рынке'
    },
    {
      number: '08',
      title: 'Рассрочка и ипотека',
      description: 'Гибкие условия оплаты, работаем с банками-партнерами'
    },
    {
      number: '09',
      title: 'Всесезонность',
      description: 'Наши дома и бани комфортны для использования круглый год'
    },
    {
      number: '10',
      title: 'Долговечность',
      description: 'Срок службы более 50 лет при правильной эксплуатации'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-orange-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            ТОП-10 преимуществ наших домов и бань
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Почему более 1000 клиентов выбрали нас для строительства своего дома мечты
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="bg-white rounded-xl p-6 shadow-md hover:shadow-xl transition-all hover:-translate-y-1"
            >
              <div className="text-5xl font-bold text-orange-200 mb-3">
                {feature.number}
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-sm text-gray-600">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TopFeaturesSection;
