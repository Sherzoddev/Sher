import React from 'react';

const ReviewsSection: React.FC = () => {
  const reviews = [
    {
      name: 'Елизавета Письменная',
      date: '30 августа 2024',
      rating: 5,
      text: 'Баня получилась чудесная 😄 нарадоваться вот теперь не могу... Места много, и внутри и снаружи красота, деревом очень приятно пахнет. Сделано все хорошо, быстро установили, тут работникам отдельное спасибо, мусор не оставили, все чисто, аккуратно, молодцы ❤️',
      image: 'https://readdy.ai/api/search-image?query=realistic%20portrait%20of%20happy%20middle%20aged%20russian%20woman%20standing%20near%20modern%20wooden%20sauna%20building%2C%20genuine%20smile%2C%20natural%20outdoor%20lighting%2C%20authentic%20customer%20photo%20style%2C%20contemporary%20architecture%20in%20background%2C%20professional%20photography&width=300&height=300&seq=201&orientation=squarish'
    },
    {
      name: 'Сергей Борисов',
      date: '22 июля 2024',
      rating: 5,
      text: 'Получили свою баню 8х2.5 м 🙂, очень довольны! Ребята выполнили всё в срок, на всех этапах мы получали ответы на все наши вопросы. Задача была сделать баню-домик, чтобы мы уже сейчас могли приезжать и спокойно оставаться несколько дней жить в ней. Качество баньки на высшем уровне!',
      image: 'https://readdy.ai/api/search-image?query=realistic%20portrait%20of%20satisfied%20middle%20aged%20russian%20man%20near%20modern%20sauna%20house%2C%20genuine%20happy%20expression%2C%20natural%20outdoor%20lighting%2C%20authentic%20customer%20photo%20style%2C%20contemporary%20building%20in%20background%2C%20professional%20photography&width=300&height=300&seq=202&orientation=squarish'
    },
    {
      name: 'Фёдор Михайлов',
      date: '30 июня 2024',
      rating: 5,
      text: 'Выбирали из нескольких компаний и решили заказывать в Baths&Home Module. Отличная банька за свои деньги. Выход с терассы в бассейн/купель это лучшее решение). При заказе не стесняйтесь воплощать свои задумки и следуйте советам менеджера.',
      image: 'https://readdy.ai/api/search-image?query=realistic%20portrait%20of%20happy%20russian%20man%20near%20modern%20wooden%20house%20with%20terrace%2C%20genuine%20satisfied%20expression%2C%20natural%20outdoor%20lighting%2C%20authentic%20customer%20photo%20style%2C%20contemporary%20architecture%20in%20background%2C%20professional%20photography&width=300&height=300&seq=203&orientation=squarish'
    },
    {
      name: 'Роберт Атаян',
      date: '21 января 2024',
      rating: 5,
      text: 'Выбор строительной компании - дело достаточно не простое и долгое, как я думал. Но у нас произошло все очень быстро и легко. Понравилось качество выставочного образца, выбрали купель на выставке и в этот же день оформили заказ. Баней довольны!',
      image: 'https://readdy.ai/api/search-image?query=realistic%20portrait%20of%20satisfied%20middle%20aged%20man%20near%20modern%20sauna%20building%2C%20genuine%20happy%20smile%2C%20natural%20outdoor%20lighting%2C%20authentic%20customer%20photo%20style%2C%20contemporary%20architecture%20in%20background%2C%20professional%20photography&width=300&height=300&seq=204&orientation=squarish'
    },
    {
      name: 'Карина Смирнова',
      date: '28 октября 2023',
      rating: 5,
      text: 'Прошло уже более года, как мы стали обладателем прекрасной бани. Могу смело заявить, что баня полностью оправдала наши ожидания. Были большие переживания, что зимой будет холодно, однако не так. В бане тепло, оставляли даже гостей ночевать. Всем рекомендую!',
      image: 'https://readdy.ai/api/search-image?query=realistic%20portrait%20of%20happy%20russian%20woman%20near%20wooden%20sauna%20in%20winter%2C%20genuine%20smile%2C%20snow%20in%20background%2C%20natural%20outdoor%20lighting%2C%20authentic%20customer%20photo%20style%2C%20warm%20atmosphere%2C%20professional%20photography&width=300&height=300&seq=205&orientation=squarish'
    },
    {
      name: 'Дмитрий Волков',
      date: '15 сентября 2023',
      rating: 5,
      text: 'Заказывали дом в стиле барн. Результат превзошел все ожидания! Качество материалов отличное, сборка быстрая и аккуратная. Особенно порадовала работа менеджера - всегда на связи, помог с выбором всех опций. Дом получился именно таким, как мы мечтали!',
      image: 'https://readdy.ai/api/search-image?query=realistic%20portrait%20of%20satisfied%20russian%20man%20near%20modern%20barn%20style%20house%2C%20genuine%20happy%20expression%2C%20natural%20outdoor%20lighting%2C%20authentic%20customer%20photo%20style%2C%20contemporary%20architecture%20in%20background%2C%20professional%20photography&width=300&height=300&seq=206&orientation=squarish'
    }
  ];

  return (
    <section className="py-20 bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4 transition-colors duration-300">
            Счастливые владельцы домов Baths&Home Module делятся впечатлениями
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 transition-colors duration-300">
            Более 1000 довольных клиентов по всей России
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <div key={index} className="bg-white dark:bg-gray-800 rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-all duration-300">
              <div className="p-6">
                <div className="flex items-start gap-4 mb-4">
                  <img
                    src={review.image}
                    alt={review.name}
                    className="w-16 h-16 rounded-full object-cover object-top"
                  />
                  <div className="flex-1">
                    <h3 className="font-bold text-gray-900 dark:text-white mb-1 transition-colors duration-300">{review.name}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-2 transition-colors duration-300">{review.date}</p>
                    <div className="flex gap-1">
                      {[...Array(review.rating)].map((_, i) => (
                        <i key={i} className="ri-star-fill text-yellow-400 text-sm"></i>
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed transition-colors duration-300">
                  {review.text}
                </p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <a 
            href="https://yandex.ru/maps" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-block bg-stone-800 dark:bg-stone-700 text-white px-8 py-3 rounded-lg hover:bg-stone-900 dark:hover:bg-stone-600 transition-colors whitespace-nowrap cursor-pointer"
          >
            Больше отзывов на Яндекс Картах
          </a>
        </div>
      </div>
    </section>
  );
};

export default ReviewsSection;
