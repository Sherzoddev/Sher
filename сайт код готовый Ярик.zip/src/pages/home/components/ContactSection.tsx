
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import ConsultationModal from '../../../components/base/ConsultationModal';

const ContactSection: React.FC = () => {
  const navigate = useNavigate();
  const [isConsultationModalOpen, setIsConsultationModalOpen] = useState(false);

  const handleShowroomVisit = () => {
    setIsConsultationModalOpen(true);
  };

  return (
    <>
      <section className="py-20 bg-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
              Посмотрите готовый дом своими глазами
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              У нас есть выставочный дом и баня, куда вы можете приехать, пройтись по комнатам, потрогать материалы и оценить планировку. Это лучший способ убедиться в качестве и надёжности Плотник
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Реальный объект, а не красивые картинки</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Честные ответы на все ваши вопросы прямо на месте</span>
                </li>
                <li className="flex items-start">
                  <div className="w-2 h-2 bg-green-600 rounded-full mt-2 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Возможность сравнить разные решения и выбрать своё</span>
                </li>
              </ul>
              
              <button 
                onClick={handleShowroomVisit}
                className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
              >
                Записаться на просмотр готового дома
              </button>
            </div>

            {/* Right Content - Image */}
            <div className="relative">
              <img 
                src="https://static.tildacdn.com/tild6636-6636-4033-b031-663132396637/noroot.png"
                alt="Выставочный модульный дом"
                className="w-full h-auto rounded-xl shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      <ConsultationModal 
        isOpen={isConsultationModalOpen}
        onClose={() => setIsConsultationModalOpen(false)}
      />
    </>
  );
};

export default ContactSection;
