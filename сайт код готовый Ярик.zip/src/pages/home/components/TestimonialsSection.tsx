
import React from 'react';

const TestimonialsSection: React.FC = () => {
  const testimonials = [
    {
      videoId: "456240478",
      title: "Отзыв семьи Ивановых"
    },
    {
      videoId: "456240223", 
      title: "Отзыв о строительстве дома"
    },
    {
      videoId: "456240213",
      title: "Впечатления от готового дома"
    },
    {
      videoId: "456240294",
      title: "Отзыв о качестве работ"
    }
  ];

  return (
    <section className="py-20 bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
            Счастливые владельцы домов HUTS делятся впечатлениями
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Видеоотзывы о том, как меняется жизнь, когда мечта о доме становится реальностью
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white rounded-xl overflow-hidden shadow-lg">
              <div className="relative aspect-video">
                <iframe
                  src={`https://vk.com/video_ext.php?oid=-119716720&id=${testimonial.videoId}&color=ffffff1&hd=2&js_api=1`}
                  width="100%"
                  height="100%"
                  frameBorder="0"
                  allowFullScreen
                  allow="clipboard-write; autoplay; encrypted-media; fullscreen; picture-in-picture; screen-wake-lock;"
                  className="w-full h-full"
                  title={testimonial.title}
                />
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <a 
            href="https://vkvideo.ru/@huts_tmn"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
          >
            Смотреть больше отзывов
          </a>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
