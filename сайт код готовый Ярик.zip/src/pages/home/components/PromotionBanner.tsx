
import React from 'react';

const PromotionBanner: React.FC = () => {
  return (
    <section className="bg-gray-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold mb-6">
              Фундамент в подарок — при заказе до конца месяца!
            </h2>
            <p className="text-xl mb-8 text-gray-300">
              Экономьте до 200 000 ₽ — мы берём фундамент на себя.
            </p>
            <button className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-colors whitespace-nowrap cursor-pointer">
              Получить подарок
            </button>
          </div>

          {/* Right Content - Image */}
          <div className="relative">
            <div 
              className="h-64 lg:h-80 bg-cover bg-center rounded-xl"
              style={{
                backgroundImage: `url('https://readdy.ai/api/search-image?query=concrete%20foundation%20construction%20for%20modular%20house%2C%20construction%20workers%2C%20professional%20building%20process%2C%20modern%20foundation%20work&width=600&height=400&seq=foundation-gift&orientation=landscape')`
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-xl" />
            <div className="absolute bottom-6 left-6 text-white">
              <div className="bg-red-600 text-white px-4 py-2 rounded-lg font-bold text-lg mb-2">
                АКЦИЯ
              </div>
              <p className="text-lg font-semibold">Экономия до 200 000 ₽</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PromotionBanner;
