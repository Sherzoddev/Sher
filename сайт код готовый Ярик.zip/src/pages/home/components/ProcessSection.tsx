import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import ConsultationModal from '../../../components/base/ConsultationModal';

const ProcessSection: React.FC = () => {
  const [isConsultationModalOpen, setIsConsultationModalOpen] = useState(false);

  const steps = [
    {
      number: 1,
      title: "Заявка на сайте",
      description: "Вы оставляете заявку, и мы сразу связываемся, чтобы понять ваши желания и ответить на все вопросы."
    },
    {
      number: 2,
      title: "ПОДБОР И НАСТРОЙКА ПРОЕКТА",
      description: "Покажем готовые решения или адаптируем планировку под ваш образ жизни. Всё прозрачно и наглядно."
    },
    {
      number: 3,
      title: "ДОГОВОР И гарантия",
      description: "Фиксируем стоимость, прописываем сроки и гарантии. Цена не изменится, никаких скрытых платежей."
    },
    {
      number: 4,
      title: "ПРОИЗВОДСТВо под контролем",
      description: "Ваш дом собирается на заводе по отлаженной технологии. Вы всегда в курсе этапов и можете приехать посмотреть."
    },
    {
      number: 5,
      title: "ДОСТАВКА И УСТАНОВКА",
      description: "Мы берём на себя логистику и монтаж. Через 1−2 дня после доставки вы уже получаете готовый дом."
    }
  ];

  const handleApplicationClick = () => {
    setIsConsultationModalOpen(true);
  };

  return (
    <>
      <section className="py-20 bg-gray-900 dark:bg-black transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
              От заявки до заселения — всего 5 шагов
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {steps.map((step, index) => (
              <div key={index} className="bg-white dark:bg-gray-800 rounded-xl p-8 relative transition-colors duration-300">
                {/* Step Number */}
                <div className="absolute -top-4 left-8">
                  <div className="w-12 h-12 bg-stone-800 dark:bg-stone-700 text-white rounded-full flex items-center justify-center font-bold text-xl transition-colors duration-300">
                    {step.number}
                  </div>
                </div>

                <div className="pt-8">
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 uppercase transition-colors duration-300">
                    {step.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 leading-relaxed transition-colors duration-300">
                    {step.description}
                  </p>
                </div>
              </div>
            ))}

            {/* Final Step - Enjoy Your Home */}
            <div className="relative">
              {/* Green Circle - Outside the card */}
              <div className="absolute -top-4 left-8 z-50">
                <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-emerald-600 text-white rounded-full flex items-center justify-center transition-colors duration-300">
                  <i className="ri-home-heart-fill text-2xl"></i>
                </div>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-sm hover:shadow-xl transition-all duration-500 border border-gray-100 dark:border-gray-700 overflow-hidden relative">
                {/* Фоновое изображение счастливой семьи */}
                <div 
                  className="absolute inset-0 bg-cover bg-center opacity-15 pointer-events-none z-0"
                  style={{
                    backgroundImage: `url('https://readdy.ai/api/search-image?query=happy%20family%20standing%20in%20front%20of%20their%20new%20modern%20modular%20house%2C%20smiling%20parents%20with%20children%2C%20warm%20natural%20lighting%2C%20joyful%20atmosphere%2C%20contemporary%20home%20exterior%2C%20professional%20photography%20style%2C%20genuine%20happiness%2C%20simple%20clean%20background&width=400&height=600&seq=happy-family-home-process&orientation=portrait')`
                  }}
                />

                {/* Content */}
                <div className="relative z-10 pt-6">
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4 transition-colors duration-300">
                    Наслаждайтесь своим домом
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 leading-relaxed transition-colors duration-300">
                    Ваш дом готов! Заезжайте и начинайте создавать счастливые воспоминания в комфортном пространстве, созданном специально для вас и вашей семьи.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center">
            <div className="bg-white dark:bg-gray-800 rounded-xl p-8 max-w-md mx-auto transition-colors duration-300">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4 transition-colors duration-300">
                5 шагов — и вы живёте в новом доме!
              </h3>
              <button 
                onClick={handleApplicationClick}
                className="w-full bg-stone-800 hover:bg-stone-900 dark:bg-stone-700 dark:hover:bg-stone-600 text-white px-8 py-4 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
              >
                Оставить заявку
              </button>
            </div>
          </div>
        </div>
      </section>

      <ConsultationModal 
        isOpen={isConsultationModalOpen}
        onClose={() => setIsConsultationModalOpen(false)}
      />
    </>
  );
};

export default ProcessSection;
