import React, { useState } from 'react';
import ConsultationModal from '../../../components/base/ConsultationModal';

const ExteriorFinishSection: React.FC = () => {
  const [isConsultationModalOpen, setIsConsultationModalOpen] = useState(false);

  const finishOptions = [
    {
      name: 'Имитация бруса',
      price: 'от 350 ₽/м²',
      description: 'Натуральная древесина, создает уютный традиционный вид',
      image: 'https://readdy.ai/api/search-image?query=wooden%20house%20exterior%20with%20timber%20imitation%20siding%2C%20natural%20wood%20texture%2C%20horizontal%20planks%2C%20rustic%20style%2C%20close-up%20detail%2C%20natural%20lighting&width=400&height=300&seq=201&orientation=landscape',
      features: ['Экологично', 'Дышащий материал', 'Классический вид']
    },
    {
      name: 'Планкен',
      price: 'от 450 ₽/м²',
      description: 'Современная отделка с вентилируемым фасадом',
      image: 'https://readdy.ai/api/search-image?query=modern%20house%20exterior%20with%20planken%20wood%20siding%2C%20contemporary%20facade%2C%20horizontal%20wooden%20planks%2C%20minimalist%20design%2C%20natural%20wood%20finish&width=400&height=300&seq=202&orientation=landscape',
      features: ['Вентилируемый фасад', 'Долговечность', 'Современный стиль']
    },
    {
      name: 'Металлосайдинг',
      price: 'от 280 ₽/м²',
      description: 'Практичное и долговечное решение',
      image: 'https://readdy.ai/api/search-image?query=house%20exterior%20with%20metal%20siding%2C%20dark%20metal%20panels%2C%20contemporary%20architecture%2C%20durable%20facade%2C%20modern%20building%20material&width=400&height=300&seq=203&orientation=landscape',
      features: ['Не требует ухода', 'Пожаробезопасность', 'Широкая палитра']
    },
    {
      name: 'Фиброцементные панели',
      price: 'от 520 ₽/м²',
      description: 'Премиальная отделка с имитацией различных текстур',
      image: 'https://readdy.ai/api/search-image?query=modern%20house%20exterior%20with%20fiber%20cement%20panels%2C%20contemporary%20facade%2C%20textured%20panels%2C%20premium%20finish%2C%20architectural%20detail&width=400&height=300&seq=204&orientation=landscape',
      features: ['Имитация камня/дерева', 'Влагостойкость', 'Премиум качество']
    },
    {
      name: 'Блок-хаус',
      price: 'от 380 ₽/м²',
      description: 'Имитация бревенчатого сруба',
      image: 'https://readdy.ai/api/search-image?query=wooden%20house%20exterior%20with%20block%20house%20siding%2C%20log%20cabin%20imitation%2C%20rounded%20wooden%20planks%2C%20traditional%20style%2C%20natural%20wood%20texture&width=400&height=300&seq=205&orientation=landscape',
      features: ['Эффект бревна', 'Теплоизоляция', 'Традиционный стиль']
    },
    {
      name: 'Термодерево',
      price: 'от 680 ₽/м²',
      description: 'Обработанная древесина с повышенной стойкостью',
      image: 'https://readdy.ai/api/search-image?query=modern%20house%20exterior%20with%20thermally%20modified%20wood%20siding%2C%20dark%20wood%20finish%2C%20premium%20facade%2C%20contemporary%20architecture%2C%20natural%20material&width=400&height=300&seq=206&orientation=landscape',
      features: ['Не гниет', 'Стабильность', 'Элитный вид']
    }
  ];

  const handleFinishSelect = () => {
    setIsConsultationModalOpen(true);
  };

  return (
    <>
      <section className="py-20 bg-white dark:bg-gray-900 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4 transition-colors duration-300">
              Варианты внешней отделки
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto transition-colors duration-300">
              Выберите идеальный вариант отделки для вашего дома или бани. Все материалы адаптированы для российского климата
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {finishOptions.map((option, index) => (
              <div key={index} className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300">
                <div className="relative">
                  <img
                    src={option.image}
                    alt={option.name}
                    className="w-full h-48 object-cover object-top"
                  />
                  <div className="absolute top-4 right-4 bg-stone-800 dark:bg-stone-700 text-white px-4 py-2 rounded-lg font-bold transition-colors duration-300">
                    {option.price}
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2 transition-colors duration-300">
                    {option.name}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 transition-colors duration-300">
                    {option.description}
                  </p>
                  
                  <div className="space-y-2 mb-4">
                    {option.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <i className="ri-check-line text-stone-700 dark:text-stone-400 transition-colors duration-300"></i>
                        <span className="text-sm text-gray-700 dark:text-gray-300 transition-colors duration-300">{feature}</span>
                      </div>
                    ))}
                  </div>
                  
                  <button 
                    onClick={handleFinishSelect}
                    className="w-full bg-stone-800 dark:bg-stone-700 text-white py-2 px-4 rounded-lg hover:bg-stone-900 dark:hover:bg-stone-600 transition-colors whitespace-nowrap cursor-pointer"
                  >
                    Выбрать отделку
                  </button>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-12 bg-stone-50 dark:bg-gray-800 rounded-xl p-8 text-center transition-colors duration-300">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4 transition-colors duration-300">
              Не можете определиться?
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6 transition-colors duration-300">
              Наши специалисты помогут подобрать оптимальный вариант отделки с учетом вашего бюджета и пожеланий
            </p>
            <button 
              onClick={handleFinishSelect}
              className="bg-stone-800 dark:bg-stone-700 text-white px-8 py-3 rounded-lg hover:bg-stone-900 dark:hover:bg-stone-600 transition-colors whitespace-nowrap cursor-pointer"
            >
              Получить консультацию
            </button>
          </div>
        </div>
      </section>

      <ConsultationModal 
        isOpen={isConsultationModalOpen}
        onClose={() => setIsConsultationModalOpen(false)}
      />
    </>
  );
};

export default ExteriorFinishSection;
