import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const HeroSection: React.FC = () => {
  const navigate = useNavigate();
  const [showCatalogModal, setShowCatalogModal] = useState(false);
  const [catalogFormData, setCatalogFormData] = useState({ name: '', phone: '', email: '' });
  const [catalogSubmitting, setCatalogSubmitting] = useState(false);
  const [catalogMessage, setCatalogMessage] = useState('');

  const handleModularHousesClick = () => {
    navigate('/modulnye-doma');
  };

  const handleDvumodulnyeClick = () => {
    navigate('/dvumodulnye');
  };

  const handleModularSaunaClick = () => {
    navigate('/odnomodulnye-bani');
  };

  const handleCatalogSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setCatalogSubmitting(true);
    
    try {
      const formDataToSend = new FormData();
      formDataToSend.append('name', catalogFormData.name);
      formDataToSend.append('phone', catalogFormData.phone);
      formDataToSend.append('email', catalogFormData.email);
      
      const response = await fetch('https://readdy.ai/api/form/d4ipvm71vras6h6ft36g', {
        method: 'POST',
        body: formDataToSend
      });
      
      if (response.ok) {
        setCatalogMessage('Спасибо! Каталог будет отправлен на вашу почту в течение 5 минут.');
        setCatalogFormData({ name: '', phone: '', email: '' });
        setTimeout(() => {
          setShowCatalogModal(false);
          setCatalogMessage('');
        }, 3000);
      } else {
        setCatalogMessage('Произошла ошибка. Попробуйте еще раз.');
      }
    } catch (error) {
      setCatalogMessage('Произошла ошибка. Попробуйте еще раз.');
    } finally {
      setCatalogSubmitting(false);
    }
  };

  const handleCatalogInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setCatalogFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <>
      <section className="relative min-h-screen bg-gradient-to-br from-stone-900 via-stone-800 to-neutral-900 flex items-center">
        {/* Background Image */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
          style={{
            backgroundImage: `url('https://static.readdy.ai/image/0cf44aa0cc15a2a90aea4d375f9c5b69/ccfa0ccd9fd5baba7bfe6875f61930bd.png')`
          }}
        />
        
        <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            {/* Left Content */}
            <div className="text-white">
              <h1 className="text-3xl sm:text-4xl lg:text-6xl font-bold mb-4 sm:mb-6 leading-tight">
                Ваш дом мечты за 30 дней под ключ с гарантией
              </h1>
              <p className="text-lg sm:text-xl lg:text-2xl mb-6 sm:mb-8 text-gray-300">
                Модульные дома и бани вологодского производства с установкой за один день. С доставкой по всей России
              </p>
              <div className="flex flex-col gap-4">
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link 
                    to="/contacts"
                    className="w-full bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-xl font-bold text-lg transition-all transform hover:scale-105 cursor-pointer inline-flex items-center justify-center whitespace-nowrap"
                  >
                    Получить консультацию
                  </Link>
                  <button
                    onClick={() => setShowCatalogModal(true)}
                    className="w-full bg-white/10 hover:bg-white/20 backdrop-blur-sm text-white border-2 border-white/30 px-8 py-4 rounded-xl font-bold text-lg transition-all cursor-pointer inline-flex items-center justify-center gap-2 whitespace-nowrap"
                  >
                    <i className="ri-mail-line"></i>
                    Получить каталог
                  </button>
                </div>
                <Link 
                  to="/catalog"
                  className="w-full bg-white text-slate-900 hover:bg-gray-100 px-8 py-4 rounded-xl font-bold text-lg transition-all cursor-pointer inline-flex items-center justify-center gap-2 whitespace-nowrap"
                >
                  <i className="ri-book-open-line"></i>
                  Смотреть каталог
                </Link>
              </div>
            </div>

            {/* Right Content - House Categories */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 mt-8 lg:mt-0">
              {/* Модульные дома */}
              <div 
                onClick={handleModularHousesClick}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-4 sm:p-6 hover:bg-white/20 transition-all cursor-pointer touch-manipulation active:scale-95"
              >
                <div 
                  className="h-24 sm:h-32 bg-cover bg-center rounded-lg mb-3 sm:mb-4"
                  style={{
                    backgroundImage: `url('https://readdy.ai/api/search-image?query=modern%20modular%20house%20exterior%20view%2C%20wooden%20frame%20construction%2C%20contemporary%20design%2C%20clean%20lines%2C%20natural%20materials&width=400&height=300&seq=modular-house&orientation=landscape')`
                  }}
                />
                <h3 className="text-white text-lg sm:text-xl font-semibold mb-1 sm:mb-2">Модульные дома</h3>
                <p className="text-gray-300 text-sm">От 30 до 104 м²</p>
              </div>

              {/* Двумодульные */}
              <div 
                onClick={handleDvumodulnyeClick}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-4 sm:p-6 hover:bg-white/20 transition-all cursor-pointer touch-manipulation active:scale-95"
              >
                <div 
                  className="h-24 sm:h-32 bg-cover bg-center rounded-lg mb-3 sm:mb-4"
                  style={{
                    backgroundImage: `url('https://readdy.ai/api/search-image?query=modern%20two-module%20bathhouse%20sauna%20exterior%20view%2C%20wooden%20construction%2C%20contemporary%20design%20with%20two%20connected%20modules%2C%20natural%20materials&width=400&height=300&seq=dvumod-hero&orientation=landscape')`
                  }}
                />
                <h3 className="text-white text-lg sm:text-xl font-semibold mb-1 sm:mb-2">Двумодульные</h3>
                <p className="text-gray-300 text-sm">Просторные решения</p>
              </div>

              {/* Модульные бани */}
              <div 
                onClick={handleModularSaunaClick}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-4 sm:p-6 hover:bg-white/20 transition-all cursor-pointer touch-manipulation active:scale-95"
              >
                <div 
                  className="h-24 sm:h-32 bg-cover bg-center rounded-lg mb-3 sm:mb-4"
                  style={{
                    backgroundImage: `url('https://readdy.ai/api/search-image?query=modern%20modular%20sauna%20bathhouse%20exterior%2C%20wooden%20construction%2C%20traditional%20Russian%20banya%20design%2C%20natural%20materials&width=400&height=300&seq=modular-sauna&orientation=landscape')`
                  }}
                />
                <h3 className="text-white text-lg sm:text-xl font-semibold mb-1 sm:mb-2">Модульные бани</h3>
                <p className="text-gray-300 text-sm">Готовые решения</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Catalog Modal */}
      {showCatalogModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full">
            <div className="p-8">
              <div className="flex justify-between items-start mb-6">
                <h2 className="text-2xl font-bold text-slate-900">Заказать электронный каталог</h2>
                <button
                  onClick={() => setShowCatalogModal(false)}
                  className="w-10 h-10 flex items-center justify-center cursor-pointer hover:bg-gray-100 rounded-full transition-colors"
                >
                  <i className="ri-close-line text-gray-500 text-xl"></i>
                </button>
              </div>

              {catalogMessage && (
                <div className={`mb-6 p-4 rounded-lg ${catalogMessage.includes('Спасибо') ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                  {catalogMessage}
                </div>
              )}

              <form onSubmit={handleCatalogSubmit} className="space-y-4" data-readdy-form id="hero-catalog-form">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Ваше имя *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={catalogFormData.name}
                    onChange={handleCatalogInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Имя"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Телефон *
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={catalogFormData.phone}
                    onChange={handleCatalogInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="+7 (000) 000-00-00"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Электронная почта *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={catalogFormData.email}
                    onChange={handleCatalogInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="email@example.com"
                    required
                  />
                </div>
                <button
                  type="submit"
                  disabled={catalogSubmitting}
                  className="w-full bg-slate-900 hover:bg-slate-800 disabled:bg-gray-400 text-white px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
                >
                  {catalogSubmitting ? 'Отправляем...' : 'Получить каталог'}
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default HeroSection;
