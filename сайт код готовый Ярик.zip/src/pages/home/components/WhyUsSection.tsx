import React from 'react';

const WhyUsSection: React.FC = () => {
  const reasons = [
    {
      icon: 'ri-time-line',
      title: 'Быстрое строительство',
      description: 'Изготовление за 30-90 дней в зависимости от площади объекта. Монтаж на участке всего лишь за 1-3 дня.'
    },
    {
      icon: 'ri-shield-check-line',
      title: 'Гарантия качества',
      description: 'Предоставляем гарантию 2 года на весь дом и 10 лет на несущий силовой каркас.'
    },
    {
      icon: 'ri-money-dollar-circle-line',
      title: 'Прозрачная цена',
      description: 'Фиксированная стоимость без\u00A0скрытых платежей. Цена в\u00A0договоре остаётся неизменной.'
    },
    {
      icon: 'ri-leaf-line',
      title: 'Экологичность',
      description: 'Используем только натуральные и безопасные материалы для здоровья вашей семьи.'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-white dark:from-gray-900 dark:to-gray-800 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-4xl font-bold text-center text-gray-900 dark:text-white mb-16 transition-colors duration-300">
          Почему нам доверяют сотни семей
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {reasons.map((reason, index) => (
            <div key={index} className="bg-white dark:bg-gray-800 rounded-xl p-6 hover:shadow-xl transition-all duration-300 border border-gray-200 dark:border-gray-700">
              <div className="w-16 h-16 flex items-center justify-center bg-gradient-to-br from-stone-100 to-stone-200 dark:from-stone-700 dark:to-stone-800 rounded-full mb-4 transition-colors duration-300">
                <i className={`${reason.icon} text-3xl text-stone-700 dark:text-stone-200`}></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3 transition-colors duration-300">
                {reason.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-300 transition-colors duration-300">
                {reason.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyUsSection;
