
import React from 'react';

const SocialSection: React.FC = () => {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
              Будьте ближе к HUTS — следите за новыми проектами и акциями
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              Мы регулярно публикуем обзоры домов, акции и полезные советы
            </p>
            
            <div className="grid grid-cols-2 gap-4">
              <a 
                href="https://t.me/huts_72"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-3 bg-blue-500 hover:bg-blue-600 text-white px-6 py-4 rounded-lg transition-colors cursor-pointer"
              >
                <img src="https://static.tildacdn.com/tild3535-3666-4334-b566-333762323133/icons8--app-50_white.png" alt="Telegram" className="w-6 h-6" />
                <span className="font-medium">telegram</span>
              </a>
              
              <a 
                href="https://api.whatsapp.com/send/?phone=79292696390&text=Добрый+день%21+Хочу+получить+консультацию&type=phone_number&app_absent=0"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-3 bg-green-500 hover:bg-green-600 text-white px-6 py-4 rounded-lg transition-colors cursor-pointer"
              >
                <img src="https://static.tildacdn.com/tild3136-6466-4137-b661-333431626431/icons8-whatsapp-50.png" alt="WhatsApp" className="w-6 h-6" />
                <span className="font-medium">whatsApp</span>
              </a>
              
              <a 
                href="https://vk.com/huts_tmn"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-3 bg-blue-600 hover:bg-blue-700 text-white px-6 py-4 rounded-lg transition-colors cursor-pointer"
              >
                <img src="https://static.tildacdn.com/tild3930-6561-4361-b932-346537666234/icons8-vk-50_1.png" alt="VK" className="w-6 h-6" />
                <span className="font-medium">vk</span>
              </a>
              
              <a 
                href="https://youtube.com/@huts_tmn?si=Uz9OU8VgxXSs0hkq"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-3 bg-red-600 hover:bg-red-700 text-white px-6 py-4 rounded-lg transition-colors cursor-pointer"
              >
                <img src="https://static.tildacdn.com/tild6238-3734-4836-a264-633033646663/icons8-youtube-60.png" alt="YouTube" className="w-6 h-6" />
                <span className="font-medium">youtube</span>
              </a>
            </div>
          </div>

          {/* Right Content - Image */}
          <div className="relative">
            <img 
              src="https://static.tildacdn.com/tild3036-3432-4337-b936-303466346235/-.jpg"
              alt="Социальные сети HUTS"
              className="w-full h-auto rounded-xl shadow-lg"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default SocialSection;
