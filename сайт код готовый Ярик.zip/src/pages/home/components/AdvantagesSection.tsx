
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import ConsultationModal from '../../../components/base/ConsultationModal';

const AdvantagesSection: React.FC = () => {
  const navigate = useNavigate();
  const [isConsultationModalOpen, setIsConsultationModalOpen] = useState(false);

  const advantages = [
    {
      title: "ПОД КЛЮЧ С ГАРАНТИЕЙ 10 ЛЕТ",
      description: "Дом сразу готов к жизни. Мы сдаём объект с полной отделкой, проведённой электрикой, сантехникой и отоплением. Заезжайте и начинайте новую главу уже завтра. Мы даём гарантию 2 года на весь дом и 10 лет на несущий силовой каркас.",
      image: "https://static.tildacdn.com/tild6533-3238-4634-a665-313133383938/4.jpg",
      buttonText: "Подробнее",
      action: () => navigate('/portfolio')
    },
    {
      title: "ЭКОЛОГИЧНЫЕ МАТЕРИАЛЫ",
      description: "Безопасно для вашей семьи. Только экологичные и проверенные материалы, без токсинов и формальдегидов — здоровье и комфорт ваших близких на первом месте.",
      image: "https://static.tildacdn.com/tild3263-3363-4362-a438-393938633931/YDV_3275.jpg",
      buttonText: "Подробнее",
      action: () => setIsConsultationModalOpen(true)
    },
    {
      title: "Скорость и надежость",
      description: "Ваш дом — без долгостроя. Производство на заводе исключает ошибки и задержки, а установка занимает всего 1−2 дня. Вы получаете готовый дом без лишних нервов и ожиданий.",
      image: "https://static.tildacdn.com/tild3832-3936-4362-a434-386531363561/photo_2025-07-10_09-.jpg",
      buttonText: "Подробнее",
      action: () => navigate('/portfolio')
    },
    {
      title: "КРУГЛОГОДИЧНОЕ ПРОЖИВАНИЕ",
      description: "Тепло зимой, прохладно летом. Мы используем утеплители по стандартам северных регионов. Ваш дом будет комфортным даже при -45 °C — для настоящей жизни круглый год.",
      image: "https://static.tildacdn.com/tild6263-6366-4837-a364-313631616532/DJI_0402--NR_1.jpg",
      buttonText: "Подробнее",
      action: () => setIsConsultationModalOpen(true)
    },
    {
      title: "ИНДИВИДУАЛЬНЫЙ ПРОЕКТ",
      description: "Дом под ваш образ жизни. Забудьте про одинаковые коробки. Мы разрабатываем проект, который отражает ваш стиль, ритм и мечты.",
      image: "https://static.tildacdn.com/tild6436-6562-4232-b562-653230366239/YDV_3276.jpg",
      buttonText: "Подробнее",
      action: () => navigate('/calculator')
    },
    {
      title: "ПРОИЗВОДИМ КРУГЛЫЙ ГОД",
      description: "Заказывайте в любое время года! Производство в отапливаемых цехах и установка за 1-2 дня даже зимой. Пока другие ждут весны — мы строим ваш дом с гарантией качества независимо от сезона.",
      image: "https://readdy.ai/api/search-image?query=Modern%20modular%20house%20construction%20site%20in%20winter%20snow%2C%20workers%20installing%20prefabricated%20modules%20with%20crane%2C%20heated%20factory%20workshop%20in%20background%2C%20professional%20construction%20equipment%2C%20snowy%20landscape%2C%20bright%20daylight%2C%20industrial%20photography%20style%2C%20clean%20simple%20background%20emphasizing%20year-round%20construction%20capability&width=400&height=300&seq=winter-construction-advantage&orientation=landscape",
      buttonText: "Подробнее",
      action: () => setIsConsultationModalOpen(true)
    }
  ];

  return (
    <>
      <section className="py-20 bg-neutral-900 dark:bg-black transition-colors duration-300 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-6">
              Наши преимущества
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 relative">
            {advantages.map((advantage, index) => (
              <div 
                key={index}
                className="group relative bg-white dark:bg-gray-800 rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2"
              >
                <div className="relative h-64 overflow-hidden">
                  <img 
                    src={advantage.image}
                    alt={advantage.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
                </div>
                
                <div className="p-6 relative z-10">
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-3 uppercase transition-colors duration-300">
                    {advantage.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed mb-4 transition-colors duration-300">
                    {advantage.description}
                  </p>
                  <button 
                    onClick={advantage.action}
                    className="w-full bg-stone-800 dark:bg-stone-700 text-white py-2 px-4 rounded-lg hover:bg-stone-900 dark:hover:bg-stone-600 transition-colors whitespace-nowrap cursor-pointer"
                  >
                    {advantage.buttonText}
                  </button>
                </div>
              </div>
            ))}
            
            {/* Зеленый кружочек вынесен за пределы карточек */}
            <div className="absolute -top-8 -right-8 w-32 h-32 bg-green-500 rounded-full opacity-20 blur-2xl pointer-events-none" style={{ zIndex: 9999 }}></div>
          </div>
        </div>
      </section>

      <ConsultationModal 
        isOpen={isConsultationModalOpen}
        onClose={() => setIsConsultationModalOpen(false)}
      />
    </>
  );
};

export default AdvantagesSection;
