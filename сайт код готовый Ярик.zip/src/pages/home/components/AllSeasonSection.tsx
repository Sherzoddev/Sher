import React from 'react';

const AllSeasonSection: React.FC = () => {
  return (
    <section className="py-20 bg-white dark:bg-black transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl">
          {/* Background Image */}
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: `url('https://readdy.ai/api/search-image?query=modern%20modular%20house%20construction%20in%20winter%20snow%2C%20workers%20installing%20prefabricated%20building%20modules%20in%20snowy%20weather%2C%20professional%20construction%20site%20with%20crane%20and%20equipment%2C%20cold%20season%20building%20process%2C%20industrial%20winter%20landscape%20with%20white%20snow%20and%20construction%20machinery&width=1400&height=600&seq=allseason-bg&orientation=landscape')`
            }}
          />
          
          {/* Dark Overlay */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/70 to-black/60" />
          
          {/* Content */}
          <div className="relative z-10 py-16 px-8 lg:px-16">
            <div className="max-w-3xl">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 flex items-center justify-center bg-green-600 rounded-full">
                  <i className="ri-calendar-check-line text-3xl text-white"></i>
                </div>
                <h2 className="text-3xl lg:text-5xl font-bold text-white">
                  Производим и устанавливаем круглый год
                </h2>
              </div>
              
              <p className="text-xl lg:text-2xl text-gray-200 mb-8 leading-relaxed">
                Изготовление за 30-90 дней в зависимости от площади объекта. Монтаж на участке всего лишь за 1-3 дня.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg flex-shrink-0">
                    <i className="ri-snowflake-line text-2xl text-white"></i>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white mb-2">Зимнее производство</h3>
                    <p className="text-gray-300 text-sm">
                      Заводское производство в отапливаемых цехах — качество не зависит от погоды
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg flex-shrink-0">
                    <i className="ri-truck-line text-2xl text-white"></i>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white mb-2">Установка за 1-2 дня</h3>
                    <p className="text-gray-300 text-sm">
                      Быстрый монтаж готовых модулей даже при минусовой температуре
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg flex-shrink-0">
                    <i className="ri-shield-check-line text-2xl text-white"></i>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white mb-2">Гарантия качества</h3>
                    <p className="text-gray-300 text-sm">
                      Все материалы адаптированы для работы в любых погодных условиях
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-lg flex-shrink-0">
                    <i className="ri-time-line text-2xl text-white"></i>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white mb-2">Без задержек</h3>
                    <p className="text-gray-300 text-sm">
                      Соблюдаем сроки независимо от сезона — ваш дом будет готов вовремя
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="bg-green-600/20 backdrop-blur-sm border-2 border-green-500/50 rounded-xl p-6">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 flex items-center justify-center bg-green-600 rounded-full flex-shrink-0">
                    <i className="ri-information-line text-xl text-white"></i>
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-white mb-2">Почему это важно?</h4>
                    <p className="text-gray-200 text-sm leading-relaxed">
                      Многие компании отказываются от зимних заказов или переносят их на весну. Мы работаем круглый год, потому что наше производство находится в отапливаемых цехах, а технология модульного строительства позволяет устанавливать дома даже в мороз. Заказывайте сейчас — не ждите весны!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AllSeasonSection;
