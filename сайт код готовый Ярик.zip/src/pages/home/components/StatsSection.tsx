
import React from 'react';

const StatsSection: React.FC = () => {
  const stats = [
    {
      number: "8",
      label: "лет опыта",
      description: "Мы уже 8 лет проектируем и производим модульные строения"
    },
    {
      number: "150+",
      label: "клиентов",
      description: "Более 150 семей доверили нам строительство"
    },
    {
      number: "10",
      label: "лет гарантии на силовой каркас",
      description: "2 года гарантии на все строения"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-stone-800 via-stone-700 to-neutral-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Почему нам доверяют сотни семей?
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-5xl lg:text-6xl font-bold mb-2 text-white">
                {stat.number}
              </div>
              <div className="text-xl font-semibold text-gray-200 mb-4">
                {stat.label}
              </div>
              <p className="text-base text-gray-300 leading-relaxed">
                {stat.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatsSection;
