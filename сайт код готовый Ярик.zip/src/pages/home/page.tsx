import React from 'react';
import HeroSection from './components/HeroSection';
import WhyUsSection from './components/WhyUsSection';
import AdvantagesSection from './components/AdvantagesSection';
import ProcessSection from './components/ProcessSection';
import ReviewsSection from './components/ReviewsSection';
import StatsSection from './components/StatsSection';
import FAQSection from './components/FAQSection';
import ExteriorFinishSection from './components/ExteriorFinishSection';
import WhatsAppCatalogPopup from '../../components/base/WhatsAppCatalogPopup';

const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
      <HeroSection />
      <WhyUsSection />
      <StatsSection />
      <AdvantagesSection />
      <ExteriorFinishSection />
      <ProcessSection />
      <ReviewsSection />
      <FAQSection />
      <WhatsAppCatalogPopup />
    </div>
  );
};

export default HomePage;
