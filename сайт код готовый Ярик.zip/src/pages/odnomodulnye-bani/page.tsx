import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createClient } from '@supabase/supabase-js';
import ConsultationModal from '../../components/base/ConsultationModal';

const supabase = createClient(
  import.meta.env.VITE_PUBLIC_SUPABASE_URL,
  import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY
);

interface Project {
  id: string;
  title: string;
  category: string;
  price: number;
  area: number;
  dimensions: string;
  description: string;
  features: string[];
  images: string[];
  rooms: string;
  foundation: string;
  walls: string;
  roof: string;
  is_featured: boolean;
}

const OdnomodulnyeBaniPage: React.FC = () => {
  const [isConsultationModalOpen, setIsConsultationModalOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [showBlueprint, setShowBlueprint] = useState(false);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('projects')
      .select('*')
      .eq('category', 'Модульные бани')
      .order('is_featured', { ascending: false })
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Ошибка загрузки проектов:', error);
    } else {
      setProjects(data || []);
    }
    setLoading(false);
  };

  const openProjectModal = (project: Project) => {
    setSelectedProject(project);
    setShowBlueprint(false);
  };

  const closeProjectModal = () => {
    setSelectedProject(null);
    setShowBlueprint(false);
  };

  return (
    <>
      <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
        {/* Hero Section */}
        <section className="py-20 lg:py-32">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-light text-gray-900 dark:text-white mb-6 transition-colors duration-300">
                Одномодульные бани
              </h1>
              <p className="text-xl text-gray-500 dark:text-gray-400 font-light transition-colors duration-300">
                Компактные решения от 12 до 35 м²
              </p>
            </div>
          </div>
        </section>

        {/* Projects Grid */}
        <section className="pb-32">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {projects.map((project) => (
                <div 
                  key={project.id}
                  onClick={() => openProjectModal(project)}
                  className="group cursor-pointer"
                >
                  <div className="relative overflow-hidden aspect-[4/3] mb-6">
                    <img
                      src={project.images[0]}
                      alt={project.title}
                      className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105"
                    />
                  </div>
                  <h3 className="text-xl font-light text-gray-900 dark:text-white mb-3 group-hover:text-gray-600 dark:group-hover:text-gray-300 transition-colors leading-tight">
                    {project.title}
                  </h3>
                  <p className="text-lg text-gray-500 dark:text-gray-400 mb-2 transition-colors duration-300">{project.dimensions}</p>
                  <p className="text-lg text-gray-900 dark:text-white font-medium transition-colors duration-300">{project.price} ₽</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gray-50 dark:bg-gray-800 transition-colors duration-300">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl sm:text-4xl font-light text-gray-900 dark:text-white mb-6 transition-colors duration-300">
              Нужна консультация?
            </h2>
            <p className="text-xl text-gray-500 dark:text-gray-400 mb-10 font-light transition-colors duration-300">
              Свяжитесь с нами для обсуждения вашего проекта
            </p>
            <button
              onClick={() => setIsConsultationModalOpen(true)}
              className="bg-gray-900 dark:bg-gray-700 hover:bg-gray-800 dark:hover:bg-gray-600 text-white px-12 py-4 text-lg font-light transition-colors cursor-pointer whitespace-nowrap"
            >
              Связаться с нами
            </button>
          </div>
        </section>
      </div>

      {/* Project Modal */}
      {selectedProject && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 max-w-6xl w-full max-h-[90vh] overflow-y-auto transition-colors duration-300">
            <div className="p-8 lg:p-12">
              <div className="flex justify-between items-start mb-12">
                <div>
                  <h2 className="text-3xl lg:text-4xl font-light text-gray-900 dark:text-white mb-4 transition-colors duration-300">
                    {selectedProject.title}
                  </h2>
                  <p className="text-xl text-gray-500 dark:text-gray-400 transition-colors duration-300">{selectedProject.dimensions}</p>
                </div>
                <button
                  onClick={closeProjectModal}
                  className="w-12 h-12 flex items-center justify-center cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                >
                  <i className="ri-close-line text-gray-400 dark:text-gray-500 text-2xl"></i>
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
                <div>
                  <img
                    src={showBlueprint ? selectedProject.images[1] : selectedProject.images[0]}
                    alt={selectedProject.title}
                    className="w-full aspect-[4/3] object-cover object-top mb-6"
                  />
                  <div className="flex gap-4">
                    <button
                      onClick={() => setShowBlueprint(false)}
                      className={`flex-1 py-3 text-center font-light transition-colors cursor-pointer whitespace-nowrap ${
                        !showBlueprint 
                          ? 'bg-gray-900 dark:bg-gray-700 text-white' 
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                      }`}
                    >
                      Фото
                    </button>
                    <button
                      onClick={() => setShowBlueprint(true)}
                      className={`flex-1 py-3 text-center font-light transition-colors cursor-pointer whitespace-nowrap ${
                        showBlueprint 
                          ? 'bg-gray-900 dark:bg-gray-700 text-white' 
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                      }`}
                    >
                      Чертеж
                    </button>
                  </div>
                </div>

                <div className="space-y-8">
                  <div>
                    <p className="text-3xl font-light text-gray-900 dark:text-white mb-6 transition-colors duration-300">
                      {selectedProject.price} ₽
                    </p>
                    <p className="text-lg text-gray-600 dark:text-gray-300 font-light leading-relaxed transition-colors duration-300">
                      {selectedProject.description}
                    </p>
                  </div>

                  <div>
                    <h3 className="text-lg font-light text-gray-900 dark:text-white mb-4 transition-colors duration-300">Помещения</h3>
                    <div className="space-y-2">
                      {selectedProject.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center gap-3">
                          <div className="w-1 h-1 bg-gray-400 dark:bg-gray-500"></div>
                          <span className="text-gray-600 dark:text-gray-300 font-light transition-colors duration-300">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-light text-gray-900 dark:text-white mb-4 transition-colors duration-300">Характеристики</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                        <span className="text-gray-500 dark:text-gray-400 font-light transition-colors duration-300">Фундамент</span>
                        <span className="text-gray-900 dark:text-white font-light transition-colors duration-300">{selectedProject.foundation}</span>
                      </div>
                      <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                        <span className="text-gray-500 dark:text-gray-400 font-light transition-colors duration-300">Стены</span>
                        <span className="text-gray-900 dark:text-white font-light transition-colors duration-300">{selectedProject.walls}</span>
                      </div>
                      <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                        <span className="text-gray-500 dark:text-gray-400 font-light transition-colors duration-300">Кровля</span>
                        <span className="text-gray-900 dark:text-white font-light transition-colors duration-300">{selectedProject.roof}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      closeProjectModal();
                      setIsConsultationModalOpen(true);
                    }}
                    className="w-full bg-gray-900 dark:bg-gray-700 hover:bg-gray-800 dark:hover:bg-gray-600 text-white py-4 text-lg font-light transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Связаться с нами
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <ConsultationModal
        isOpen={isConsultationModalOpen}
        onClose={() => setIsConsultationModalOpen(false)}
      />
    </>
  );
};

export default OdnomodulnyeBaniPage;
