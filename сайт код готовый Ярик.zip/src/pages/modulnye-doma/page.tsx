import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createClient } from '@supabase/supabase-js';
import ConsultationModal from '../../components/base/ConsultationModal';

const supabase = createClient(
  import.meta.env.VITE_PUBLIC_SUPABASE_URL,
  import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY
);

interface Project {
  id: string;
  title: string;
  category: string;
  price: number;
  area: number;
  dimensions: string;
  description: string;
  features: string[];
  images: string[];
  rooms: string;
  foundation: string;
  walls: string;
  roof: string;
  is_featured: boolean;
}

const ModulnyeDomaPage: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('projects')
      .select('*')
      .eq('category', 'Модульные дома')
      .order('is_featured', { ascending: false })
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Ошибка загрузки проектов:', error);
    } else {
      setProjects(data || []);
    }
    setLoading(false);
  };

  return (
    <>
      <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
        {/* Hero - минималистичный */}
        <section className="pt-12 pb-16 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
          <div className="text-center mb-4">
            <span className="text-sm text-neutral-500 dark:text-neutral-400 tracking-wide uppercase transition-colors duration-300">Каталог</span>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-light text-neutral-900 dark:text-white text-center mb-6 tracking-tight transition-colors duration-300">
            Модульные дома
          </h1>
          <p className="text-lg text-neutral-500 dark:text-neutral-400 text-center max-w-xl mx-auto font-light transition-colors duration-300">
            Готовые проекты от 10 до 104 м². Производство 2 месяца. Установка за 1 день.
          </p>
        </section>

        {/* Проекты - чистая сетка */}
        <section className="pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project) => (
              <div 
                key={project.id} 
                className="group cursor-pointer"
                onClick={() => setSelectedProject(project)}
              >
                <div className="aspect-[3/2] overflow-hidden rounded-2xl mb-5 bg-neutral-100 dark:bg-neutral-800 transition-colors duration-300">
                  <img
                    src={project.images[0]}
                    alt={project.title}
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-700 ease-out"
                  />
                </div>
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-medium text-neutral-900 dark:text-white mb-1 transition-colors duration-300">
                      {project.title}
                    </h3>
                    <p className="text-neutral-500 dark:text-neutral-400 text-sm transition-colors duration-300">
                      {project.area} м² · {project.rooms}
                    </p>
                  </div>
                  <p className="text-lg font-medium text-neutral-900 dark:text-white transition-colors duration-300">
                    {(parseInt(project.price.toString()) / 1000000).toFixed(1)} млн ₽
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* CTA - простой */}
        <section className="py-20 bg-neutral-950 dark:bg-neutral-900 transition-colors duration-300">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl sm:text-4xl font-light text-white mb-4">
              Обсудим ваш проект?
            </h2>
            <p className="text-neutral-400 dark:text-neutral-500 mb-10 font-light transition-colors duration-300">
              Бесплатная консультация и расчёт стоимости
            </p>
            <button
              onClick={() => setIsModalOpen(true)}
              className="bg-white dark:bg-neutral-800 text-neutral-900 dark:text-white px-10 py-4 rounded-full font-medium hover:bg-neutral-100 dark:hover:bg-neutral-700 transition-colors cursor-pointer whitespace-nowrap"
            >
              Связаться с нами
            </button>
          </div>
        </section>
      </div>

      {/* Модальное окно проекта */}
      {selectedProject && (
        <div 
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedProject(null)}
        >
          <div 
            className="bg-white dark:bg-gray-800 rounded-3xl max-w-3xl w-full max-h-[85vh] overflow-y-auto transition-colors duration-300"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative">
              <img
                src={selectedProject.images[0]}
                alt={selectedProject.title}
                className="w-full aspect-[16/9] object-cover object-top rounded-t-3xl"
              />
              <button
                onClick={() => setSelectedProject(null)}
                className="absolute top-4 right-4 w-10 h-10 bg-white/90 dark:bg-gray-800/90 backdrop-blur rounded-full flex items-center justify-center cursor-pointer hover:bg-white dark:hover:bg-gray-700 transition-colors"
              >
                <i className="ri-close-line text-xl text-neutral-700 dark:text-neutral-300"></i>
              </button>
            </div>
            
            <div className="p-8">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h2 className="text-2xl font-medium text-neutral-900 dark:text-white mb-1 transition-colors duration-300">
                    {selectedProject.title}
                  </h2>
                  <p className="text-neutral-500 dark:text-neutral-400 transition-colors duration-300">
                    {selectedProject.area} м² · {selectedProject.rooms}
                  </p>
                </div>
                <p className="text-2xl font-medium text-neutral-900 dark:text-white transition-colors duration-300">
                  {parseInt(selectedProject.price.toString()).toLocaleString('ru-RU')} ₽
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="bg-neutral-50 dark:bg-gray-700 rounded-xl p-4 transition-colors duration-300">
                  <p className="text-sm text-neutral-500 dark:text-neutral-400 mb-1 transition-colors duration-300">Фундамент</p>
                  <p className="text-neutral-900 dark:text-white transition-colors duration-300">Свайно-винтовой</p>
                </div>
                <div className="bg-neutral-50 dark:bg-gray-700 rounded-xl p-4 transition-colors duration-300">
                  <p className="text-sm text-neutral-500 dark:text-neutral-400 mb-1 transition-colors duration-300">Утепление</p>
                  <p className="text-neutral-900 dark:text-white transition-colors duration-300">150-200 мм</p>
                </div>
                <div className="bg-neutral-50 dark:bg-gray-700 rounded-xl p-4 transition-colors duration-300">
                  <p className="text-sm text-neutral-500 dark:text-neutral-400 mb-1 transition-colors duration-300">Кровля</p>
                  <p className="text-neutral-900 dark:text-white transition-colors duration-300">Металлочерепица</p>
                </div>
                <div className="bg-neutral-50 dark:bg-gray-700 rounded-xl p-4 transition-colors duration-300">
                  <p className="text-sm text-neutral-500 dark:text-neutral-400 mb-1 transition-colors duration-300">Отделка</p>
                  <p className="text-neutral-900 dark:text-white transition-colors duration-300">Под ключ</p>
                </div>
              </div>

              <button
                onClick={() => {
                  setSelectedProject(null);
                  setIsModalOpen(true);
                }}
                className="w-full bg-neutral-900 dark:bg-neutral-700 text-white py-4 rounded-full font-medium hover:bg-neutral-800 dark:hover:bg-neutral-600 transition-colors cursor-pointer whitespace-nowrap"
              >
                Заказать проект
              </button>
            </div>
          </div>
        </div>
      )}

      <ConsultationModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </>
  );
};

export default ModulnyeDomaPage;
