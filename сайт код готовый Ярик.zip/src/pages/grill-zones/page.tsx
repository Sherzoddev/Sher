
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createClient } from '@supabase/supabase-js';
import ConsultationModal from '../../components/base/ConsultationModal';

const supabase = createClient(
  import.meta.env.VITE_PUBLIC_SUPABASE_URL,
  import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY
);

interface Project {
  id: string;
  title: string;
  category: string;
  price: number;
  area: number;
  dimensions: string;
  description: string;
  features: string[];
  images: string[];
  rooms: string;
  foundation: string;
  walls: string;
  roof: string;
  is_featured: boolean;
}

const GrillZonesPage: React.FC = () => {
  const [isConsultationModalOpen, setIsConsultationModalOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('projects')
      .select('*')
      .in('category', ['Гриль-дома', 'Беседки', 'Хозпостройки'])
      .order('is_featured', { ascending: false })
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Ошибка загрузки проектов:', error);
    } else {
      setProjects(data || []);
    }
    setLoading(false);
  };

  const openModal = (project: Project) => {
    setSelectedProject(project);
    setIsModalOpen(true);
    setCurrentImageIndex(0);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedProject(null);
    setCurrentImageIndex(0);
  };

  const nextImage = () => {
    if (selectedProject) {
      setCurrentImageIndex((prev) => 
        prev === selectedProject.images.length - 1 ? 0 : prev + 1
      );
    }
  };

  const prevImage = () => {
    if (selectedProject) {
      setCurrentImageIndex((prev) => 
        prev === 0 ? selectedProject.images.length - 1 : prev - 1
      );
    }
  };

  return (
    <>
      <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
        {/* Hero Section */}
        <section className="py-20 lg:py-32">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-light text-gray-900 dark:text-white mb-6 transition-colors duration-300">
                Зоны гриль
              </h1>
              <p className="text-xl text-gray-500 dark:text-gray-400 font-light transition-colors duration-300">
                Беседки и барбекю-комплексы от 12 до 35 м²
              </p>
            </div>
          </div>
        </section>

        {/* Projects Grid */}
        <section className="pb-32">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {loading ? (
              <div className="text-center py-20">
                <div className="w-16 h-16 border-4 border-gray-900 dark:border-gray-300 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-gray-600 dark:text-gray-400">Загрузка проектов...</p>
              </div>
            ) : projects.length === 0 ? (
              <div className="text-center py-20">
                <p className="text-xl text-gray-500 dark:text-gray-400">Проекты скоро появятся</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects.map((project) => (
                  <div 
                    key={project.id}
                    onClick={() => openModal(project)}
                    className="group cursor-pointer"
                  >
                    <div className="relative overflow-hidden aspect-[4/3] mb-6">
                      <img
                        src={project.images[0]}
                        alt={project.title}
                        className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105"
                      />
                    </div>
                    <h3 className="text-xl font-light text-gray-900 dark:text-white mb-2 group-hover:text-gray-600 dark:group-hover:text-gray-300 transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-lg text-gray-500 dark:text-gray-400 mb-1 transition-colors duration-300">{project.area} м²</p>
                    <p className="text-lg text-gray-900 dark:text-white transition-colors duration-300">{project.price.toLocaleString('ru-RU')} ₽</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gray-50 dark:bg-gray-800 transition-colors duration-300">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl sm:text-4xl font-light text-gray-900 dark:text-white mb-6 transition-colors duration-300">
              Нужна консультация?
            </h2>
            <p className="text-xl text-gray-500 dark:text-gray-400 mb-10 font-light transition-colors duration-300">
              Свяжитесь с нами для обсуждения вашего проекта
            </p>
            <button
              onClick={() => setIsConsultationModalOpen(true)}
              className="bg-gray-900 dark:bg-gray-700 hover:bg-gray-800 dark:hover:bg-gray-600 text-white px-12 py-4 text-lg font-light transition-colors cursor-pointer whitespace-nowrap"
            >
              Связаться с нами
            </button>
          </div>
        </section>
      </div>

      {/* Project Modal */}
      {isModalOpen && selectedProject && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 max-w-6xl w-full max-h-[90vh] overflow-y-auto transition-colors duration-300">
            <div className="p-8 lg:p-12">
              <div className="flex justify-between items-start mb-12">
                <div>
                  <h2 className="text-3xl lg:text-4xl font-light text-gray-900 dark:text-white mb-4 transition-colors duration-300">
                    {selectedProject.title}
                  </h2>
                  <p className="text-xl text-gray-500 dark:text-gray-400 transition-colors duration-300">{selectedProject.area} м²</p>
                </div>
                <button
                  onClick={closeModal}
                  className="w-12 h-12 flex items-center justify-center cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                >
                  <i className="ri-close-line text-gray-400 dark:text-gray-500 text-2xl"></i>
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
                <div>
                  {/* Image Carousel */}
                  <div className="relative mb-4">
                    <img
                      src={selectedProject.images[currentImageIndex]}
                      alt={`${selectedProject.title} - фото ${currentImageIndex + 1}`}
                      className="w-full aspect-[4/3] object-cover object-top"
                    />
                    
                    {/* Navigation Arrows */}
                    {selectedProject.images.length > 1 && (
                      <>
                        <button
                          onClick={prevImage}
                          className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/90 dark:bg-gray-800/90 hover:bg-white dark:hover:bg-gray-800 rounded-full flex items-center justify-center cursor-pointer transition-all shadow-lg"
                        >
                          <i className="ri-arrow-left-s-line text-2xl text-gray-800 dark:text-white"></i>
                        </button>
                        <button
                          onClick={nextImage}
                          className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/90 dark:bg-gray-800/90 hover:bg-white dark:hover:bg-gray-800 rounded-full flex items-center justify-center cursor-pointer transition-all shadow-lg"
                        >
                          <i className="ri-arrow-right-s-line text-2xl text-gray-800 dark:text-white"></i>
                        </button>
                      </>
                    )}

                    {/* Image Counter */}
                    {selectedProject.images.length > 1 && (
                      <div className="absolute bottom-4 right-4 bg-black/70 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm font-semibold">
                        {currentImageIndex + 1} / {selectedProject.images.length}
                      </div>
                    )}
                  </div>

                  {/* Thumbnail Navigation */}
                  {selectedProject.images.length > 1 && (
                    <div className="flex gap-2 overflow-x-auto pb-2">
                      {selectedProject.images.map((image, index) => (
                        <button
                          key={index}
                          onClick={() => setCurrentImageIndex(index)}
                          className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden cursor-pointer transition-all ${
                            currentImageIndex === index 
                              ? 'ring-4 ring-gray-900 dark:ring-gray-300 scale-105' 
                              : 'opacity-60 hover:opacity-100'
                          }`}
                        >
                          <img
                            src={image}
                            alt={`Миниатюра ${index + 1}`}
                            className="w-full h-full object-cover object-top"
                          />
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div className="space-y-8">
                  <div>
                    <p className="text-3xl font-light text-gray-900 dark:text-white mb-6 transition-colors duration-300">
                      {selectedProject.price.toLocaleString('ru-RU')} ₽
                    </p>
                    <p className="text-lg text-gray-600 dark:text-gray-300 font-light leading-relaxed transition-colors duration-300">
                      {selectedProject.description}
                    </p>
                  </div>

                  {selectedProject.features && selectedProject.features.length > 0 && (
                    <div>
                      <h3 className="text-lg font-light text-gray-900 dark:text-white mb-4 transition-colors duration-300">Особенности</h3>
                      <div className="space-y-2">
                        {selectedProject.features.map((feature, idx) => (
                          <div key={idx} className="flex items-center gap-3">
                            <div className="w-1 h-1 bg-gray-400 dark:bg-gray-500"></div>
                            <span className="text-gray-600 dark:text-gray-300 font-light transition-colors duration-300">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <h3 className="text-lg font-light text-gray-900 dark:text-white mb-4 transition-colors duration-300">Характеристики</h3>
                    <div className="space-y-3">
                      {selectedProject.area && (
                        <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                          <span className="text-gray-500 dark:text-gray-400 font-light transition-colors duration-300">Площадь</span>
                          <span className="text-gray-900 dark:text-white font-light transition-colors duration-300">{selectedProject.area} м²</span>
                        </div>
                      )}
                      {selectedProject.foundation && (
                        <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                          <span className="text-gray-500 dark:text-gray-400 font-light transition-colors duration-300">Фундамент</span>
                          <span className="text-gray-900 dark:text-white font-light transition-colors duration-300">{selectedProject.foundation}</span>
                        </div>
                      )}
                      {selectedProject.walls && (
                        <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                          <span className="text-gray-500 dark:text-gray-400 font-light transition-colors duration-300">Стены</span>
                          <span className="text-gray-900 dark:text-white font-light transition-colors duration-300">{selectedProject.walls}</span>
                        </div>
                      )}
                      {selectedProject.roof && (
                        <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                          <span className="text-gray-500 dark:text-gray-400 font-light transition-colors duration-300">Кровля</span>
                          <span className="text-gray-900 dark:text-white font-light transition-colors duration-300">{selectedProject.roof}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      closeModal();
                      setIsConsultationModalOpen(true);
                    }}
                    className="w-full bg-gray-900 dark:bg-gray-700 hover:bg-gray-800 dark:hover:bg-gray-600 text-white py-4 text-lg font-light transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Связаться с нами
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <ConsultationModal
        isOpen={isConsultationModalOpen}
        onClose={() => setIsConsultationModalOpen(false)}
      />
    </>
  );
};

export default GrillZonesPage;
