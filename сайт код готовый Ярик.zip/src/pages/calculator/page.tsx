import React, { useState } from 'react';

const CalculatorPage: React.FC = () => {
  const [buildingType, setBuildingType] = useState('modular-bath');
  const [houseArea, setHouseArea] = useState(50);
  const [terraceArea, setTerraceArea] = useState(0);
  const [foundation, setFoundation] = useState('pile');
  const [roofing, setRoofing] = useState('flexible-shingle');
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const buildingTypes = [
    { 
      value: 'modular-bath', 
      label: 'Модульная баня', 
      pricePerSqm: 52000,
      icon: 'ri-home-4-line'
    },
    { 
      value: 'frame-bath', 
      label: 'Каркасная баня', 
      pricePerSqm: 53000,
      icon: 'ri-building-line'
    },
    { 
      value: 'modular-house', 
      label: 'Модульный дом', 
      pricePerSqm: 54000,
      icon: 'ri-home-3-line'
    },
    { 
      value: 'frame-house', 
      label: 'Каркасный дом', 
      pricePerSqm: 55000,
      icon: 'ri-home-2-line'
    }
  ];

  const foundationTypes = [
    { value: 'pile', label: 'Свайный фундамент' },
    { value: 'strip', label: 'Ленточный фундамент' },
    { value: 'slab', label: 'Плитный фундамент' },
    { value: 'screw-pile', label: 'Свайно-винтовой фундамент' }
  ];

  const roofingTypes = [
    { value: 'flexible-shingle', label: 'Гибкая черепица' },
    { value: 'metal-profile', label: 'Металлический профнастил С20/21' },
    { value: 'click-fold', label: 'Кликфальц' }
  ];

  const calculatePrice = () => {
    const selectedType = buildingTypes.find(type => type.value === buildingType);
    if (!selectedType) return 0;

    const houseCost = selectedType.pricePerSqm * houseArea;
    const terraceCost = terraceArea > 0 ? 15000 * terraceArea : 0;
    
    return Math.round(houseCost + terraceCost);
  };

  const totalPrice = calculatePrice();
  const selectedType = buildingTypes.find(type => type.value === buildingType);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');

    try {
      const formDataToSend = new URLSearchParams();
      formDataToSend.append('name', formData.name);
      formDataToSend.append('phone', formData.phone);
      formDataToSend.append('email', formData.email);
      formDataToSend.append('buildingType', selectedType?.label || '');
      formDataToSend.append('area', `${houseArea} м²`);
      formDataToSend.append('price', `${totalPrice.toLocaleString()} ₽`);

      const response = await fetch('https://readdy.ai/api/form/d4ir3gj3rief4cfea73g', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formDataToSend.toString()
      });

      if (response.ok) {
        setSubmitStatus('success');
        setFormData({ name: '', phone: '', email: '' });
        setTimeout(() => {
          setShowModal(false);
          setSubmitStatus('idle');
        }, 2000);
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
        <div className="max-w-5xl mx-auto px-4 py-8 sm:py-16">
          <div className="text-center mb-8 sm:mb-16">
            <h1 className="text-3xl sm:text-5xl font-light text-gray-900 dark:text-white mb-4 sm:mb-6">
              Калькулятор стоимости
            </h1>
            <p className="text-base sm:text-xl text-gray-600 dark:text-gray-400 font-light px-4">
              Рассчитайте стоимость вашего будущего дома или бани
            </p>
          </div>

          <div className="bg-gray-50 dark:bg-gray-800 rounded-2xl sm:rounded-3xl p-4 sm:p-12 transition-colors duration-300">
            <div className="space-y-8 sm:space-y-0 sm:grid sm:grid-cols-1 lg:grid-cols-3 sm:gap-12">
              {/* Параметры */}
              <div className="sm:col-span-1 lg:col-span-2 space-y-8 sm:space-y-12">
                
                {/* Тип строения */}
                <div>
                  <h2 className="text-xl sm:text-2xl font-light text-gray-900 dark:text-white mb-4 sm:mb-8">
                    Тип строения
                  </h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                    {buildingTypes.map((type) => (
                      <button
                        key={type.value}
                        onClick={() => setBuildingType(type.value)}
                        className={`p-4 sm:p-6 rounded-xl sm:rounded-2xl border-2 transition-all cursor-pointer touch-manipulation active:scale-95 ${
                          buildingType === type.value
                            ? 'border-gray-900 dark:border-gray-600 bg-white dark:bg-gray-700 shadow-lg'
                            : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                        }`}
                      >
                        <div className="text-left">
                          <div className="text-base sm:text-lg font-medium text-gray-900 dark:text-white">
                            {type.label}
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Площадь дома */}
                <div>
                  <label className="block text-xl sm:text-2xl font-light text-gray-900 dark:text-white mb-4 sm:mb-6">
                    Площадь дома
                  </label>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 mb-4">
                      <span className="text-base sm:text-lg text-gray-600 dark:text-gray-400 flex-shrink-0">Площадь дома:</span>
                      <div className="flex-1"></div>
                      <input
                        type="number"
                        min="10"
                        max="200"
                        step="0.1"
                        value={houseArea}
                        onChange={(e) => setHouseArea(Number(e.target.value))}
                        className="w-20 sm:w-24 px-2 sm:px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg text-center focus:ring-2 focus:ring-gray-900 dark:focus:ring-white focus:border-gray-900 dark:focus:border-white text-base sm:text-base"
                      />
                      <span className="text-base sm:text-lg text-gray-600 dark:text-gray-400 flex-shrink-0">м²</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="200"
                      step="0.1"
                      value={houseArea}
                      onChange={(e) => setHouseArea(Number(e.target.value))}
                      className="w-full h-2 bg-gray-200/50 dark:bg-gray-600/50 rounded-lg appearance-none cursor-pointer slider-thumb"
                    />
                    <div className="flex justify-between text-xs sm:text-sm text-gray-400 dark:text-gray-500">
                      <span>10 м²</span>
                      <span>200 м²</span>
                    </div>
                  </div>
                </div>

                {/* Площадь террасы */}
                <div>
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <span className={`text-base sm:text-lg flex-shrink-0 ${terraceArea > 0 ? 'text-gray-600 dark:text-gray-400' : 'text-gray-400 dark:text-gray-500'}`}>
                        Площадь террасы:
                      </span>
                      <div className="flex-1"></div>
                      <input
                        type="number"
                        min="0"
                        max="50"
                        step="0.1"
                        value={terraceArea}
                        onChange={(e) => setTerraceArea(Number(e.target.value))}
                        className="w-20 sm:w-24 px-2 sm:px-3 py-2 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg text-center focus:ring-2 focus:ring-gray-900 dark:focus:ring-white focus:border-gray-900 dark:focus:border-white text-base sm:text-base"
                      />
                      <span className={`text-base sm:text-lg flex-shrink-0 ${terraceArea > 0 ? 'text-gray-600 dark:text-gray-400' : 'text-gray-400 dark:text-gray-500'}`}>
                        м²
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="50"
                      step="0.1"
                      value={terraceArea}
                      onChange={(e) => setTerraceArea(Number(e.target.value))}
                      className="w-full h-2 bg-gray-200/50 dark:bg-gray-600/50 rounded-lg appearance-none cursor-pointer slider-thumb"
                    />
                    <div className="flex justify-between text-xs sm:text-sm text-gray-400 dark:text-gray-500">
                      <span>0 м²</span>
                      <span>50 м²</span>
                    </div>
                  </div>
                </div>

                {/* Тип фундамента */}
                <div>
                  <label className="block text-xl sm:text-2xl font-light text-gray-900 dark:text-white mb-4 sm:mb-6">
                    Тип фундамента
                  </label>
                  <select
                    value={foundation}
                    onChange={(e) => setFoundation(e.target.value)}
                    className="w-full p-3 sm:p-4 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-xl focus:ring-2 focus:ring-gray-900 dark:focus:ring-white focus:border-gray-900 dark:focus:border-white bg-white text-base sm:text-lg font-light pr-8"
                  >
                    {foundationTypes.map((type) => (
                      <option key={type.value} value={type.value}>{type.label}</option>
                    ))}
                  </select>
                </div>

                {/* Тип кровли */}
                <div>
                  <label className="block text-xl sm:text-2xl font-light text-gray-900 dark:text-white mb-4 sm:mb-6">
                    Тип кровли
                  </label>
                  <select
                    value={roofing}
                    onChange={(e) => setRoofing(e.target.value)}
                    className="w-full p-3 sm:p-4 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-xl focus:ring-2 focus:ring-gray-900 dark:focus:ring-white focus:border-gray-900 dark:focus:border-white bg-white text-base sm:text-lg font-light pr-8"
                  >
                    {roofingTypes.map((type) => (
                      <option key={type.value} value={type.value}>{type.label}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Результат */}
              <div className="sm:col-span-1">
                <div className="sticky top-20 sm:top-8">
                  <div className="bg-white dark:bg-gray-700 rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-lg transition-colors duration-300">
                    <h2 className="text-xl sm:text-2xl font-light text-gray-900 dark:text-white mb-6 sm:mb-8 text-center">
                      Расчет стоимости
                    </h2>

                    <div className="text-center mb-6 sm:mb-8">
                      <div className="text-3xl sm:text-4xl font-light text-gray-900 dark:text-white mb-2">
                        {totalPrice.toLocaleString()} ₽
                      </div>
                      <div className="text-xs sm:text-sm text-gray-500 dark:text-gray-400">
                        Стоимость производства
                      </div>
                      <div className="text-xs text-gray-400 dark:text-gray-500 mt-2">
                        Стоимость работ уже включена в итоговую цену
                      </div>
                    </div>

                    <div className="space-y-3 sm:space-y-4 mb-6 sm:mb-8 text-xs sm:text-sm">
                      <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-600">
                        <span className="text-gray-600 dark:text-gray-400">Тип строения:</span>
                        <span className="font-medium text-gray-900 dark:text-white text-right ml-2">{selectedType?.label}</span>
                      </div>
                      <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-600">
                        <span className="text-gray-600 dark:text-gray-400">Площадь дома:</span>
                        <span className="font-medium text-gray-900 dark:text-white">{houseArea} м²</span>
                      </div>
                      {terraceArea > 0 && (
                        <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-600">
                          <span className="text-gray-600 dark:text-gray-400">Площадь террасы:</span>
                          <span className="font-medium text-gray-900 dark:text-white">{terraceArea} м²</span>
                        </div>
                      )}
                    </div>

                    <div className="space-y-3">
                      <a 
                        href="tel:+79115098818"
                        className="block w-full bg-gray-900 dark:bg-white hover:bg-gray-800 dark:hover:bg-gray-100 text-white dark:text-gray-900 py-3 sm:py-4 px-4 sm:px-6 rounded-xl font-medium transition-colors text-center cursor-pointer whitespace-nowrap text-sm sm:text-base touch-manipulation active:scale-95"
                      >
                        Позвонить нам
                      </a>
                      <button
                        onClick={() => setShowModal(true)}
                        className="block w-full bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-900 dark:text-white border-2 border-gray-900 dark:border-white py-3 sm:py-4 px-4 sm:px-6 rounded-xl font-medium transition-colors text-center cursor-pointer whitespace-nowrap text-sm sm:text-base touch-manipulation active:scale-95"
                      >
                        Оставить заявку
                      </button>
                    </div>

                    <div className="mt-6 sm:mt-8 space-y-2 sm:space-y-3 text-xs text-gray-500 dark:text-gray-400">
                      <div className="flex items-start">
                        <i className="ri-information-line mr-2 flex-shrink-0 mt-0.5"></i>
                        <span>Стоимость фундамента уточняется отдельно во время консультации</span>
                      </div>
                      <div className="flex items-start">
                        <i className="ri-information-line mr-2 flex-shrink-0 mt-0.5"></i>
                        <span>Стоимость кровли рассчитывается отдельно во время консультации</span>
                      </div>
                      <div className="flex items-start">
                        <i className="ri-information-line mr-2 flex-shrink-0 mt-0.5"></i>
                        <span>Обратите внимание, что цена в реальности будет меньше</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Модальное окно */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl max-w-md w-full p-6 sm:p-8 relative transition-colors duration-300 max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 cursor-pointer touch-manipulation active:scale-95"
            >
              <i className="ri-close-line text-2xl"></i>
            </button>

            <h3 className="text-xl sm:text-2xl font-light text-gray-900 dark:text-white mb-6">
              Оставить заявку
            </h3>

            <form onSubmit={handleSubmit} data-readdy-form id="calculator-form">
              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-sm text-gray-600 dark:text-gray-400 mb-2">
                    Имя *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    className="w-full p-3 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-xl focus:ring-2 focus:ring-gray-900 dark:focus:ring-white focus:border-gray-900 dark:focus:border-white text-base"
                    placeholder="Ваше имя"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-600 dark:text-gray-400 mb-2">
                    Телефон *
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                    className="w-full p-3 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-xl focus:ring-2 focus:ring-gray-900 dark:focus:ring-white focus:border-gray-900 dark:focus:border-white text-base"
                    placeholder="+7 (___) ___-__-__"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-600 dark:text-gray-400 mb-2">
                    Email *
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                    className="w-full p-3 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-xl focus:ring-2 focus:ring-gray-900 dark:focus:ring-white focus:border-gray-900 dark:focus:border-white text-base"
                    placeholder="your@email.com"
                  />
                </div>

                <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-xl text-sm">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600 dark:text-gray-400">Тип строения:</span>
                    <span className="font-medium text-gray-900 dark:text-white text-right ml-2">{selectedType?.label}</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-600 dark:text-gray-400">Площадь:</span>
                    <span className="font-medium text-gray-900 dark:text-white">{houseArea} м²</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Стоимость:</span>
                    <span className="font-medium text-gray-900 dark:text-white">{totalPrice.toLocaleString()} ₽</span>
                  </div>
                </div>
              </div>

              {submitStatus === 'success' && (
                <div className="mb-4 p-3 bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white rounded-xl text-sm">
                  Заявка успешно отправлена! Мы свяжемся с вами в ближайшее время.
                </div>
              )}

              {submitStatus === 'error' && (
                <div className="mb-4 p-3 bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white rounded-xl text-sm">
                  Произошла ошибка. Пожалуйста, попробуйте позже.
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-gray-900 dark:bg-white hover:bg-gray-800 dark:hover:bg-gray-100 text-white dark:text-gray-900 py-3 sm:py-4 px-4 sm:px-6 rounded-xl font-medium transition-colors cursor-pointer whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed text-base touch-manipulation active:scale-95"
              >
                {isSubmitting ? 'Отправка...' : 'Отправить заявку'}
              </button>
            </form>
          </div>
        </div>
      )}
      
      <style>{`
        .slider-thumb::-webkit-slider-thumb {
          appearance: none;
          height: 24px;
          width: 24px;
          border-radius: 50%;
          background: #6b7280;
          cursor: pointer;
          border: 3px solid #ffffff;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
        
        .slider-thumb::-moz-range-thumb {
          height: 24px;
          width: 24px;
          border-radius: 50%;
          background: #6b7280;
          cursor: pointer;
          border: 3px solid #ffffff;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
        }
      `}</style>
    </>
  );
};

export default CalculatorPage;
