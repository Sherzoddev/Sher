import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_PUBLIC_SUPABASE_URL,
  import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY
);

interface Project {
  id: string;
  title: string;
  category: string;
  price: number;
  area: number;
  dimensions: string;
  description: string;
  features: string[];
  images: string[];
  rooms: string;
  foundation: string;
  walls: string;
  roof: string;
  is_featured: boolean;
}

const CatalogPage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('Все');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isWhatsAppPopupOpen, setIsWhatsAppPopupOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [isFullscreenOpen, setIsFullscreenOpen] = useState(false);
  const [fullscreenImageIndex, setFullscreenImageIndex] = useState(0);

  const categories = [
    'Все',
    'Модульные дома',
    'Каркасные дома',
    'Модульные бани',
    'Гриль-дома',
    'Беседки',
    'Хозпостройки'
  ];

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('projects')
      .select('*')
      .order('display_order', { ascending: true })
      .order('is_featured', { ascending: false });

    if (error) {
      console.error('Ошибка загрузки проектов:', error);
    } else {
      setProjects(data || []);
    }
    setLoading(false);
  };

  const openModal = (project: Project) => {
    setSelectedProject(project);
    setIsModalOpen(true);
    setCurrentImageIndex(0);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedProject(null);
    setCurrentImageIndex(0);
  };

  const nextImage = () => {
    if (selectedProject) {
      setCurrentImageIndex((prev) => 
        prev === selectedProject.images.length - 1 ? 0 : prev + 1
      );
    }
  };

  const prevImage = () => {
    if (selectedProject) {
      setCurrentImageIndex((prev) => 
        prev === 0 ? selectedProject.images.length - 1 : prev - 1
      );
    }
  };

  const openFullscreen = (index: number) => {
    setFullscreenImageIndex(index);
    setIsFullscreenOpen(true);
  };

  const closeFullscreen = () => {
    setIsFullscreenOpen(false);
  };

  const nextFullscreenImage = () => {
    if (selectedProject) {
      setFullscreenImageIndex((prev) => 
        prev === selectedProject.images.length - 1 ? 0 : prev + 1
      );
    }
  };

  const prevFullscreenImage = () => {
    if (selectedProject) {
      setFullscreenImageIndex((prev) => 
        prev === 0 ? selectedProject.images.length - 1 : prev - 1
      );
    }
  };

  const filteredProjects = selectedCategory === 'Все' 
    ? projects 
    : projects.filter(p => p.category === selectedCategory);

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#222222] via-[#2a2a2a] to-[#333333] dark:from-gray-950 dark:via-gray-900 dark:to-black py-20 lg:py-32 overflow-hidden transition-colors duration-300">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-gray-600 rounded-full filter blur-3xl"></div>
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-gray-700 rounded-full filter blur-3xl"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
              Полный каталог готовых проектов
            </h1>
            <p className="text-xl text-gray-300 mb-12">
              Выберите идеальное строение из нашей коллекции
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <button
                onClick={() => setIsWhatsAppPopupOpen(true)}
                className="bg-white/10 hover:bg-white/20 backdrop-blur-sm text-white border-2 border-white/30 px-8 py-4 rounded-xl font-bold text-lg transition-all cursor-pointer inline-flex items-center justify-center gap-2 whitespace-nowrap"
              >
                <i className="ri-mail-line"></i>
                Получить каталог
              </button>
              <Link 
                to="/calculator"
                className="bg-white text-slate-900 hover:bg-gray-100 px-8 py-4 rounded-xl font-bold text-lg transition-all cursor-pointer inline-flex items-center justify-center gap-2 whitespace-nowrap"
              >
                <i className="ri-calculator-line"></i>
                Рассчитать стоимость
              </Link>
            </div>

            {/* Filter Pills */}
            <div className="flex flex-wrap justify-center gap-2 bg-white/10 backdrop-blur-sm rounded-2xl p-3 max-w-4xl mx-auto">
              {categories.map((type) => (
                <button
                  key={type}
                  onClick={() => setSelectedCategory(type)}
                  className={`px-6 py-2 rounded-xl font-semibold transition-all cursor-pointer whitespace-nowrap text-sm ${
                    selectedCategory === type
                      ? 'bg-white text-slate-900 shadow-lg'
                      : 'text-white hover:bg-white/10'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="py-20 bg-white dark:bg-gray-900 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {loading ? (
            <div className="text-center py-20">
              <div className="w-16 h-16 border-4 border-slate-900 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-gray-600 dark:text-gray-400">Загрузка проектов...</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredProjects.map((project) => (
                <div 
                  key={project.id} 
                  onClick={() => openModal(project)}
                  className="group bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500 cursor-pointer border border-gray-100 dark:border-gray-700 hover:border-green-600 hover:border-2"
                >
                  <div className="relative overflow-hidden aspect-[4/3]">
                    <img
                      src={project.images[0]}
                      alt={project.title}
                      className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    
                    {/* Floating Badge */}
                    <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm px-4 py-2 rounded-full shadow-lg">
                      <span className="text-sm font-bold text-slate-900">{project.area} м²</span>
                    </div>

                    {/* Hover Info */}
                    <div className="absolute bottom-0 left-0 right-0 p-6 translate-y-full group-hover:translate-y-0 transition-transform duration-500">
                      <div className="flex flex-wrap gap-2 mb-3">
                        {project.features.slice(0, 2).map((feature, idx) => (
                          <span key={idx} className="text-xs bg-white/20 backdrop-blur-sm text-white px-3 py-1 rounded-full">
                            {feature}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-sm text-gray-500 dark:text-gray-400 font-medium">{project.category}</span>
                    </div>
                    
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-3 group-hover:text-green-600 dark:group-hover:text-green-400 transition-colors leading-tight">
                      {project.title}
                    </h3>
                    
                    <p className="text-2xl font-bold text-slate-900 dark:text-white mb-4">
                      {project.price.toLocaleString('ru-RU')} ₽
                    </p>
                    
                    <div className="flex items-center text-green-600 dark:text-green-400 font-semibold group-hover:gap-3 gap-2 transition-all">
                      <span>Подробнее</span>
                      <i className="ri-arrow-right-line"></i>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Work Area Section */}
      <section className="py-20 bg-gradient-to-b from-gray-50 to-white dark:from-gray-800 dark:to-gray-900 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 dark:text-white mb-6">
            Мы работаем по всей России
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Работаем по всей России. Доставка и установка в радиусе 30 км от Вологды — 
            на выгодных условиях (детали на консультации).
          </p>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 bg-white dark:bg-gray-900 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 dark:text-white mb-4">
              Категории проектов
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Найдите идеальное решение для вашего участка
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <Link 
              to="/modulnye-doma" 
              className="group relative bg-gradient-to-br from-blue-500 to-blue-600 rounded-3xl overflow-hidden h-80 cursor-pointer"
            >
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
              <div className="relative h-full p-8 flex flex-col justify-end text-white">
                <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <i className="ri-home-smile-2-line text-3xl"></i>
                </div>
                <h3 className="text-2xl font-bold mb-2">Модульные дома</h3>
                <p className="text-white/90 mb-4">От 11 до 102 м²</p>
                <div className="flex items-center gap-2 font-semibold">
                  <span>Смотреть проекты</span>
                  <i className="ri-arrow-right-line group-hover:translate-x-2 transition-transform"></i>
                </div>
              </div>
            </Link>

            <Link 
              to="/dvumodulnye" 
              className="group relative bg-gradient-to-br from-slate-500 to-slate-600 rounded-3xl overflow-hidden h-80 cursor-pointer"
            >
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
              <div className="relative h-full p-8 flex flex-col justify-end text-white">
                <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <i className="ri-building-2-line text-3xl"></i>
                </div>
                <h3 className="text-2xl font-bold mb-2">Каркасные дома</h3>
                <p className="text-white/90 mb-4">От 90 до 180 м²</p>
                <div className="flex items-center gap-2 font-semibold">
                  <span>Смотреть проекты</span>
                  <i className="ri-arrow-right-line group-hover:translate-x-2 transition-transform"></i>
                </div>
              </div>
            </Link>

            <Link 
              to="/odnomodulnye-bani" 
              className="group relative bg-gradient-to-br from-teal-500 to-teal-600 rounded-3xl overflow-hidden h-80 cursor-pointer"
            >
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
              <div className="relative h-full p-8 flex flex-col justify-end text-white">
                <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <i className="ri-home-4-line text-3xl"></i>
                </div>
                <h3 className="text-2xl font-bold mb-2">Модульные бани</h3>
                <p className="text-white/90 mb-4">Зоны отдыха</p>
                <div className="flex items-center gap-2 font-semibold">
                  <span>Смотреть проекты</span>
                  <i className="ri-arrow-right-line group-hover:translate-x-2 transition-transform"></i>
                </div>
              </div>
            </Link>

            <Link 
              to="/grill-zones" 
              className="group relative bg-gradient-to-br from-gray-500 to-gray-600 rounded-3xl overflow-hidden h-80 cursor-pointer"
            >
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
              <div className="relative h-full p-8 flex flex-col justify-end text-white">
                <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <i className="ri-door-line text-3xl"></i>
                </div>
                <h3 className="text-2xl font-bold mb-2">Хозпостройки</h3>
                <p className="text-white/90 mb-4">Хозблоки, сараи, гаражи</p>
                <div className="flex items-center gap-2 font-semibold">
                  <span>Смотреть проекты</span>
                  <i className="ri-arrow-right-line group-hover:translate-x-2 transition-transform"></i>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-slate-900 dark:bg-gray-950 relative overflow-hidden transition-colors duration-300">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-0 right-0 w-96 h-96 bg-teal-500 rounded-full filter blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500 rounded-full filter blur-3xl"></div>
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Не нашли подходящий проект?
          </h2>
          <p className="text-xl text-gray-300 mb-10">
            Разработаем индивидуальный проект специально для вас
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => setIsWhatsAppPopupOpen(true)}
              className="bg-white/10 hover:bg-white/20 backdrop-blur-sm text-white border-2 border-white/30 px-10 py-5 rounded-xl font-bold text-lg transition-all cursor-pointer inline-flex items-center justify-center gap-2 whitespace-nowrap"
            >
              Получить каталог
            </button>
            <Link 
              to="/calculator"
              className="bg-white text-slate-900 hover:bg-gray-100 px-10 py-5 rounded-xl font-bold text-lg transition-all cursor-pointer inline-flex items-center justify-center gap-2 whitespace-nowrap"
            >
              Рассчитать стоимость
            </Link>
            <Link
              to="/contacts"
              className="bg-white/10 hover:bg-white/20 backdrop-blur-sm text-white border-2 border-white/30 px-10 py-5 rounded-xl font-bold text-lg transition-all cursor-pointer inline-flex items-center justify-center gap-2 whitespace-nowrap"
            >
              Связаться с нами
            </Link>
          </div>
        </div>
      </section>

      {/* WhatsApp Popup */}
      {isWhatsAppPopupOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 rounded-3xl max-w-md w-full transition-colors duration-300">
            <div className="p-8">
              <div className="flex justify-between items-start mb-6">
                <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Получить каталог</h2>
                <button
                  onClick={() => setIsWhatsAppPopupOpen(false)}
                  className="w-10 h-10 flex items-center justify-center cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
                >
                  <i className="ri-close-line text-gray-500 dark:text-gray-400 text-2xl"></i>
                </button>
              </div>

              <form className="space-y-4" data-readdy-form id="catalog-form">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Ваше имя *
                  </label>
                  <input
                    type="text"
                    name="name"
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Имя"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Телефон *
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="+7 (000) 000-00-00"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Электронная почта *
                  </label>
                  <input
                    type="email"
                    name="email"
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="email@example.com"
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-slate-900 dark:bg-slate-700 hover:bg-slate-800 dark:hover:bg-slate-600 text-white px-6 py-3 rounded-xl font-semibold transition-colors whitespace-nowrap cursor-pointer"
                >
                  Получить каталог
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Project Modal with Carousel */}
      {isModalOpen && selectedProject && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 rounded-3xl max-w-5xl w-full max-h-[90vh] overflow-y-auto transition-colors duration-300">
            <div className="p-8">
              <div className="flex justify-between items-start mb-8">
                <div>
                  <div className="flex items-center gap-3 mb-3">
                    <span className={`px-4 py-1 rounded-full text-sm font-semibold ${
                      selectedProject.category.includes('дом') ? 'bg-blue-100 text-blue-700' : 
                      selectedProject.category.includes('баня') ? 'bg-teal-100 text-teal-700' :
                      selectedProject.category === 'Гриль-дома' ? 'bg-orange-100 text-orange-700' :
                      selectedProject.category === 'Беседки' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                    }`}>
                      {selectedProject.category}
                    </span>
                    <span className="text-gray-500 dark:text-gray-400">{selectedProject.area} м²</span>
                  </div>
                  <h2 className="text-3xl font-bold text-slate-900 dark:text-white">{selectedProject.title}</h2>
                </div>
                <button
                  onClick={closeModal}
                  className="w-12 h-12 flex items-center justify-center cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
                >
                  <i className="ri-close-line text-gray-500 dark:text-gray-400 text-2xl"></i>
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                <div>
                  {/* Image Carousel */}
                  <div className="relative mb-4">
                    <img
                      src={selectedProject.images[currentImageIndex]}
                      alt={`${selectedProject.title} - фото ${currentImageIndex + 1}`}
                      className="w-full h-96 object-cover object-top rounded-2xl cursor-pointer"
                      onClick={() => openFullscreen(currentImageIndex)}
                    />
                    
                    {/* Fullscreen Icon */}
                    <button
                      onClick={() => openFullscreen(currentImageIndex)}
                      className="absolute top-4 right-4 w-10 h-10 bg-white/90 dark:bg-gray-800/90 hover:bg-white dark:hover:bg-gray-800 rounded-full flex items-center justify-center cursor-pointer transition-all shadow-lg"
                      title="Открыть в полном экране"
                    >
                      <i className="ri-fullscreen-line text-xl text-gray-800 dark:text-white"></i>
                    </button>
                    
                    {/* Navigation Arrows */}
                    {selectedProject.images.length > 1 && (
                      <>
                        <button
                          onClick={prevImage}
                          className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/90 dark:bg-gray-800/90 hover:bg-white dark:hover:bg-gray-800 rounded-full flex items-center justify-center cursor-pointer transition-all shadow-lg"
                        >
                          <i className="ri-arrow-left-s-line text-2xl text-gray-800 dark:text-white"></i>
                        </button>
                        <button
                          onClick={nextImage}
                          className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/90 dark:bg-gray-800/90 hover:bg-white dark:hover:bg-gray-800 rounded-full flex items-center justify-center cursor-pointer transition-all shadow-lg"
                        >
                          <i className="ri-arrow-right-s-line text-2xl text-gray-800 dark:text-white"></i>
                        </button>
                      </>
                    )}

                    {/* Image Counter */}
                    <div className="absolute bottom-4 right-4 bg-black/70 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm font-semibold">
                      {currentImageIndex + 1} / {selectedProject.images.length}
                    </div>
                  </div>

                  {/* Thumbnail Navigation */}
                  {selectedProject.images.length > 1 && (
                    <div className="flex gap-2 overflow-x-auto pb-2">
                      {selectedProject.images.map((image, index) => (
                        <button
                          key={index}
                          onClick={() => setCurrentImageIndex(index)}
                          className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden cursor-pointer transition-all ${
                            currentImageIndex === index 
                              ? 'ring-4 ring-green-600 scale-105' 
                              : 'opacity-60 hover:opacity-100'
                          }`}
                        >
                          <img
                            src={image}
                            alt={`Миниатюра ${index + 1}`}
                            className="w-full h-full object-cover object-top"
                          />
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div className="space-y-6">
                  <div>
                    <div className="text-3xl font-bold text-slate-900 dark:text-white mb-4">
                      {selectedProject.price.toLocaleString('ru-RU')} ₽
                    </div>
                    <p className="text-gray-600 dark:text-gray-300 text-lg">{selectedProject.description}</p>
                  </div>

                  <div className="bg-gray-50 dark:bg-gray-700 rounded-2xl p-6 transition-colors duration-300">
                    <h3 className="font-bold text-slate-900 dark:text-white mb-4 text-lg flex items-center gap-2">
                      <i className="ri-ruler-line text-green-600"></i>
                      Основные характеристики
                    </h3>
                    <div className="space-y-3">
                      <div className="flex flex-col sm:flex-row sm:justify-between gap-1">
                        <span className="text-gray-600 dark:text-gray-400 text-sm sm:text-base">Общая площадь:</span>
                        <span className="font-semibold text-slate-900 dark:text-white text-sm sm:text-base">{selectedProject.area} м²</span>
                      </div>
                      {selectedProject.rooms && (
                        <div className="flex flex-col sm:flex-row sm:justify-between gap-1">
                          <span className="text-gray-600 dark:text-gray-400 text-sm sm:text-base">Помещения:</span>
                          <span className="font-semibold text-slate-900 dark:text-white text-sm sm:text-base">{selectedProject.rooms}</span>
                        </div>
                      )}
                      {selectedProject.foundation && (
                        <div className="flex flex-col sm:flex-row sm:justify-between gap-1">
                          <span className="text-gray-600 dark:text-gray-400 text-sm sm:text-base">Фундамент:</span>
                          <span className="font-semibold text-slate-900 dark:text-white text-sm sm:text-base">{selectedProject.foundation}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white mb-3 text-lg">Особенности</h3>
                    <div className="flex flex-wrap gap-2">
                      {selectedProject.features.map((feature, index) => (
                        <span
                          key={index}
                          className="bg-gray-100 dark:bg-gray-700 text-slate-900 dark:text-white px-4 py-2 rounded-full text-sm font-medium"
                        >
                          {feature}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/calculator"
                  className="flex-1 bg-slate-900 dark:bg-slate-700 hover:bg-slate-800 dark:hover:bg-slate-600 text-white py-4 px-6 rounded-xl transition-all whitespace-nowrap cursor-pointer font-bold text-center"
                >
                  Заказать проект
                </Link>
                <Link
                  to="/contacts"
                  className="flex-1 border-2 border-slate-900 dark:border-slate-600 text-slate-900 dark:text-white py-4 px-6 rounded-xl hover:bg-slate-50 dark:hover:bg-gray-700 transition-all whitespace-nowrap cursor-pointer font-bold text-center"
                >
                  Получить консультацию
                </Link>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Fullscreen Image Viewer */}
      {isFullscreenOpen && selectedProject && (
        <div className="fixed inset-0 bg-black z-[100] flex items-center justify-center">
          {/* Close Button */}
          <button
            onClick={closeFullscreen}
            className="absolute top-4 right-4 w-12 h-12 bg-white/10 hover:bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center cursor-pointer transition-all z-10"
          >
            <i className="ri-close-line text-white text-2xl"></i>
          </button>

          {/* Image Counter */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-white/10 backdrop-blur-sm text-white px-6 py-3 rounded-full text-sm font-semibold z-10">
            {fullscreenImageIndex + 1} / {selectedProject.images.length}
          </div>

          {/* Main Image */}
          <img
            src={selectedProject.images[fullscreenImageIndex]}
            alt={`${selectedProject.title} - фото ${fullscreenImageIndex + 1}`}
            className="max-w-[95vw] max-h-[95vh] object-contain"
          />

          {/* Navigation Arrows */}
          {selectedProject.images.length > 1 && (
            <>
              <button
                onClick={prevFullscreenImage}
                className="absolute left-4 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/10 hover:bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center cursor-pointer transition-all"
              >
                <i className="ri-arrow-left-s-line text-3xl text-white"></i>
              </button>
              <button
                onClick={nextFullscreenImage}
                className="absolute right-4 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/10 hover:bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center cursor-pointer transition-all"
              >
                <i className="ri-arrow-right-s-line text-3xl text-white"></i>
              </button>
            </>
          )}

          {/* Thumbnail Navigation */}
          {selectedProject.images.length > 1 && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 overflow-x-auto max-w-[90vw] pb-2">
              {selectedProject.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setFullscreenImageIndex(index)}
                  className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden cursor-pointer transition-all ${
                    fullscreenImageIndex === index 
                      ? 'ring-4 ring-white scale-105' 
                      : 'opacity-60 hover:opacity-100'
                  }`}
                >
                  <img
                    src={image}
                    alt={`Миниатюра ${index + 1}`}
                    className="w-full h-full object-cover object-top"
                  />
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default CatalogPage;
