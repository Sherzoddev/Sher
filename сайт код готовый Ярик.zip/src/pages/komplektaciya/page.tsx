import React, { useState } from 'react';

const KomplektaciyaPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'packages' | 'options'>('packages');
  const [selectedOption, setSelectedOption] = useState<any>(null);
  const [selectedPackage, setSelectedPackage] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedRoofingType, setSelectedRoofingType] = useState<string>('');

  const topOptions = [
    {
      id: 1,
      name: 'Система "Басту"',
      icon: 'ri-windy-line',
      price: 'от 25 000 ₽',
      shortDescription: 'Обеспечивает регулирования интенсивности воздухообмена в парной.',
      fullDescription: 'Система вентиляции "Басту" - это инновационное решение для саун и бань, обеспечивающее оптимальный воздухообмен. Свежий воздух поступает и нагревается, отработанный уходит, создавая комфортные условия для парения.',
      image: 'https://readdy.ai/api/search-image?query=modern%20sauna%20ventilation%20system%20Bastu%2C%20air%20circulation%20system%2C%20technical%20equipment%20for%20sauna%2C%20professional%20installation%2C%20clean%20background&width=800&height=600&seq=bastu-system&orientation=landscape',
      features: [
        'Регулируемая интенсивность воздухообмена',
        'Автоматическое управление',
        'Энергоэффективность',
        'Простая установка',
        'Долговечность конструкции'
      ],
      specifications: {
        'Производительность': 'До 150 м³/час',
        'Материал': 'Нержавеющая сталь',
        'Управление': 'Механическое/автоматическое',
        'Гарантия': '3 года'
      }
    },
    {
      id: 2,
      name: 'Панорамное остекление',
      icon: 'ri-window-line',
      price: 'от 45 000 ₽',
      shortDescription: 'Большие окна от пола до потолка для максимального естественного освещения.',
      fullDescription: 'Панорамное остекление создает ощущение простора и единения с природой. Энергоэффективные стеклопакеты обеспечивают отличную теплоизоляцию при максимальном естественном освещении.',
      image: 'https://readdy.ai/api/search-image?query=panoramic%20windows%20in%20modern%20house%2C%20floor%20to%20ceiling%20glass%2C%20natural%20light%2C%20contemporary%20interior%20with%20large%20windows%2C%20clean%20background&width=800&height=600&seq=panoramic-windows&orientation=landscape',
      features: [
        'Энергоэффективные стеклопакеты',
        'Максимум естественного света',
        'Отличная теплоизоляция',
        'Современный дизайн',
        'Различные размеры'
      ],
      specifications: {
        'Тип стеклопакета': 'Двухкамерный',
        'Толщина': '40-44 мм',
        'Теплоизоляция': 'До 0.6 Вт/м²К',
        'Шумоизоляция': 'До 35 дБ'
      }
    },
    {
      id: 3,
      name: 'Теплый пол',
      icon: 'ri-temp-hot-line',
      price: 'от 3 500 ₽/м²',
      shortDescription: 'Комфортный обогрев помещений с равномерным распределением тепла.',
      fullDescription: 'Система теплого пола обеспечивает равномерный и комфортный обогрев всего помещения. Экономичное решение с возможностью индивидуальной регулировки температуры в каждой комнате.',
      image: 'https://readdy.ai/api/search-image?query=underfloor%20heating%20system%20installation%2C%20warm%20floor%20construction%2C%20heating%20cables%2C%20modern%20home%20comfort%2C%20technical%20installation%2C%20clean%20background&width=800&height=600&seq=warm-floor&orientation=landscape',
      features: [
        'Равномерное распределение тепла',
        'Энергоэффективность до 30%',
        'Индивидуальная регулировка',
        'Совместим с любым покрытием',
        'Долгий срок службы'
      ],
      specifications: {
        'Тип системы': 'Электрический/водяной',
        'Мощность': '120-180 Вт/м²',
        'Управление': 'Терморегулятор',
        'Гарантия': '10 лет'
      }
    },
    {
      id: 4,
      name: 'Умный дом',
      icon: 'ri-home-wifi-line',
      price: 'от 85 000 ₽',
      shortDescription: 'Автоматизация освещения, отопления, безопасности и других систем.',
      fullDescription: 'Система "Умный дом" позволяет управлять всеми инженерными системами дома с помощью смартфона или голосовых команд. Автоматизация освещения, климат-контроля, безопасности и мультимедиа.',
      image: 'https://readdy.ai/api/search-image?query=smart%20home%20control%20system%2C%20home%20automation%2C%20smartphone%20control%2C%20modern%20technology%2C%20IoT%20devices%2C%20clean%20background&width=800&height=600&seq=smart-home&orientation=landscape',
      features: [
        'Управление со смартфона',
        'Голосовое управление',
        'Автоматические сценарии',
        'Контроль безопасности',
        'Энергосбережение'
      ],
      specifications: {
        'Протокол': 'Wi-Fi, Zigbee, Z-Wave',
        'Совместимость': 'iOS, Android',
        'Количество устройств': 'До 100',
        'Облачное хранение': 'Включено'
      }
    },
    {
      id: 5,
      name: 'Дровяная печь премиум',
      icon: 'ri-fire-line',
      price: 'от 120 000 ₽',
      shortDescription: 'Финская печь с камнями для настоящей русской бани.',
      fullDescription: 'Премиальная дровяная печь от финских производителей. Быстрый нагрев, долгое сохранение тепла, равномерное распределение жара. Идеальна для создания аутентичной атмосферы русской бани.',
      image: 'https://readdy.ai/api/search-image?query=premium%20wood%20burning%20sauna%20stove%2C%20Finnish%20sauna%20heater%20with%20stones%2C%20traditional%20bathhouse%20equipment%2C%20professional%20installation%2C%20clean%20background&width=800&height=600&seq=wood-stove&orientation=landscape',
      features: [
        'Финское качество',
        'Быстрый нагрев до 100°C',
        'Большой объем камней',
        'Панорамное стекло',
        'Долгий срок службы'
      ],
      specifications: {
        'Мощность': '18-24 кВт',
        'Объем парной': 'До 24 м³',
        'Вес камней': 'До 80 кг',
        'Материал': 'Нержавеющая сталь'
      }
    },
    {
      id: 6,
      name: 'Терраса с навесом',
      icon: 'ri-home-5-line',
      price: 'от 95 000 ₽',
      shortDescription: 'Открытая терраса с защитой от дождя и солнца.',
      fullDescription: 'Просторная терраса с надежным навесом создает дополнительное пространство для отдыха. Защита от дождя и солнца позволяет комфортно проводить время на свежем воздухе в любую погоду.',
      image: 'https://readdy.ai/api/search-image?query=modern%20wooden%20terrace%20with%20roof%20canopy%2C%20outdoor%20living%20space%2C%20covered%20patio%2C%20contemporary%20design%2C%20natural%20materials%2C%20clean%20background&width=800&height=600&seq=terrace-canopy&orientation=landscape',
      features: [
        'Защита от дождя и солнца',
        'Прочная конструкция',
        'Деревянный настил',
        'Различные размеры',
        'Быстрый монтаж'
      ],
      specifications: {
        'Площадь': 'От 12 м²',
        'Материал настила': 'Террасная доска',
        'Кровля': 'Металлочерепица/поликарбонат',
        'Нагрузка': 'До 250 кг/м²'
      }
    },
    {
      id: 7,
      name: 'Купель с подогревом',
      icon: 'ri-contrast-drop-line',
      price: 'от 180 000 ₽',
      shortDescription: 'Деревянная купель с системой подогрева воды.',
      fullDescription: 'Традиционная деревянная купель из кедра или лиственницы с современной системой подогрева. Идеальное дополнение к бане для контрастных процедур и релаксации.',
      image: 'https://readdy.ai/api/search-image?query=wooden%20hot%20tub%20with%20heating%20system%2C%20cedar%20barrel%20bath%2C%20outdoor%20spa%2C%20traditional%20bathhouse%20equipment%2C%20natural%20wood%2C%20clean%20background&width=800&height=600&seq=hot-tub&orientation=landscape',
      features: [
        'Натуральное дерево (кедр/лиственница)',
        'Система подогрева воды',
        'Гидромассаж (опция)',
        'Вместимость 4-6 человек',
        'Долговечность'
      ],
      specifications: {
        'Объем': '1500-2000 литров',
        'Диаметр': '180-220 см',
        'Подогрев': 'Электрический/дровяной',
        'Температура': 'До 45°C'
      }
    },
    {
      id: 8,
      name: 'Система видеонаблюдения',
      icon: 'ri-camera-line',
      price: 'от 55 000 ₽',
      shortDescription: 'Комплексная система безопасности с удаленным доступом.',
      fullDescription: 'Профессиональная система видеонаблюдения с возможностью удаленного просмотра через смартфон. Запись на облако, ночное видение, детекция движения и уведомления в реальном времени.',
      image: 'https://readdy.ai/api/search-image?query=modern%20security%20camera%20system%2C%20home%20surveillance%2C%20IP%20cameras%2C%20smart%20security%2C%20monitoring%20equipment%2C%20clean%20background&width=800&height=600&seq=cctv-system&orientation=landscape',
      features: [
        'Удаленный доступ 24/7',
        'Ночное видение',
        'Детекция движения',
        'Облачное хранение',
        'Мобильные уведомления'
      ],
      specifications: {
        'Количество камер': '4-8 шт',
        'Разрешение': 'Full HD 1080p',
        'Хранение': '30 дней',
        'Угол обзора': '110-130°'
      }
    },
    {
      id: 9,
      name: 'Солнечные панели',
      icon: 'ri-sun-line',
      price: 'от 250 000 ₽',
      shortDescription: 'Автономное электроснабжение и экономия на счетах.',
      fullDescription: 'Система солнечных панелей для частичного или полного обеспечения дома электроэнергией. Экологичное решение с окупаемостью 5-7 лет и возможностью продажи излишков энергии.',
      image: 'https://readdy.ai/api/search-image?query=solar%20panels%20on%20house%20roof%2C%20photovoltaic%20system%2C%20renewable%20energy%2C%20modern%20eco%20home%2C%20clean%20technology%2C%20clean%20background&width=800&height=600&seq=solar-panels&orientation=landscape',
      features: [
        'Экономия до 70% на электричестве',
        'Экологичность',
        'Автономность',
        'Долгий срок службы (25+ лет)',
        'Государственные субсидии'
      ],
      specifications: {
        'Мощность системы': '5-10 кВт',
        'Количество панелей': '15-30 шт',
        'Производство': '6000-12000 кВт·ч/год',
        'Гарантия': '25 лет'
      }
    },
    {
      id: 10,
      name: 'Система рекуперации',
      icon: 'ri-refresh-line',
      price: 'от 95 000 ₽',
      shortDescription: 'Энергоэффективная вентиляция с возвратом тепла.',
      fullDescription: 'Система приточно-вытяжной вентиляции с рекуперацией тепла. Обеспечивает постоянный приток свежего воздуха с сохранением до 90% тепла, значительно снижая расходы на отопление.',
      image: 'https://readdy.ai/api/search-image?query=heat%20recovery%20ventilation%20system%2C%20energy%20efficient%20HVAC%2C%20recuperation%20unit%2C%20modern%20home%20ventilation%2C%20technical%20equipment%2C%20clean%20background&width=800&height=600&seq=recuperation&orientation=landscape',
      features: [
        'Возврат до 90% тепла',
        'Постоянный приток свежего воздуха',
        'Фильтрация воздуха',
        'Экономия на отоплении',
        'Тихая работа'
      ],
      specifications: {
        'Производительность': '150-300 м³/час',
        'КПД рекуперации': 'До 90%',
        'Уровень шума': '25-35 дБ',
        'Фильтры': 'F7/G4'
      }
    }
  ];

  const roofingTypes = [
    {
      value: 'metal-tile',
      label: 'Металлочерепица',
      description: 'Классическое кровельное покрытие с имитацией натуральной черепицы',
      features: [
        'Долговечность до 50 лет',
        'Устойчивость к перепадам температур',
        'Широкая цветовая гамма',
        'Легкий вес',
        'Простой монтаж'
      ],
      specifications: {
        'Материал': 'Оцинкованная сталь с полимерным покрытием',
        'Толщина металла': '0.45-0.5 мм',
        'Покрытие': 'Полиэстер/Матовый полиэстер',
        'Гарантия': '10-15 лет',
        'Вес': '4-5 кг/м²'
      }
    },
    {
      value: 'profiled-sheet',
      label: 'Профнастил',
      description: 'Экономичное и надежное решение для кровли',
      features: [
        'Доступная цена',
        'Высокая прочность',
        'Быстрый монтаж',
        'Устойчивость к коррозии',
        'Долгий срок службы'
      ],
      specifications: {
        'Материал': 'Оцинкованная сталь',
        'Толщина металла': '0.5 мм',
        'Профиль': 'С20/С21',
        'Гарантия': '10 лет',
        'Вес': '4-6 кг/м²'
      }
    },
    {
      value: 'ondulin',
      label: 'Ондулин',
      description: 'Легкое битумное покрытие для небольших построек',
      features: [
        'Низкая цена',
        'Малый вес',
        'Бесшумность при дожде',
        'Простой монтаж',
        'Экологичность'
      ],
      specifications: {
        'Материал': 'Целлюлоза с битумной пропиткой',
        'Толщина': '3 мм',
        'Размер листа': '2000x950 мм',
        'Гарантия': '15 лет',
        'Вес': '6 кг/м²'
      }
    }
  ];

  const foundationTypes = [
    {
      value: 'screw-pile',
      label: 'Свайно-винтовой фундамент',
      description: 'Универсальное решение для любых типов грунта',
      features: [
        'Подходит для любых грунтов',
        'Быстрый монтаж за 1-2 дня',
        'Не требует земляных работ',
        'Можно строить круглый год',
        'Срок службы более 80 лет'
      ],
      specifications: {
        'Диаметр сваи': '108 мм',
        'Толщина стенки': '4 мм',
        'Обвязка': 'Брус 150х150 мм',
        'Антикоррозийное покрытие': 'Да',
        'Глубина установки': '1.5-2.5 м'
      }
    },
    {
      value: 'strip',
      label: 'Ленточный фундамент',
      description: 'Надежный фундамент для капитального строительства',
      features: [
        'Низкая стоимость',
        'Быстрый монтаж',
        'Подходит для легких построек',
        'Минимум земляных работ',
        'Хорошая вентиляция подпола'
      ],
      specifications: {
        'Материал столбов': 'Бетонные блоки/кирпич',
        'Размер столба': '400х400 мм',
        'Глубина': '0.5-1 м',
        'Обвязка': 'Брус 150х150 мм',
        'Шаг столбов': '1.5-2 м'
      }
    },
    {
      value: 'slab',
      label: 'Плитный фундамент',
      description: 'Монолитная плита для сложных грунтов',
      features: [
        'Максимальная устойчивость',
        'Подходит для слабых грунтов',
        'Равномерное распределение нагрузки',
        'Можно использовать как пол',
        'Долговечность'
      ],
      specifications: {
        'Толщина плиты': '200-300 мм',
        'Материал': 'Бетон М300-М350',
        'Армирование': 'Двойная сетка Ø12-14 мм',
        'Утепление': 'Пенополистирол 100 мм',
        'Гидроизоляция': 'Обязательна'
      }
    },
    {
      value: 'columnar',
      label: 'Столбчатый фундамент',
      description: 'Экономичное решение для легких построек',
      features: [
        'Низкая стоимость',
        'Быстрый монтаж',
        'Подходит для легких построек',
        'Минимум земляных работ',
        'Хорошая вентиляция подпола'
      ],
      specifications: {
        'Материал столбов': 'Бетонные блоки/кирпич',
        'Размер столба': '400х400 мм',
        'Глубина': '0.5-1 м',
        'Обвязка': 'Брус 150х150 мм',
        'Шаг столбов': '1.5-2 м'
      }
    }
  ];

  const basePackages = [
    {
      id: 1,
      name: 'Каркас',
      icon: 'ri-layout-grid-line',
      description: 'Деревянный каркас из сухого строганого бруса',
      included: true,
      fullDescription: 'Прочный деревянный каркас из сухого строганого бруса камерной сушки. Основа всей конструкции, обеспечивающая надежность и долговечность строения на десятилетия.',
      image: 'https://readdy.ai/api/search-image?query=wooden%20frame%20construction%20with%20dry%20planed%20timber%20beams%2C%20house%20frame%20structure%2C%20professional%20carpentry%20work%2C%20natural%20wood%20construction%2C%20clean%20background&width=800&height=600&seq=frame-construction&orientation=landscape',
      features: [
        'Брус камерной сушки (влажность 12-14%)',
        'Строганый брус 100х150 мм',
        'Обработка антисептиком',
        'Точная геометрия элементов',
        'Долговечность более 50 лет'
      ],
      specifications: {
        'Материал': 'Сосна/ель камерной сушки',
        'Сечение бруса': '100х150 мм',
        'Влажность': '12-14%',
        'Обработка': 'Антисептик + огнезащита'
      }
    },
    {
      id: 2,
      name: 'Утепление',
      icon: 'ri-temp-cold-line',
      description: 'Минеральная вата 150 мм с пароизоляцией',
      included: true,
      fullDescription: 'Профессиональное утепление минеральной ватой толщиной 150 мм с полной пароизоляцией. Обеспечивает комфортную температуру круглый год и значительно снижает расходы на отопление.',
      image: 'https://readdy.ai/api/search-image?query=mineral%20wool%20insulation%20installation%20in%20wall%2C%20thermal%20insulation%20layers%2C%20vapor%20barrier%2C%20professional%20house%20insulation%2C%20construction%20materials%2C%20clean%20background&width=800&height=600&seq=insulation-work&orientation=landscape',
      features: [
        'Минеральная вата 150 мм',
        'Пароизоляция с двух сторон',
        'Экологически чистый материал',
        'Негорючий материал',
        'Звукоизоляция до 50 дБ'
      ],
      specifications: {
        'Толщина утеплителя': '150 мм',
        'Плотность': '35-50 кг/м³',
        'Теплопроводность': '0.035-0.040 Вт/м·К',
        'Класс горючести': 'НГ (негорючий)'
      }
    },
    {
      id: 3,
      name: 'Кровля',
      icon: 'ri-home-4-line',
      description: 'Металлочерепица или профнастил на выбор',
      included: true,
      fullDescription: 'Качественная кровля из металлочерепицы или профнастила на ваш выбор. Надежная защита от осадков, долговечность и привлекательный внешний вид на долгие годы.',
      image: 'https://readdy.ai/api/search-image?query=metal%20roof%20installation%2C%20metal%20tile%20roofing%2C%20professional%20roof%20construction%2C%20modern%20house%20roof%2C%20clean%20background&width=800&height=600&seq=roof-installation&orientation=landscape',
      features: [
        'Металлочерепица или профнастил',
        'Толщина металла 0.5 мм',
        'Полимерное покрытие',
        'Гидроизоляция кровли',
        'Срок службы до 50 лет'
      ],
      specifications: {
        'Материал': 'Оцинкованная сталь',
        'Толщина': '0.5 мм',
        'Покрытие': 'Полиэстер/Матовый полиэстер',
        'Гарантия': '10-15 лет'
      },
      hasOptions: true,
      optionType: 'roofing'
    },
    {
      id: 4,
      name: 'Окна и двери',
      icon: 'ri-door-open-line',
      description: 'Пластиковые окна и входная металлическая дверь',
      included: true,
      fullDescription: 'Энергоэффективные пластиковые окна с двухкамерными стеклопакетами и надежная входная металлическая дверь. Обеспечивают отличную тепло- и звукоизоляцию.',
      image: 'https://readdy.ai/api/search-image?query=modern%20plastic%20windows%20and%20metal%20entrance%20door%20installation%2C%20double%20glazed%20windows%2C%20house%20entrance%2C%20clean%20background&width=800&height=600&seq=windows-doors&orientation=landscape',
      features: [
        'Двухкамерные стеклопакеты',
        'Металлическая входная дверь',
        'Фурнитура европейского качества',
        'Отличная тепло- и звукоизоляция',
        'Гарантия на окна 5 лет'
      ],
      specifications: {
        'Профиль окон': '70 мм, 5 камер',
        'Стеклопакет': 'Двухкамерный 40 мм',
        'Входная дверь': 'Металл 2 мм',
        'Замки': '2 замка (сувальдный + цилиндровый)'
      }
    },
    {
      id: 5,
      name: 'Внутренняя отделка',
      icon: 'ri-paint-brush-line',
      description: 'Вагонка класса А или имитация бруса',
      included: true,
      fullDescription: 'Качественная внутренняя отделка вагонкой класса А или имитацией бруса. Создает уютную атмосферу натурального дерева и приятный микроклимат в помещении.',
      image: 'https://readdy.ai/api/search-image?query=interior%20wood%20paneling%20installation%2C%20wooden%20wall%20cladding%2C%20natural%20wood%20interior%20finish%2C%20cozy%20room%20with%20wood%20walls%2C%20clean%20background&width=800&height=600&seq=interior-finish&orientation=landscape',
      features: [
        'Вагонка класса А или имитация бруса',
        'Камерная сушка древесины',
        'Обработка антисептиком',
        'Экологически чистый материал',
        'Приятный аромат дерева'
      ],
      specifications: {
        'Материал': 'Сосна/ель класса А',
        'Толщина': '12-16 мм',
        'Влажность': '10-12%',
        'Обработка': 'Антисептик'
      }
    },
    {
      id: 6,
      name: 'Сантехника',
      icon: 'ri-drop-line',
      description: 'Разводка труб водоснабжения и канализации',
      included: true,
      fullDescription: 'Профессиональная разводка труб водоснабжения и канализации по всему дому. Используем качественные материалы и современные технологии монтажа.',
      image: 'https://readdy.ai/api/search-image?query=plumbing%20pipes%20installation%2C%20water%20supply%20and%20sewage%20system%2C%20professional%20plumbing%20work%2C%20modern%20house%20utilities%2C%20clean%20background&width=800&height=600&seq=plumbing-work&orientation=landscape',
      features: [
        'Полипропиленовые трубы',
        'Разводка холодной и горячей воды',
        'Канализационная система',
        'Запорная арматура',
        'Гарантия на монтаж 2 года'
      ],
      specifications: {
        'Трубы водоснабжения': 'Полипропилен PN20',
        'Трубы канализации': 'ПВХ 50-110 мм',
        'Фитинги': 'Полипропилен',
        'Краны': 'Шаровые краны'
      }
    },
    {
      id: 7,
      name: 'Электрика',
      icon: 'ri-flashlight-line',
      description: 'Разводка электропроводки, розетки, выключатели',
      included: true,
      fullDescription: 'Полная разводка электропроводки с установкой розеток, выключателей и распределительного щита. Все работы выполняются согласно нормам безопасности.',
      image: 'https://readdy.ai/api/search-image?query=electrical%20wiring%20installation%2C%20power%20outlets%20and%20switches%2C%20electrical%20panel%2C%20professional%20electrician%20work%2C%20clean%20background&width=800&height=600&seq=electrical-work&orientation=landscape',
      features: [
        'Медный кабель ВВГнг',
        'Розетки и выключатели',
        'Распределительный щит',
        'Автоматические выключатели',
        'УЗО для безопасности'
      ],
      specifications: {
        'Кабель': 'ВВГнг 3х2.5 мм²',
        'Розетки': '16А, с заземлением',
        'Выключатели': 'Скрытой установки',
        'Щит': 'На 12-24 модуля'
      }
    },
    {
      id: 8,
      name: 'Фундамент',
      icon: 'ri-building-line',
      description: 'Винтовые сваи с обвязкой из бруса 150х150 мм',
      included: false,
      fullDescription: 'Надежный свайно-винтовой фундамент с обвязкой из бруса 150х150 мм. Подходит для любых типов грунта, быстрый монтаж, долговечность более 80 лет.',
      image: 'https://readdy.ai/api/search-image?query=screw%20pile%20foundation%20installation%2C%20helical%20piles%20with%20timber%20frame%2C%20house%20foundation%20construction%2C%20professional%20foundation%20work%2C%20clean%20background&width=800&height=600&seq=foundation-work&orientation=landscape',
      features: [
        'Винтовые сваи диаметром 108 мм',
        'Обвязка брусом 150х150 мм',
        'Подходит для любых грунтов',
        'Быстрый монтаж за 1-2 дня',
        'Срок службы более 80 лет'
      ],
      specifications: {
        'Диаметр сваи': '108 мм',
        'Толщина стенки': '4 мм',
        'Обвязка': 'Брус 150х150 мм',
        'Антикоррозийное покрытие': 'Да'
      },
      hasOptions: true,
      optionType: 'foundation'
    }
  ];

  const openComplectationModal = (item: any) => {
    setSelectedPackage(item);
  };

  return (
    <>
      <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
        {/* Modern Hero Section - Mobile Optimized */}
        <section className="relative overflow-hidden bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0" style={{
              backgroundImage: `url('https://readdy.ai/api/search-image?query=modern%20architectural%20blueprint%20technical%20drawing%20with%20wooden%20construction%20materials%2C%20clean%20minimalist%20design%2C%20professional%20building%20plans%20with%20natural%20wood%20textures%20and%20construction%20details&width=1920&height=800&seq=komplekt-hero-modern&orientation=landscape')`,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}></div>
          </div>
          
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-24">
            <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
              <div>
                <div className="inline-flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-full px-3 sm:px-4 py-1.5 sm:py-2 mb-4 sm:mb-6">
                  <i className="ri-checkbox-circle-fill text-green-400 text-sm sm:text-base"></i>
                  <span className="text-green-400 font-medium text-xs sm:text-sm">Премиум качество</span>
                </div>
                
                <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-4 sm:mb-6 leading-tight">
                  Комплектация<br/>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-400">
                    и материалы
                  </span>
                </h1>
                
                <p className="text-base sm:text-lg lg:text-xl text-gray-300 mb-6 sm:mb-8 leading-relaxed">
                  Используем только сертифицированные материалы от проверенных производителей. Гибкая система комплектации позволяет создать идеальный дом или баню под ваши потребности.
                </p>
                
                <div className="flex flex-col sm:flex-row flex-wrap gap-3 sm:gap-4">
                  <button 
                    onClick={() => setIsModalOpen(true)}
                    className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold text-base sm:text-lg transition-all shadow-lg hover:shadow-xl hover:scale-105 whitespace-nowrap cursor-pointer text-center"
                  >
                    Получить консультацию
                  </button>
                  <a 
                    href="/catalog"
                    className="bg-white/10 backdrop-blur-sm border border-white/20 text-white hover:bg-white/20 px-6 sm:px-8 py-3 sm:py-4 rounded-xl font-semibold text-base sm:text-lg transition-all whitespace-nowrap cursor-pointer inline-flex items-center justify-center gap-2"
                  >
                    Смотреть каталог
                    <i className="ri-arrow-right-line"></i>
                  </a>
                </div>
              </div>
              
              {/* Desktop Info Cards */}
              <div className="hidden lg:block">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-4">
                    <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
                      <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center mb-4">
                        <i className="ri-checkbox-circle-fill text-2xl text-green-400"></i>
                      </div>
                      <h3 className="text-white font-bold text-lg mb-2">Гарантия качества</h3>
                      <p className="text-gray-300 text-sm">Все материалы сертифицированы</p>
                    </div>
                    <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
                      <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center mb-4">
                        <i className="ri-tools-line text-2xl text-blue-400"></i>
                      </div>
                      <h3 className="text-white font-bold text-lg mb-2">Профессиональный монтаж</h3>
                      <p className="text-gray-300 text-sm">Опытная команда специалистов</p>
                    </div>
                  </div>
                  <div className="space-y-4 pt-8">
                    <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
                      <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center mb-4">
                        <i className="ri-price-tag-3-line text-2xl text-purple-400"></i>
                      </div>
                      <h3 className="text-white font-bold text-lg mb-2">Прозрачные цены</h3>
                      <p className="text-gray-300 text-sm">Без скрытых платежей</p>
                    </div>
                    <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
                      <div className="w-12 h-12 bg-orange-500/20 rounded-xl flex items-center justify-center mb-4">
                        <i className="ri-time-line text-2xl text-orange-400"></i>
                      </div>
                      <h3 className="text-white font-bold text-lg mb-2">Быстрые сроки</h3>
                      <p className="text-gray-300 text-sm">Соблюдаем договоренности</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Mobile Info Cards */}
              <div className="grid grid-cols-2 gap-3 lg:hidden">
                <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4">
                  <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center mb-2">
                    <i className="ri-shield-check-line text-xl text-green-400"></i>
                  </div>
                  <h3 className="text-white font-bold text-sm mb-1">Гарантия качества</h3>
                  <p className="text-gray-300 text-xs">Сертифицированные материалы</p>
                </div>
                <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4">
                  <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center mb-2">
                    <i className="ri-tools-line text-xl text-blue-400"></i>
                  </div>
                  <h3 className="text-white font-bold text-sm mb-1">Профессионалы</h3>
                  <p className="text-gray-300 text-xs">Опытная команда</p>
                </div>
                <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4">
                  <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center mb-2">
                    <i className="ri-price-tag-3-line text-xl text-purple-400"></i>
                  </div>
                  <h3 className="text-white font-bold text-sm mb-1">Прозрачные цены</h3>
                  <p className="text-gray-300 text-xs">Без скрытых платежей</p>
                </div>
                <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4">
                  <div className="w-10 h-10 bg-orange-500/20 rounded-lg flex items-center justify-center mb-2">
                    <i className="ri-time-line text-xl text-orange-400"></i>
                  </div>
                  <h3 className="text-white font-bold text-sm mb-1">Быстрые сроки</h3>
                  <p className="text-gray-300 text-xs">Соблюдаем сроки</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Decorative elements */}
          <div className="absolute top-0 right-0 w-64 sm:w-96 h-64 sm:h-96 bg-green-500/5 rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-64 sm:w-96 h-64 sm:h-96 bg-blue-500/5 rounded-full blur-3xl"></div>
        </section>

        {/* Tab Navigation - Mobile Optimized */}
        <section className="sticky top-0 z-40 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700 shadow-sm transition-colors duration-300">
          <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-8">
            <div className="flex gap-2 py-3 sm:py-4">
              <button
                onClick={() => setActiveTab('packages')}
                className={`flex-1 px-3 sm:px-6 py-2.5 sm:py-3 rounded-lg font-semibold text-sm sm:text-base transition-all cursor-pointer ${
                  activeTab === 'packages'
                    ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white shadow-lg'
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                <i className="ri-checkbox-circle-line mr-1 sm:mr-2"></i>
                <span className="hidden sm:inline">Базовая комплектация</span>
                <span className="sm:hidden">Базовая</span>
              </button>
              <button
                onClick={() => setActiveTab('options')}
                className={`flex-1 px-3 sm:px-6 py-2.5 sm:py-3 rounded-lg font-semibold text-sm sm:text-base transition-all cursor-pointer ${
                  activeTab === 'options'
                    ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white shadow-lg'
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                <i className="ri-star-line mr-1 sm:mr-2"></i>
                <span className="hidden sm:inline">ТОП-10 популярных опций</span>
                <span className="sm:hidden">ТОП-10</span>
              </button>
            </div>
          </div>
        </section>

        {/* Base Complectation Section - Mobile Optimized */}
        {activeTab === 'packages' && (
          <section className="py-8 sm:py-12 lg:py-16">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-8 sm:mb-12">
                <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-3 sm:mb-4 transition-colors duration-300">
                  Базовая комплектация
                </h2>
                <p className="text-base sm:text-lg lg:text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto px-4 transition-colors duration-300">
                  Все необходимое для комфортного проживания уже включено в стоимость. 
                  Мы продумали каждую деталь, чтобы вы получили готовое решение.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
                {basePackages.map((item, index) => (
                  <div
                    key={index}
                    onClick={() => openComplectationModal(item)}
                    className="group bg-white dark:bg-gray-800 rounded-2xl p-4 sm:p-6 shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer border border-gray-100 dark:border-gray-700 hover:border-green-600 hover:border-2 relative"
                  >
                    <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center mb-3 sm:mb-4 group-hover:scale-110 transition-transform">
                      <i className={`${item.icon} text-xl sm:text-2xl text-white`}></i>
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold text-gray-900 dark:text-white mb-2 transition-colors duration-300">
                      {item.name}
                    </h3>
                    <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400 mb-3 sm:mb-4 transition-colors duration-300">
                      {item.description}
                    </p>
                    
                    {/* Индикатор статуса */}
                    <div className="flex items-center justify-between mt-auto">
                      {item.name === 'Фундамент' ? (
                        <span className="inline-flex items-center gap-1 text-xs sm:text-sm font-semibold text-gray-500 dark:text-gray-400">
                          <i className="ri-information-line"></i>
                          Нужно уточнить
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-xs sm:text-sm font-semibold text-green-600 dark:text-green-400">
                          <i className="ri-check-line"></i>
                          Включено
                        </span>
                      )}
                      <span className="inline-flex items-center gap-1 text-xs sm:text-sm font-semibold text-green-600 dark:text-green-400 group-hover:gap-2 transition-all">
                        Подробнее
                        <i className="ri-arrow-right-line"></i>
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Top Options Section - Mobile Optimized */}
        {activeTab === 'options' && (
          <section className="py-8 sm:py-12 lg:py-16">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-8 sm:mb-12">
                <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-3 sm:mb-4 transition-colors duration-300">
                  ТОП-10 популярных опций
                </h2>
                <p className="text-base sm:text-lg lg:text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto px-4 transition-colors duration-300">
                  Дополните ваш дом или баню полезными опциями для максимального комфорта. 
                  Эти решения выбирают большинство наших клиентов.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                {topOptions.map((option, index) => (
                  <div
                    key={option.id}
                    onClick={() => setSelectedOption(option)}
                    className="group bg-white dark:bg-gray-800 border-2 border-gray-100 dark:border-gray-700 rounded-2xl p-6 hover:border-green-600 dark:hover:border-green-600 hover:shadow-xl transition-all duration-300 cursor-pointer"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-emerald-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                        <i className={`${option.icon} text-white text-2xl`}></i>
                      </div>
                      <span className="bg-green-50 dark:bg-green-900/30 text-green-700 dark:text-green-400 px-3 py-1 rounded-full text-sm font-semibold transition-colors duration-300">
                        #{index + 1}
                      </span>
                    </div>

                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2 group-hover:text-green-600 dark:group-hover:text-green-400 transition-colors">
                      {option.name}
                    </h3>
                    
                    <p className="text-gray-600 dark:text-gray-400 mb-4 text-sm leading-relaxed transition-colors duration-300">
                      {option.shortDescription}
                    </p>

                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold text-gray-900 dark:text-white transition-colors duration-300">
                        {option.price}
                      </span>
                      <div className="flex items-center text-green-600 dark:text-green-400 font-semibold text-sm group-hover:gap-2 gap-1 transition-all">
                        <span>Подробнее</span>
                        <i className="ri-arrow-right-line"></i>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Benefits Section - Mobile Optimized */}
        <section className="py-12 sm:py-16 bg-white dark:bg-gray-900 transition-colors duration-300">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-8 sm:gap-10 lg:gap-12 items-center">
              <div className="order-2 lg:order-1">
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 dark:text-white mb-5 sm:mb-6 transition-colors duration-300">
                  Почему выбирают нашу комплектацию?
                </h2>
                <div className="space-y-4 sm:space-y-6">
                  <div className="flex gap-3 sm:gap-4">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-green-100 rounded-lg sm:rounded-xl flex items-center justify-center flex-shrink-0">
                      <i className="ri-medal-line text-xl sm:text-2xl text-green-600"></i>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-base sm:text-lg lg:text-xl font-bold text-gray-900 dark:text-white mb-1 sm:mb-2 transition-colors duration-300">Проверенные материалы</h3>
                      <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400">Работаем только с надежными поставщиками, все материалы имеют сертификаты качества</p>
                    </div>
                  </div>
                  
                  <div className="flex gap-3 sm:gap-4">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-blue-100 rounded-lg sm:rounded-xl flex items-center justify-center flex-shrink-0">
                      <i className="ri-settings-3-line text-xl sm:text-2xl text-blue-600"></i>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-base sm:text-lg lg:text-xl font-bold text-gray-900 dark:text-white mb-1 sm:mb-2 transition-colors duration-300">Гибкая настройка</h3>
                      <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400">Можете выбрать базовую комплектацию или дополнить её любыми опциями по вашему желанию</p>
                    </div>
                  </div>
                  
                  <div className="flex gap-3 sm:gap-4">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-purple-100 rounded-lg sm:rounded-xl flex items-center justify-center flex-shrink-0">
                      <i className="ri-hand-coin-line text-xl sm:text-2xl text-purple-600"></i>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-base sm:text-lg lg:text-xl font-bold text-gray-900 dark:text-white mb-1 sm:mb-2 transition-colors duration-300">Оптимальная цена</h3>
                      <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400">Прямые поставки от производителей позволяют предложить лучшие цены на рынке</p>
                    </div>
                  </div>
                  
                  <div className="flex gap-3 sm:gap-4">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 bg-orange-100 rounded-lg sm:rounded-xl flex items-center justify-center flex-shrink-0">
                      <i className="ri-customer-service-2-line text-xl sm:text-2xl text-orange-600"></i>
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-base sm:text-lg lg:text-xl font-bold text-gray-900 dark:text-white mb-1 sm:mb-2 transition-colors duration-300">Экспертная поддержка</h3>
                      <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400">Наши специалисты помогут подобрать оптимальный вариант под ваш бюджет</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="relative order-1 lg:order-2">
                <img 
                  src="https://readdy.ai/api/search-image?query=construction%20worker%20in%20safety%20helmet%20examining%20premium%20wooden%20lumber%20and%20building%20materials%20in%20professional%20warehouse%2C%20high%20quality%20timber%20beams%20stacked%20neatly%2C%20industrial%20construction%20site%20with%20natural%20lighting%2C%20realistic%20photography%20style&width=800&height=900&seq=komplekt-realistic&orientation=portrait"
                  alt="Качественные материалы"
                  className="rounded-xl sm:rounded-2xl shadow-2xl w-full h-auto object-cover"
                />
                <div className="absolute -bottom-4 sm:-bottom-6 -left-4 sm:-left-6 bg-white dark:bg-gray-800 rounded-xl sm:rounded-2xl shadow-xl p-4 sm:p-6 max-w-[200px] sm:max-w-xs">
                  <div className="flex items-center gap-3 sm:gap-4">
                    <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-green-500 to-emerald-500 rounded-lg sm:rounded-xl flex items-center justify-center flex-shrink-0">
                      <i className="ri-award-line text-2xl sm:text-3xl text-white"></i>
                    </div>
                    <div>
                      <div className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white">15+</div>
                      <div className="text-xs sm:text-sm text-gray-600 dark:text-gray-400">лет опыта</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section - Mobile Optimized */}
        <section className="py-12 sm:py-16 lg:py-20 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 dark:from-gray-950 dark:via-gray-900 dark:to-gray-950 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAxOGMzLjMxNCAwIDYgMi42ODYgNiA2cy0yLjY4NiA2LTYgNi0yLTIuNjg2LTYtNiAyLjY4Ni0yIDYtNiIgc3Ryb2tlPSIjZmZmIiBzdHJva2Utd2lkdGg9IjIiLz48L2c+PC9zdmc+')] opacity-20"></div>
          </div>
          
          <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="inline-flex items-center gap-2 bg-green-500/10 border border-green-500/20 rounded-full px-3 sm:px-4 py-1.5 sm:py-2 mb-4 sm:mb-6">
              <i className="ri-customer-service-2-line text-green-400 text-sm sm:text-base"></i>
              <span className="text-green-400 font-medium text-xs sm:text-sm">Бесплатная консультация</span>
            </div>
            
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4 sm:mb-6 px-4">
              Нужна помощь с выбором комплектации?
            </h2>
            <p className="text-base sm:text-lg lg:text-xl text-gray-300 mb-8 sm:mb-10 max-w-3xl mx-auto px-4">
              Наши специалисты помогут подобрать оптимальный вариант под ваш бюджет и пожелания. 
              Расскажем о всех материалах и ответим на любые вопросы.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 justify-center px-4">
              <button 
                onClick={() => setIsModalOpen(true)}
                className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white px-6 sm:px-10 py-4 sm:py-5 rounded-xl font-bold text-base sm:text-lg transition-all shadow-xl hover:shadow-2xl hover:scale-105 cursor-pointer inline-flex items-center justify-center gap-2"
              >
                <i className="ri-phone-line text-lg sm:text-xl"></i>
                Получить консультацию
              </button>
              <a 
                href="tel:+79115098818"
                className="bg-white border-2 border-gray-200 hover:border-green-500 text-gray-900 px-6 sm:px-10 py-4 sm:py-5 rounded-xl font-bold text-base sm:text-lg transition-all shadow-lg hover:shadow-xl hover:scale-105 cursor-pointer inline-flex items-center justify-center gap-2"
              >
                <i className="ri-phone-line text-lg sm:text-xl"></i>
                +7 911 509 88 18
              </a>
            </div>
            
            <div className="mt-8 sm:mt-12 grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 max-w-4xl mx-auto">
              <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-5 sm:p-6">
                <i className="ri-time-line text-2xl sm:text-3xl text-green-400 mb-2 sm:mb-3"></i>
                <div className="text-white font-bold text-base sm:text-lg mb-1">Быстрый ответ</div>
                <div className="text-gray-400 text-xs sm:text-sm">В течение 15 минут</div>
              </div>
              <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-5 sm:p-6">
                <i className="ri-calculator-line text-2xl sm:text-3xl text-blue-400 mb-2 sm:mb-3"></i>
                <div className="text-white font-bold text-base sm:text-lg mb-1">Точный расчет</div>
                <div className="text-gray-400 text-xs sm:text-sm">Стоимости и сроков</div>
              </div>
              <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-xl p-5 sm:p-6">
                <i className="ri-gift-line text-2xl sm:text-3xl text-purple-400 mb-2 sm:mb-3"></i>
                <div className="text-white font-bold text-base sm:text-lg mb-1">Специальные условия</div>
                <div className="text-gray-400 text-xs sm:text-sm">Для новых клиентов</div>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Package Detail Modal */}
      {selectedPackage && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 rounded-3xl max-w-5xl w-full max-h-[90vh] overflow-y-auto transition-colors duration-300">
            <div className="p-4 sm:p-8">
              <div className="flex justify-between items-start mb-6 sm:mb-8">
                <div className="flex-1 pr-4">
                  <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white mb-2">{selectedPackage.name}</h2>
                  {selectedPackage.included ? (
                    <div className="flex items-center text-green-600 dark:text-green-400 font-semibold">
                      <i className="ri-checkbox-circle-fill mr-2"></i>
                      <span>Включено в базовую комплектацию</span>
                    </div>
                  ) : (
                    <div className="flex items-center text-gray-500 dark:text-gray-400 font-semibold">
                      <i className="ri-information-line mr-2"></i>
                      <span>Обсуждается индивидуально</span>
                    </div>
                  )}
                </div>
                <button
                  onClick={() => {
                    setSelectedPackage(null);
                    setSelectedRoofingType('');
                  }}
                  className="w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors flex-shrink-0"
                >
                  <i className="ri-close-line text-gray-500 dark:text-gray-400 text-xl sm:text-2xl"></i>
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
                <div>
                  <img
                    src={selectedPackage.image}
                    alt={selectedPackage.name}
                    className="w-full h-64 sm:h-96 object-cover object-center rounded-2xl mb-4"
                  />
                </div>

                <div className="space-y-4 sm:space-y-6">
                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white mb-3 text-base sm:text-lg">Описание</h3>
                    <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400 leading-relaxed">{selectedPackage.fullDescription}</p>
                  </div>

                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white mb-3 text-base sm:text-lg">Преимущества</h3>
                    <ul className="space-y-2">
                      {selectedPackage.features.map((feature: string, idx: number) => (
                        <li key={idx} className="flex items-start gap-2">
                          <i className="ri-check-line text-green-600 text-lg sm:text-xl flex-shrink-0 mt-0.5"></i>
                          <span className="text-sm sm:text-base text-gray-600 dark:text-gray-400">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-gray-50 dark:bg-gray-700 rounded-2xl p-4 sm:p-6">
                    <h3 className="font-bold text-slate-900 dark:text-white mb-4 text-base sm:text-lg">Характеристики</h3>
                    <div className="space-y-3">
                      {Object.entries(selectedPackage.specifications).map(([key, value]) => (
                        <div key={key} className="flex justify-between items-start gap-4">
                          <span className="text-sm sm:text-base text-gray-600 dark:text-gray-400">{key}:</span>
                          <span className="text-sm sm:text-base font-semibold text-slate-900 dark:text-white text-right">{value as string}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Options Section for Roofing and Foundation */}
                  {selectedPackage.hasOptions && (
                    <div className="bg-gray-50 dark:bg-gray-700/50 rounded-2xl p-4 sm:p-6 border-2 border-gray-200 dark:border-gray-600">
                      <h3 className="font-bold text-slate-900 dark:text-white mb-4 text-base sm:text-lg flex items-center gap-2">
                        <i className="ri-information-line text-gray-500 dark:text-gray-400"></i>
                        Доступные варианты
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                        Выберите вариант, чтобы узнать подробную информацию:
                      </p>
                      <div className="space-y-2">
                        {(selectedPackage.optionType === 'roofing' ? roofingTypes : foundationTypes).map((option: any) => (
                          <button
                            key={option.value}
                            onClick={() => setSelectedRoofingType(option.value)}
                            className="w-full text-left px-4 py-3 bg-white dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700/50 rounded-xl transition-all cursor-pointer border-2 border-transparent hover:border-gray-400 dark:hover:border-gray-500"
                          >
                            <div className="flex items-center justify-between">
                              <span className="font-semibold text-slate-900 dark:text-white">{option.label}</span>
                              <i className="ri-arrow-right-line text-gray-500 dark:text-gray-400"></i>
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 mt-6 sm:mt-8">
                <button
                  onClick={() => {
                    setSelectedPackage(null);
                    setSelectedRoofingType('');
                  }}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white py-3 sm:py-4 px-4 sm:px-6 rounded-xl transition-all whitespace-nowrap cursor-pointer font-bold text-sm sm:text-base"
                >
                  Понятно
                </button>
                <button
                  onClick={() => {
                    setSelectedPackage(null);
                    setSelectedRoofingType('');
                    setIsModalOpen(true);
                  }}
                  className="flex-1 border-2 border-green-600 text-green-600 py-3 sm:py-4 px-4 sm:px-6 rounded-xl hover:bg-green-50 dark:hover:bg-green-900/20 transition-all whitespace-nowrap cursor-pointer font-bold text-sm sm:text-base"
                >
                  Получить консультацию
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Roofing/Foundation Type Detail Modal */}
      {selectedRoofingType && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 rounded-3xl max-w-3xl w-full max-h-[90vh] overflow-y-auto transition-colors duration-300">
            <div className="p-4 sm:p-8">
              {(() => {
                const optionsList = selectedPackage?.optionType === 'roofing' ? roofingTypes : foundationTypes;
                const selectedTypeData = optionsList.find((t: any) => t.value === selectedRoofingType);
                if (!selectedTypeData) return null;

                return (
                  <>
                    <div className="flex justify-between items-start mb-6 sm:mb-8">
                      <div className="flex-1 pr-4">
                        <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white mb-2">
                          {selectedTypeData.label}
                        </h2>
                        <p className="text-gray-600 dark:text-gray-400">{selectedTypeData.description}</p>
                      </div>
                      <button
                        onClick={() => setSelectedRoofingType('')}
                        className="w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors flex-shrink-0"
                      >
                        <i className="ri-close-line text-gray-500 dark:text-gray-400 text-xl sm:text-2xl"></i>
                      </button>
                    </div>

                    <div className="space-y-6">
                      <div>
                        <h3 className="font-bold text-slate-900 dark:text-white mb-3 text-base sm:text-lg">Преимущества</h3>
                        <ul className="space-y-2">
                          {selectedTypeData.features.map((feature: string, idx: number) => (
                            <li key={idx} className="flex items-start gap-2">
                              <i className="ri-check-line text-green-600 text-lg sm:text-xl flex-shrink-0 mt-0.5"></i>
                              <span className="text-sm sm:text-base text-gray-600 dark:text-gray-400">{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="bg-gray-50 dark:bg-gray-700 rounded-2xl p-4 sm:p-6">
                        <h3 className="font-bold text-slate-900 dark:text-white mb-4 text-base sm:text-lg">Технические характеристики</h3>
                        <div className="space-y-3">
                          {Object.entries(selectedTypeData.specifications).map(([key, value]) => (
                            <div key={key} className="flex justify-between items-start gap-4">
                              <span className="text-sm sm:text-base text-gray-600 dark:text-gray-400">{key}:</span>
                              <span className="text-sm sm:text-base font-semibold text-slate-900 dark:text-white text-right">{value as string}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
                      <button
                        onClick={() => setSelectedRoofingType('')}
                        className="flex-1 bg-green-600 hover:bg-green-700 text-white py-3 sm:py-4 px-4 sm:px-6 rounded-xl transition-all whitespace-nowrap cursor-pointer font-bold text-sm sm:text-base"
                      >
                        Назад
                      </button>
                      <button
                        onClick={() => {
                          setSelectedRoofingType('');
                          setSelectedPackage(null);
                          setIsModalOpen(true);
                        }}
                        className="flex-1 border-2 border-green-600 text-green-600 py-3 sm:py-4 px-4 sm:px-6 rounded-xl hover:bg-green-50 dark:hover:bg-green-900/20 transition-all whitespace-nowrap cursor-pointer font-bold text-sm sm:text-base"
                      >
                        Получить консультацию
                      </button>
                    </div>
                  </>
                );
              })()}
            </div>
          </div>
        </div>
      )}

      {/* Option Detail Modal */}
      {selectedOption && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 rounded-3xl max-w-5xl w-full max-h-[90vh] overflow-y-auto transition-colors duration-300">
            <div className="p-4 sm:p-8">
              <div className="flex justify-between items-start mb-6 sm:mb-8">
                <div className="flex-1 pr-4">
                  <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white mb-2">{selectedOption.name}</h2>
                  <p className="text-lg sm:text-xl text-green-600 font-bold">{selectedOption.price}</p>
                </div>
                <button
                  onClick={() => setSelectedOption(null)}
                  className="w-10 h-10 sm:w-12 sm:h-12 flex items-center justify-center cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors flex-shrink-0"
                >
                  <i className="ri-close-line text-gray-500 dark:text-gray-400 text-2xl"></i>
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
                <div>
                  <img
                    src={selectedOption.image}
                    alt={selectedOption.name}
                    className="w-full h-64 sm:h-96 object-cover object-center rounded-2xl mb-4"
                  />
                </div>

                <div className="space-y-4 sm:space-y-6">
                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white mb-3 text-base sm:text-lg">Описание</h3>
                    <p className="text-sm sm:text-base text-gray-600 dark:text-gray-400 leading-relaxed">{selectedOption.fullDescription}</p>
                  </div>

                  <div>
                    <h3 className="font-bold text-slate-900 dark:text-white mb-3 text-base sm:text-lg">Преимущества</h3>
                    <ul className="space-y-2">
                      {selectedOption.features.map((feature: string, idx: number) => (
                        <li key={idx} className="flex items-start gap-2">
                          <i className="ri-check-line text-green-600 text-lg sm:text-xl flex-shrink-0 mt-0.5"></i>
                          <span className="text-sm sm:text-base text-gray-600 dark:text-gray-400">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-gray-50 dark:bg-gray-700 rounded-2xl p-4 sm:p-6">
                    <h3 className="font-bold text-slate-900 dark:text-white mb-4 text-base sm:text-lg">Характеристики</h3>
                    <div className="space-y-3">
                      {Object.entries(selectedOption.specifications).map(([key, value]) => (
                        <div key={key} className="flex justify-between items-start gap-4">
                          <span className="text-sm sm:text-base text-gray-600 dark:text-gray-400">{key}:</span>
                          <span className="text-sm sm:text-base font-semibold text-slate-900 dark:text-white text-right">{value as string}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
                <button
                  onClick={() => setSelectedOption(null)}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white py-3 sm:py-4 px-4 sm:px-6 rounded-xl transition-all whitespace-nowrap cursor-pointer font-bold text-sm sm:text-base"
                >
                  Добавить в расчет
                </button>
                <button
                  onClick={() => {
                    setSelectedOption(null);
                    setIsModalOpen(true);
                  }}
                  className="flex-1 border-2 border-green-600 text-green-600 py-3 sm:py-4 px-4 sm:px-6 rounded-xl hover:bg-green-50 transition-all whitespace-nowrap cursor-pointer font-bold text-sm sm:text-base"
                >
                  Получить консультацию
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Consultation Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 rounded-3xl max-w-md w-full p-6 sm:p-8 relative transition-colors duration-300">
            <button
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 w-10 h-10 flex items-center justify-center cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 rounded-full transition-colors"
            >
              <i className="ri-close-line text-gray-500 dark:text-gray-400 text-2xl"></i>
            </button>

            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2 transition-colors duration-300">Получить консультацию</h2>
              <p className="text-gray-600 dark:text-gray-400 transition-colors duration-300">Заполните данные и наш менеджер свяжется с вами в ближайшее время</p>
            </div>

            <form className="space-y-4" data-readdy-form id="komplektaciya-consultation-form">
              <div>
                <input
                  type="text"
                  name="name"
                  placeholder="Имя"
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-colors duration-300"
                  required
                />
              </div>
              <div>
                <input
                  type="tel"
                  name="phone"
                  placeholder="+7 (000) 000-00-00"
                  className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 dark:bg-gray-700 dark:text-white rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent transition-colors duration-300"
                  required
                />
              </div>
              <div className="flex items-start">
                <input
                  type="checkbox"
                  name="agreement"
                  className="mt-1 mr-3 h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 dark:border-gray-600 rounded"
                  required
                />
                <label className="text-sm text-gray-600 dark:text-gray-400 transition-colors duration-300">
                  Я принимаю условия Политики Конфиденциальности и даю согласие на обработку персональных данных
                </label>
              </div>
              <button
                type="submit"
                className="w-full bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors whitespace-nowrap cursor-pointer"
              >
                Отправить
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
};

export default KomplektaciyaPage;
