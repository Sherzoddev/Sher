import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createClient } from '@supabase/supabase-js';
import ConsultationModal from '../../components/base/ConsultationModal';

const supabase = createClient(
  import.meta.env.VITE_PUBLIC_SUPABASE_URL,
  import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY
);

interface Project {
  id: string;
  title: string;
  category: string;
  price: number;
  area: number;
  dimensions: string;
  description: string;
  features: string[];
  images: string[];
  rooms: string;
  foundation: string;
  walls: string;
  roof: string;
  is_featured: boolean;
}

const DvumodulnyePage: React.FC = () => {
  const [isConsultationModalOpen, setIsConsultationModalOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [showBlueprint, setShowBlueprint] = useState(false);
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('projects')
      .select('*')
      .eq('category', 'Каркасные дома')
      .eq('is_active', true)
      .order('display_order', { ascending: true });

    if (error) {
      console.error('Ошибка загрузки проектов:', error);
    } else {
      setProjects(data || []);
    }
    setLoading(false);
  };

  const openProjectModal = (project: any) => {
    setSelectedProject(project);
    setShowBlueprint(false);
  };

  const closeProjectModal = () => {
    setSelectedProject(null);
    setShowBlueprint(false);
  };

  return (
    <>
      <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
        {/* Hero Section */}
        <section className="py-20 lg:py-32">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-light text-gray-900 dark:text-white mb-6 transition-colors duration-300">
                Двумодульные бани
              </h1>
              <p className="text-xl text-gray-500 dark:text-gray-400 font-light transition-colors duration-300">
                Просторные решения от 48 до 96 м²
              </p>
            </div>
          </div>
        </section>

        {/* Projects Grid */}
        <section className="pb-32">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {loading ? (
              <div className="text-center py-20">
                <div className="inline-block w-12 h-12 border-4 border-gray-200 border-t-gray-900 rounded-full animate-spin"></div>
              </div>
            ) : projects.length === 0 ? (
              <div className="text-center py-20">
                <p className="text-xl text-gray-500 dark:text-gray-400">Проекты не найдены</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {projects.map((project) => (
                  <div 
                    key={project.id}
                    onClick={() => openProjectModal(project)}
                    className="group cursor-pointer"
                  >
                    <div className="relative overflow-hidden aspect-[4/3] mb-6">
                      <img
                        src={project.images?.[0] || 'https://readdy.ai/api/search-image?query=modern%20modular%20house%20exterior%20with%20clean%20lines%20and%20contemporary%20design%2C%20simple%20background%20highlighting%20the%20architecture&width=800&height=600&seq=dvumodulnye1&orientation=landscape'}
                        alt={project.title}
                        className="w-full h-full object-cover object-top transition-transform duration-700 group-hover:scale-105"
                      />
                    </div>
                    <h3 className="text-xl font-light text-gray-900 dark:text-white mb-3 group-hover:text-gray-600 dark:group-hover:text-gray-300 transition-colors leading-tight">
                      {project.title}
                    </h3>
                    <p className="text-lg text-gray-500 dark:text-gray-400 mb-2 transition-colors duration-300">{project.area} м²</p>
                    <p className="text-lg text-gray-900 dark:text-white font-medium transition-colors duration-300">{project.price.toLocaleString()} ₽</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gray-50 dark:bg-gray-800 transition-colors duration-300">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl sm:text-4xl font-light text-gray-900 dark:text-white mb-6 transition-colors duration-300">
              Нужна консультация?
            </h2>
            <p className="text-xl text-gray-500 dark:text-gray-400 mb-10 font-light transition-colors duration-300">
              Свяжитесь с нами для обсуждения вашего проекта
            </p>
            <button
              onClick={() => setIsConsultationModalOpen(true)}
              className="bg-gray-900 dark:bg-gray-700 hover:bg-gray-800 dark:hover:bg-gray-600 text-white px-12 py-4 text-lg font-light transition-colors cursor-pointer whitespace-nowrap"
            >
              Связаться с нами
            </button>
          </div>
        </section>
      </div>

      {/* Project Modal */}
      {selectedProject && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 max-w-6xl w-full max-h-[90vh] overflow-y-auto transition-colors duration-300">
            <div className="p-8 lg:p-12">
              <div className="flex justify-between items-start mb-12">
                <div>
                  <h2 className="text-3xl lg:text-4xl font-light text-gray-900 dark:text-white mb-4 transition-colors duration-300">
                    {selectedProject.title}
                  </h2>
                  <p className="text-xl text-gray-500 dark:text-gray-400 transition-colors duration-300">{selectedProject.area} м²</p>
                </div>
                <button
                  onClick={closeProjectModal}
                  className="w-12 h-12 flex items-center justify-center cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                >
                  <i className="ri-close-line text-gray-400 dark:text-gray-500 text-2xl"></i>
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
                <div>
                  <img
                    src={selectedProject.images?.[showBlueprint ? 1 : 0] || selectedProject.images?.[0] || 'https://readdy.ai/api/search-image?query=modern%20modular%20house%20exterior%20with%20clean%20lines%20and%20contemporary%20design%2C%20simple%20background%20highlighting%20the%20architecture&width=800&height=600&seq=dvumodulnye2&orientation=landscape'}
                    alt={selectedProject.title}
                    className="w-full aspect-[4/3] object-cover object-top mb-6"
                  />
                  {selectedProject.images && selectedProject.images.length > 1 && (
                    <div className="flex gap-4">
                      <button
                        onClick={() => setShowBlueprint(false)}
                        className={`flex-1 py-3 text-center font-light transition-colors cursor-pointer whitespace-nowrap ${
                          !showBlueprint 
                            ? 'bg-gray-900 dark:bg-gray-700 text-white' 
                            : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                        }`}
                      >
                        Фото
                      </button>
                      <button
                        onClick={() => setShowBlueprint(true)}
                        className={`flex-1 py-3 text-center font-light transition-colors cursor-pointer whitespace-nowrap ${
                          showBlueprint 
                            ? 'bg-gray-900 dark:bg-gray-700 text-white' 
                            : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                        }`}
                      >
                        Чертеж
                      </button>
                    </div>
                  )}
                </div>

                <div className="space-y-8">
                  <div>
                    <p className="text-3xl font-light text-gray-900 dark:text-white mb-6 transition-colors duration-300">
                      {selectedProject.price.toLocaleString()} ₽
                    </p>
                    <p className="text-lg text-gray-600 dark:text-gray-300 font-light leading-relaxed transition-colors duration-300">
                      {selectedProject.description}
                    </p>
                  </div>

                  {selectedProject.features && selectedProject.features.length > 0 && (
                    <div>
                      <h3 className="text-lg font-light text-gray-900 dark:text-white mb-4 transition-colors duration-300">Помещения</h3>
                      <div className="space-y-2">
                        {selectedProject.features.map((feature: string, idx: number) => (
                          <div key={idx} className="flex items-center gap-3">
                            <div className="w-1 h-1 bg-gray-400 dark:bg-gray-500"></div>
                            <span className="text-gray-600 dark:text-gray-300 font-light transition-colors duration-300">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <h3 className="text-lg font-light text-gray-900 dark:text-white mb-4 transition-colors duration-300">Характеристики</h3>
                    <div className="space-y-3">
                      {selectedProject.dimensions && (
                        <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                          <span className="text-gray-500 dark:text-gray-400 font-light transition-colors duration-300">Размеры</span>
                          <span className="text-gray-900 dark:text-white font-light transition-colors duration-300">{selectedProject.dimensions}</span>
                        </div>
                      )}
                      {selectedProject.rooms && (
                        <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                          <span className="text-gray-500 dark:text-gray-400 font-light transition-colors duration-300">Комнаты</span>
                          <span className="text-gray-900 dark:text-white font-light transition-colors duration-300">{selectedProject.rooms}</span>
                        </div>
                      )}
                      {selectedProject.foundation && (
                        <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                          <span className="text-gray-500 dark:text-gray-400 font-light transition-colors duration-300">Фундамент</span>
                          <span className="text-gray-900 dark:text-white font-light transition-colors duration-300">{selectedProject.foundation}</span>
                        </div>
                      )}
                      {selectedProject.walls && (
                        <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                          <span className="text-gray-500 dark:text-gray-400 font-light transition-colors duration-300">Стены</span>
                          <span className="text-gray-900 dark:text-white font-light transition-colors duration-300">{selectedProject.walls}</span>
                        </div>
                      )}
                      {selectedProject.roof && (
                        <div className="flex justify-between py-2 border-b border-gray-100 dark:border-gray-700">
                          <span className="text-gray-500 dark:text-gray-400 font-light transition-colors duration-300">Кровля</span>
                          <span className="text-gray-900 dark:text-white font-light transition-colors duration-300">{selectedProject.roof}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      closeProjectModal();
                      setIsConsultationModalOpen(true);
                    }}
                    className="w-full bg-gray-900 dark:bg-gray-700 hover:bg-gray-800 dark:hover:bg-gray-600 text-white py-4 text-lg font-light transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Связаться с нами
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <ConsultationModal
        isOpen={isConsultationModalOpen}
        onClose={() => setIsConsultationModalOpen(false)}
      />
    </>
  );
};

export default DvumodulnyePage;
