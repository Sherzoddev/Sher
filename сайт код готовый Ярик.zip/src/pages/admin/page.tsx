import React, { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { useNavigate } from 'react-router-dom';
import MultiImageUploader from '../../components/admin/MultiImageUploader';
import ImageUploader from '../../components/admin/ImageUploader';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

const supabase = createClient(
  import.meta.env.VITE_PUBLIC_SUPABASE_URL,
  import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY
);

interface Project {
  id: string;
  title: string;
  category: string;
  price: number;
  area: number;
  dimensions: string;
  description: string;
  features: string[];
  images: string[];
  rooms: string;
  foundation: string;
  walls: string;
  roof: string;
  is_featured: boolean;
  display_order?: number;
}

interface Testimonial {
  id: string;
  author_name: string;
  author_position: string;
  author_avatar: string;
  rating: number;
  text: string;
  project_type: string;
  date: string;
  is_active: boolean;
  display_order: number;
}

interface PortfolioItem {
  id: string;
  title: string;
  category: string;
  description: string;
  location: string;
  area: number;
  completion_date: string;
  main_image: string;
  images: string[];
  features: string[];
  is_featured: boolean;
  is_active: boolean;
  display_order: number;
}

interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
  is_active: boolean;
  display_order: number;
}

interface Advantage {
  id: string;
  title: string;
  description: string;
  icon: string;
  is_active: boolean;
  display_order: number;
}

interface ContactInfo {
  id: string;
  type: string;
  value: string;
  label: string;
  is_active: boolean;
}

type ActiveTab = 'projects' | 'modulnye-doma' | 'karkasnye-doma' | 'modulnye-bani' | 'grill-doma' | 'besedki' | 'hozpostroyki' | 'testimonials' | 'portfolio' | 'faq' | 'advantages' | 'contacts';

// Sortable Card Component
const SortableProjectCard: React.FC<{
  project: Project;
  onEdit: (project: Project) => void;
  onDelete: (id: string) => void;
}> = ({ project, onEdit, onDelete }) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: project.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm hover:shadow-lg transition-shadow border border-gray-100 dark:border-gray-700"
    >
      <div className="relative aspect-[4/3] overflow-hidden rounded-t-2xl bg-gray-900">
        {project.images[0] ? (
          <img
            src={project.images[0]}
            alt={project.title}
            className="w-full h-full object-contain bg-gray-100"
          />
        ) : (
          <div className="w-full h-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
            <i className="ri-image-line text-4xl text-gray-400 dark:text-gray-500"></i>
          </div>
        )}
        {project.is_featured && (
          <div className="absolute top-3 right-3 bg-yellow-400 text-yellow-900 px-3 py-1 rounded-full text-xs font-bold">
            <i className="ri-star-fill mr-1"></i>
            Избранное
          </div>
        )}
        <div
          {...attributes}
          {...listeners}
          className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm text-slate-900 px-3 py-2 rounded-lg cursor-move hover:bg-white transition-colors"
          title="Перетащите для изменения порядка"
        >
          <i className="ri-draggable text-lg"></i>
        </div>
      </div>

      <div className="p-6">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 px-3 py-1 rounded-full font-medium">
            {project.category}
          </span>
          <span className="text-xs text-gray-500 dark:text-gray-400">{project.area} м²</span>
        </div>

        <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">{project.title}</h3>
        <p className="text-2xl font-bold text-slate-900 dark:text-white mb-4">
          {project.price.toLocaleString('ru-RU')} ₽
        </p>

        <div className="flex gap-2">
          <button
            onClick={() => onEdit(project)}
            className="flex-1 bg-slate-900 hover:bg-slate-800 text-white py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-edit-line mr-1"></i>
            Редактировать
          </button>
          <button
            onClick={() => onDelete(project.id)}
            className="px-4 bg-red-50 dark:bg-red-900 hover:bg-red-100 dark:hover:bg-red-800 text-red-600 dark:text-red-400 py-2 rounded-lg transition-colors cursor-pointer"
          >
            <i className="ri-delete-bin-line"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

// Sortable Portfolio Card
const SortablePortfolioCard: React.FC<{
  item: PortfolioItem;
  onEdit: (item: PortfolioItem) => void;
  onDelete: (id: string) => void;
}> = ({ item, onEdit, onDelete }) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: item.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm hover:shadow-lg transition-shadow border border-gray-100 dark:border-gray-700"
    >
      <div className="relative aspect-[4/3] overflow-hidden rounded-t-2xl">
        {item.main_image ? (
          <img
            src={item.main_image}
            alt={item.title}
            className="w-full h-full object-cover object-top"
          />
        ) : (
          <div className="w-full h-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
            <i className="ri-image-line text-4xl text-gray-400 dark:text-gray-500"></i>
          </div>
        )}
        <div
          {...attributes}
          {...listeners}
          className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm text-slate-900 px-3 py-2 rounded-lg cursor-move hover:bg-white transition-colors"
          title="Перетащите для изменения порядка"
        >
          <i className="ri-draggable text-lg"></i>
        </div>
      </div>

      <div className="p-6">
        <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">{item.title}</h3>
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">{item.location}</p>

        <div className="flex gap-2">
          <button
            onClick={() => onEdit(item)}
            className="flex-1 bg-slate-900 hover:bg-slate-800 text-white py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
          >
            <i className="ri-edit-line mr-1"></i>
            Редактировать
          </button>
          <button
            onClick={() => onDelete(item.id)}
            className="px-4 bg-red-50 dark:bg-red-900 hover:bg-red-100 dark:hover:bg-red-800 text-red-600 dark:text-red-400 py-2 rounded-lg transition-colors cursor-pointer"
          >
            <i className="ri-delete-bin-line"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

const AdminPage = () => {
  const [activeTab, setActiveTab] = useState<ActiveTab>('projects');
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const navigate = useNavigate();

  // Projects
  const [projects, setProjects] = useState<Project[]>([]);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);

  // Testimonials
  const [testimonials, setTestimonials] = useState<any[]>([]);
  const [editingTestimonial, setEditingTestimonial] = useState<Testimonial | null>(null);
  const [isTestimonialModalOpen, setIsTestimonialModalOpen] = useState(false);

  // Portfolio
  const [portfolioItems, setPortfolioItems] = useState<PortfolioItem[]>([]);
  const [editingPortfolio, setEditingPortfolio] = useState<PortfolioItem | null>(null);
  const [isPortfolioModalOpen, setIsPortfolioModalOpen] = useState(false);

  // FAQ
  const [faqItems, setFaqItems] = useState<any[]>([]);
  const [editingFAQ, setEditingFAQ] = useState<FAQItem | null>(null);
  const [isFAQModalOpen, setIsFAQModalOpen] = useState(false);

  // Advantages
  const [advantages, setAdvantages] = useState<any[]>([]);
  const [editingAdvantage, setEditingAdvantage] = useState<Advantage | null>(null);
  const [isAdvantageModalOpen, setIsAdvantageModalOpen] = useState(false);

  // Contacts
  const [contacts, setContacts] = useState<ContactInfo[]>([]);
  const [editingContact, setEditingContact] = useState<ContactInfo | null>(null);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);

  const categories = [
    'Модульные дома',
    'Каркасные дома',
    'Модульные бани',
    'Гриль-дома',
    'Беседки',
    'Хозпостройки'
  ];

  useEffect(() => {
    checkAuth();
  }, []);

  useEffect(() => {
    if (isAuthenticated) {
      loadData();
    }
  }, [isAuthenticated, activeTab]);

  const checkAuth = async () => {
    const { data: { session } } = await supabase.auth.getSession();
    setIsAuthenticated(!!session);
    setLoading(false);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      setLoginError('Неверный email или пароль');
    } else {
      setIsAuthenticated(true);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setIsAuthenticated(false);
    navigate('/');
  };

  const loadData = async () => {
    setLoading(true);
    
    if (activeTab === 'projects') {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .order('display_order', { ascending: true });
      if (!error) setProjects(data || []);
    } else if (activeTab === 'modulnye-doma') {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('category', 'Модульные дома')
        .order('display_order', { ascending: true });
      if (!error) setProjects(data || []);
    } else if (activeTab === 'karkasnye-doma') {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('category', 'Каркасные дома')
        .order('display_order', { ascending: true });
      if (!error) setProjects(data || []);
    } else if (activeTab === 'modulnye-bani') {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('category', 'Модульные бани')
        .order('display_order', { ascending: true });
      if (!error) setProjects(data || []);
    } else if (activeTab === 'grill-doma') {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('category', 'Гриль-дома')
        .order('display_order', { ascending: true });
      if (!error) setProjects(data || []);
    } else if (activeTab === 'besedki') {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('category', 'Беседки')
        .order('display_order', { ascending: true });
      if (!error) setProjects(data || []);
    } else if (activeTab === 'hozpostroyki') {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('category', 'Хозпостройки')
        .order('display_order', { ascending: true });
      if (!error) setProjects(data || []);
    } else if (activeTab === 'faq') {
      const { data, error } = await supabase
        .from('faq_items')
        .select('*')
        .order('order_index', { ascending: true });
      if (!error) setFaqItems(data || []);
    } else if (activeTab === 'testimonials') {
      const { data, error } = await supabase
        .from('testimonials')
        .select('*')
        .order('created_at', { ascending: false });
      if (!error) setTestimonials(data || []);
    } else if (activeTab === 'portfolio') {
      const { data, error } = await supabase
        .from('portfolio_items')
        .select('*')
        .order('created_at', { ascending: false });
      if (!error) setPortfolioItems(data || []);
    } else if (activeTab === 'advantages') {
      const { data, error } = await supabase
        .from('company_advantages')
        .select('*')
        .order('order_index', { ascending: true });
      if (!error) setAdvantages(data || []);
    } else if (activeTab === 'contacts') {
      const { data, error } = await supabase
        .from('contact_info')
        .select('*')
        .limit(1)
        .single();
      if (!error) setContacts(data ? [data] : []);
    }
    
    setLoading(false);
  };

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const loadProjects = async () => {
    const { data, error } = await supabase
      .from('projects')
      .select('*')
      .order('display_order', { ascending: true });

    if (!error && data) {
      setProjects(data);
    }
  };

  const loadTestimonials = async () => {
    const { data, error } = await supabase
      .from('testimonials')
      .select('*')
      .order('display_order', { ascending: true });

    if (!error && data) {
      setTestimonials(data);
    }
  };

  const loadPortfolio = async () => {
    const { data, error } = await supabase
      .from('portfolio_items')
      .select('*')
      .order('display_order', { ascending: true });

    if (!error && data) {
      setPortfolioItems(data);
    }
  };

  const loadFAQ = async () => {
    const { data, error } = await supabase
      .from('faq_items')
      .select('*')
      .order('display_order', { ascending: true });

    if (!error && data) {
      setFaqItems(data);
    }
  };

  const loadAdvantages = async () => {
    const { data, error } = await supabase
      .from('company_advantages')
      .select('*')
      .order('display_order', { ascending: true });

    if (!error && data) {
      setAdvantages(data);
    }
  };

  const loadContacts = async () => {
    const { data, error } = await supabase
      .from('contact_info')
      .select('*');

    if (!error && data) {
      setContacts(data);
    }
  };

  const showSuccess = (message: string) => {
    setSuccessMessage(message);
    setTimeout(() => setSuccessMessage(''), 3000);
  };

  // Drag and drop handlers
  const handleDragEndProjects = async (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = projects.findIndex((p) => p.id === active.id);
      const newIndex = projects.findIndex((p) => p.id === over.id);

      const newProjects = arrayMove(projects, oldIndex, newIndex);
      setProjects(newProjects);

      // Update display_order in database
      const updates = newProjects.map((project, index) => ({
        id: project.id,
        display_order: index,
      }));

      for (const update of updates) {
        await supabase
          .from('projects')
          .update({ display_order: update.display_order })
          .eq('id', update.id);
      }

      showSuccess('Порядок проектов обновлен');
    }
  };

  const handleDragEndPortfolio = async (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = portfolioItems.findIndex((p) => p.id === active.id);
      const newIndex = portfolioItems.findIndex((p) => p.id === over.id);

      const newItems = arrayMove(portfolioItems, oldIndex, newIndex);
      setPortfolioItems(newItems);

      // Update display_order in database
      const updates = newItems.map((item, index) => ({
        id: item.id,
        display_order: index,
      }));

      for (const update of updates) {
        await supabase
          .from('portfolio_items')
          .update({ display_order: update.display_order })
          .eq('id', update.id);
      }

      showSuccess('Порядок работ обновлен');
    }
  };

  // Project handlers
  const handleDeleteProject = async (id: string) => {
    if (!confirm('Вы уверены, что хотите удалить этот проект?')) return;

    const { error } = await supabase.from('projects').delete().eq('id', id);

    if (!error) {
      showSuccess('Проект удален');
      loadProjects();
    }
  };

  const handleEditProject = (project: Project) => {
    setEditingProject(project);
    setIsProjectModalOpen(true);
  };

  const handleCreateProject = () => {
    setEditingProject({
      id: '',
      title: '',
      category: 'Модульные дома',
      price: 0,
      area: 0,
      dimensions: '',
      description: '',
      features: [],
      images: [],
      rooms: '',
      foundation: '',
      walls: '',
      roof: '',
      is_featured: false,
    });
    setIsProjectModalOpen(true);
  };

  const handleSaveProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProject) return;

    const projectData = {
      title: editingProject.title,
      category: editingProject.category,
      price: editingProject.price,
      area: editingProject.area,
      dimensions: editingProject.dimensions,
      description: editingProject.description,
      features: editingProject.features,
      images: editingProject.images,
      rooms: editingProject.rooms,
      foundation: editingProject.foundation,
      walls: editingProject.walls,
      roof: editingProject.roof,
      is_featured: editingProject.is_featured,
    };

    if (editingProject.id) {
      const { error } = await supabase
        .from('projects')
        .update(projectData)
        .eq('id', editingProject.id);

      if (!error) {
        showSuccess('Проект обновлен');
        setIsProjectModalOpen(false);
        loadProjects();
      }
    } else {
      const { error } = await supabase
        .from('projects')
        .insert([projectData]);

      if (!error) {
        showSuccess('Проект создан');
        setIsProjectModalOpen(false);
        loadProjects();
      }
    }
  };

  // Testimonial handlers
  const handleDeleteTestimonial = async (id: string) => {
    if (!confirm('Удалить отзыв?')) return;
    const { error } = await supabase.from('testimonials').delete().eq('id', id);
    if (!error) {
      showSuccess('Отзыв удален');
      loadTestimonials();
    }
  };

  const handleCreateTestimonial = () => {
    setEditingTestimonial({
      id: '',
      author_name: '',
      author_position: '',
      author_avatar: '',
      rating: 5,
      text: '',
      project_type: '',
      date: new Date().toISOString().split('T')[0],
      is_active: true,
      display_order: testimonials.length,
    });
    setIsTestimonialModalOpen(true);
  };

  const handleEditTestimonial = (testimonial: Testimonial) => {
    setEditingTestimonial(testimonial);
    setIsTestimonialModalOpen(true);
  };

  const handleSaveTestimonial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTestimonial) return;

    const data = {
      author_name: editingTestimonial.author_name,
      author_position: editingTestimonial.author_position,
      author_avatar: editingTestimonial.author_avatar,
      rating: editingTestimonial.rating,
      text: editingTestimonial.text,
      project_type: editingTestimonial.project_type,
      date: editingTestimonial.date,
      is_active: editingTestimonial.is_active,
      display_order: editingTestimonial.display_order,
    };

    if (editingTestimonial.id) {
      const { error } = await supabase.from('testimonials').update(data).eq('id', editingTestimonial.id);
      if (!error) {
        showSuccess('Отзыв обновлен');
        setIsTestimonialModalOpen(false);
        loadTestimonials();
      }
    } else {
      const { error } = await supabase.from('testimonials').insert([data]);
      if (!error) {
        showSuccess('Отзыв создан');
        setIsTestimonialModalOpen(false);
        loadTestimonials();
      }
    }
  };

  // Portfolio handlers
  const handleDeletePortfolio = async (id: string) => {
    if (!confirm('Удалить работу?')) return;
    const { error } = await supabase.from('portfolio_items').delete().eq('id', id);
    if (!error) {
      showSuccess('Работа удалена');
      loadPortfolio();
    }
  };

  const handleCreatePortfolio = () => {
    setEditingPortfolio({
      id: '',
      title: '',
      category: '',
      description: '',
      location: '',
      area: 0,
      completion_date: new Date().toISOString().split('T')[0],
      main_image: '',
      images: [],
      features: [],
      is_featured: false,
      is_active: true,
      display_order: portfolioItems.length,
    });
    setIsPortfolioModalOpen(true);
  };

  const handleEditPortfolio = (item: PortfolioItem) => {
    setEditingPortfolio(item);
    setIsPortfolioModalOpen(true);
  };

  const handleSavePortfolio = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPortfolio) return;

    const data = {
      title: editingPortfolio.title,
      category: editingPortfolio.category,
      description: editingPortfolio.description,
      location: editingPortfolio.location,
      area: editingPortfolio.area,
      completion_date: editingPortfolio.completion_date,
      main_image: editingPortfolio.main_image,
      images: editingPortfolio.images,
      features: editingPortfolio.features,
      is_featured: editingPortfolio.is_featured,
      is_active: editingPortfolio.is_active,
      display_order: editingPortfolio.display_order,
    };

    if (editingPortfolio.id) {
      const { error } = await supabase.from('portfolio_items').update(data).eq('id', editingPortfolio.id);
      if (!error) {
        showSuccess('Работа обновлена');
        setIsPortfolioModalOpen(false);
        loadPortfolio();
      }
    } else {
      const { error } = await supabase.from('portfolio_items').insert([data]);
      if (!error) {
        showSuccess('Работа создана');
        setIsPortfolioModalOpen(false);
        loadPortfolio();
      }
    }
  };

  // FAQ handlers
  const handleDeleteFAQ = async (id: string) => {
    if (!confirm('Удалить вопрос?')) return;
    const { error } = await supabase.from('faq_items').delete().eq('id', id);
    if (!error) {
      showSuccess('Вопрос удален');
      loadFAQ();
    }
  };

  const handleCreateFAQ = () => {
    setEditingFAQ({
      id: '',
      question: '',
      answer: '',
      category: '',
      is_active: true,
      display_order: faqItems.length,
    });
    setIsFAQModalOpen(true);
  };

  const handleEditFAQ = (item: FAQItem) => {
    setEditingFAQ(item);
    setIsFAQModalOpen(true);
  };

  const handleSaveFAQ = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingFAQ) return;

    const data = {
      question: editingFAQ.question,
      answer: editingFAQ.answer,
      category: editingFAQ.category,
      is_active: editingFAQ.is_active,
      display_order: editingFAQ.display_order,
    };

    if (editingFAQ.id) {
      const { error } = await supabase.from('faq_items').update(data).eq('id', editingFAQ.id);
      if (!error) {
        showSuccess('Вопрос обновлен');
        setIsFAQModalOpen(false);
        loadFAQ();
      }
    } else {
      const { error } = await supabase.from('faq_items').insert([data]);
      if (!error) {
        showSuccess('Вопрос создан');
        setIsFAQModalOpen(false);
        loadFAQ();
      }
    }
  };

  // Advantage handlers
  const handleDeleteAdvantage = async (id: string) => {
    if (!confirm('Удалить преимущество?')) return;
    const { error } = await supabase.from('company_advantages').delete().eq('id', id);
    if (!error) {
      showSuccess('Преимущество удалено');
      loadAdvantages();
    }
  };

  const handleCreateAdvantage = () => {
    setEditingAdvantage({
      id: '',
      title: '',
      description: '',
      icon: 'ri-star-line',
      is_active: true,
      display_order: advantages.length,
    });
    setIsAdvantageModalOpen(true);
  };

  const handleEditAdvantage = (item: Advantage) => {
    setEditingAdvantage(item);
    setIsAdvantageModalOpen(true);
  };

  const handleSaveAdvantage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAdvantage) return;

    const data = {
      title: editingAdvantage.title,
      description: editingAdvantage.description,
      icon: editingAdvantage.icon,
      is_active: editingAdvantage.is_active,
      display_order: editingAdvantage.display_order,
    };

    if (editingAdvantage.id) {
      const { error } = await supabase.from('company_advantages').update(data).eq('id', editingAdvantage.id);
      if (!error) {
        showSuccess('Преимущество обновлено');
        setIsAdvantageModalOpen(false);
        loadAdvantages();
      }
    } else {
      const { error } = await supabase.from('company_advantages').insert([data]);
      if (!error) {
        showSuccess('Преимущество создано');
        setIsAdvantageModalOpen(false);
        loadAdvantages();
      }
    }
  };

  // Contact handlers
  const handleEditContact = (contact: ContactInfo) => {
    setEditingContact(contact);
    setIsContactModalOpen(true);
  };

  const handleSaveContact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingContact) return;

    const data = {
      value: editingContact.value,
      label: editingContact.label,
      is_active: editingContact.is_active,
    };

    const { error } = await supabase.from('contact_info').update(data).eq('id', editingContact.id);
    if (!error) {
      showSuccess('Контакт обновлен');
      setIsContactModalOpen(false);
      loadContacts();
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-slate-900 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Загрузка...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-slate-900 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <i className="ri-lock-line text-3xl text-white"></i>
            </div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">Админ-панель</h1>
            <p className="text-gray-600">Войдите для управления сайтом</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                placeholder="admin@example.com"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Пароль
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                placeholder="••••••••"
                required
              />
            </div>

            {loginError && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                {loginError}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-slate-900 hover:bg-slate-800 text-white py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
            >
              Войти
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-40">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-slate-900 rounded-xl flex items-center justify-center">
                  <i className="ri-dashboard-line text-2xl text-white"></i>
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Админ-панель</h1>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Управление сайтом</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <button
                  onClick={() => navigate('/')}
                  className="px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-home-line mr-2"></i>
                  На сайт
                </button>
                <button
                  onClick={handleLogout}
                  className="px-4 py-2 bg-red-50 dark:bg-red-900 text-red-600 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-800 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-logout-box-line mr-2"></i>
                  Выйти
                </button>
              </div>
            </div>
          </div>
        </header>

        {/* Success Message */}
        {successMessage && (
          <div className="fixed top-20 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50">
            <i className="ri-check-line mr-2"></i>
            {successMessage}
          </div>
        )}

        {/* Tabs */}
        <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex gap-2 overflow-x-auto">
              {[
                { id: 'projects', label: 'Все проекты', icon: 'ri-building-line' },
                { id: 'modulnye-doma', label: 'Модульные дома', icon: 'ri-home-smile-2-line' },
                { id: 'karkasnye-doma', label: 'Каркасные дома', icon: 'ri-building-2-line' },
                { id: 'modulnye-bani', label: 'Модульные бани', icon: 'ri-home-4-line' },
                { id: 'grill-doma', label: 'Гриль-дома', icon: 'ri-fire-line' },
                { id: 'besedki', label: 'Беседки', icon: 'ri-home-3-line' },
                { id: 'hozpostroyki', label: 'Хозпостройки', icon: 'ri-door-line' },
                { id: 'testimonials', label: 'Отзывы', icon: 'ri-chat-quote-line' },
                { id: 'portfolio', label: 'Портфолио', icon: 'ri-gallery-line' },
                { id: 'faq', label: 'FAQ', icon: 'ri-question-answer-line' },
                { id: 'advantages', label: 'Преимущества', icon: 'ri-star-line' },
                { id: 'contacts', label: 'Контакты', icon: 'ri-phone-line' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as ActiveTab)}
                  className={`px-6 py-4 font-medium transition-colors cursor-pointer whitespace-nowrap border-b-2 ${
                    activeTab === tab.id
                      ? 'border-slate-900 text-slate-900'
                      : 'border-transparent text-gray-600 dark:text-gray-400 hover:text-slate-900'
                  }`}
                >
                  <i className={`${tab.icon} mr-2`}></i>
                  {tab.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Main Content */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Projects Tab - All Categories */}
          {(activeTab === 'projects' || 
            activeTab === 'modulnye-doma' || 
            activeTab === 'karkasnye-doma' || 
            activeTab === 'modulnye-bani' || 
            activeTab === 'grill-doma' || 
            activeTab === 'besedki' || 
            activeTab === 'hozpostroyki') && (
            <>
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h2 className="text-3xl font-bold text-slate-900 dark:text-white">
                    {activeTab === 'projects' && 'Все проекты'}
                    {activeTab === 'modulnye-doma' && 'Модульные дома'}
                    {activeTab === 'karkasnye-doma' && 'Каркасные дома'}
                    {activeTab === 'modulnye-bani' && 'Модульные бани'}
                    {activeTab === 'grill-doma' && 'Гриль-дома'}
                    {activeTab === 'besedki' && 'Беседки'}
                    {activeTab === 'hozpostroyki' && 'Хозпостройки'}
                  </h2>
                  <p className="text-gray-600 dark:text-gray-400 mt-1">
                    Всего: {projects.length}
                    <span className="ml-4 text-sm">
                      <i className="ri-information-line mr-1"></i>
                      Перетащите карточки для изменения порядка
                    </span>
                  </p>
                </div>
                <button
                  onClick={handleCreateProject}
                  className="bg-slate-900 hover:bg-slate-800 text-white px-6 py-3 rounded-xl font-semibold transition-colors cursor-pointer whitespace-nowrap inline-flex items-center gap-2"
                >
                  <i className="ri-add-line text-xl"></i>
                  Добавить проект
                </button>
              </div>

              <DndContext
                sensors={sensors}
                collisionDetection={closestCenter}
                onDragEnd={handleDragEndProjects}
              >
                <SortableContext
                  items={projects.map((p) => p.id)}
                  strategy={verticalListSortingStrategy}
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {projects.map((project) => (
                      <SortableProjectCard
                        key={project.id}
                        project={project}
                        onEdit={handleEditProject}
                        onDelete={handleDeleteProject}
                      />
                    ))}
                  </div>
                </SortableContext>
              </DndContext>
            </>
          )}

          {/* Testimonials Tab */}
          {activeTab === 'testimonials' && (
            <>
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h2 className="text-3xl font-bold text-slate-900 dark:text-white">Отзывы</h2>
                  <p className="text-gray-600 dark:text-gray-400 mt-1">Всего: {testimonials.length}</p>
                </div>
                <button
                  onClick={handleCreateTestimonial}
                  className="bg-slate-900 hover:bg-slate-800 text-white px-6 py-3 rounded-xl font-semibold transition-colors cursor-pointer whitespace-nowrap inline-flex items-center gap-2"
                >
                  <i className="ri-add-line text-xl"></i>
                  Добавить отзыв
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {testimonials.map((testimonial) => (
                  <div
                    key={testimonial.id}
                    className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm hover:shadow-lg transition-shadow border border-gray-100 dark:border-gray-700 p-6"
                  >
                    <div className="flex items-start gap-4 mb-4">
                      {testimonial.author_avatar ? (
                        <img
                          src={testimonial.author_avatar}
                          alt={testimonial.author_name}
                          className="w-16 h-16 rounded-full object-cover"
                        />
                      ) : (
                        <div className="w-16 h-16 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center">
                          <i className="ri-user-line text-2xl text-gray-400 dark:text-gray-500"></i>
                        </div>
                      )}
                      <div className="flex-1">
                        <h3 className="font-bold text-slate-900 dark:text-white">{testimonial.author_name}</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{testimonial.author_position}</p>
                        <div className="flex gap-1 mt-1">
                          {[...Array(5)].map((_, i) => (
                            <i
                              key={i}
                              className={`ri-star-${i < testimonial.rating ? 'fill' : 'line'} text-yellow-400`}
                            ></i>
                          ))}
                        </div>
                      </div>
                    </div>

                    <p className="text-gray-700 dark:text-gray-300 mb-4 line-clamp-3">{testimonial.text}</p>

                    <div className="flex gap-2">
                      <button
                        onClick={() => handleEditTestimonial(testimonial)}
                        className="flex-1 bg-slate-900 hover:bg-slate-800 text-white py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <i className="ri-edit-line mr-1"></i>
                        Редактировать
                      </button>
                      <button
                        onClick={() => handleDeleteTestimonial(testimonial.id)}
                        className="px-4 bg-red-50 dark:bg-red-900 hover:bg-red-100 dark:hover:bg-red-800 text-red-600 dark:text-red-400 py-2 rounded-lg transition-colors cursor-pointer"
                      >
                        <i className="ri-delete-bin-line"></i>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* Portfolio Tab */}
          {activeTab === 'portfolio' && (
            <>
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h2 className="text-3xl font-bold text-slate-900 dark:text-white">Портфолио</h2>
                  <p className="text-gray-600 dark:text-gray-400 mt-1">
                    Всего: {portfolioItems.length}
                    <span className="ml-4 text-sm">
                      <i className="ri-information-line mr-1"></i>
                      Перетащите карточки для изменения порядка
                    </span>
                  </p>
                </div>
                <button
                  onClick={handleCreatePortfolio}
                  className="bg-slate-900 hover:bg-slate-800 text-white px-6 py-3 rounded-xl font-semibold transition-colors cursor-pointer whitespace-nowrap inline-flex items-center gap-2"
                >
                  <i className="ri-add-line text-xl"></i>
                  Добавить работу
                </button>
              </div>

              <DndContext
                sensors={sensors}
                collisionDetection={closestCenter}
                onDragEnd={handleDragEndPortfolio}
              >
                <SortableContext
                  items={portfolioItems.map((p) => p.id)}
                  strategy={verticalListSortingStrategy}
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {portfolioItems.map((item) => (
                      <SortablePortfolioCard
                        key={item.id}
                        item={item}
                        onEdit={handleEditPortfolio}
                        onDelete={handleDeletePortfolio}
                      />
                    ))}
                  </div>
                </SortableContext>
              </DndContext>
            </>
          )}

          {/* FAQ Tab */}
          {activeTab === 'faq' && (
            <>
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h2 className="text-3xl font-bold text-slate-900 dark:text-white">FAQ</h2>
                  <p className="text-gray-600 dark:text-gray-400 mt-1">Всего: {faqItems.length}</p>
                </div>
                <button
                  onClick={handleCreateFAQ}
                  className="bg-slate-900 hover:bg-slate-800 text-white px-6 py-3 rounded-xl font-semibold transition-colors cursor-pointer whitespace-nowrap inline-flex items-center gap-2"
                >
                  <i className="ri-add-line text-xl"></i>
                  Добавить вопрос
                </button>
              </div>

              <div className="space-y-4">
                {faqItems.map((item) => (
                  <div
                    key={item.id}
                    className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm hover:shadow-lg transition-shadow border border-gray-100 dark:border-gray-700 p-6"
                  >
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">{item.question}</h3>
                    <p className="text-gray-700 dark:text-gray-300 mb-4">{item.answer}</p>

                    <div className="flex gap-2">
                      <button
                        onClick={() => handleEditFAQ(item)}
                        className="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <i className="ri-edit-line mr-1"></i>
                        Редактировать
                      </button>
                      <button
                        onClick={() => handleDeleteFAQ(item.id)}
                        className="px-4 bg-red-50 dark:bg-red-900 hover:bg-red-100 dark:hover:bg-red-800 text-red-600 dark:text-red-400 py-2 rounded-lg transition-colors cursor-pointer"
                      >
                        <i className="ri-delete-bin-line"></i>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* Advantages Tab */}
          {activeTab === 'advantages' && (
            <>
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h2 className="text-3xl font-bold text-slate-900 dark:text-white">Преимущества</h2>
                  <p className="text-gray-600 dark:text-gray-400 mt-1">Всего: {advantages.length}</p>
                </div>
                <button
                  onClick={handleCreateAdvantage}
                  className="bg-slate-900 hover:bg-slate-800 text-white px-6 py-3 rounded-xl font-semibold transition-colors cursor-pointer whitespace-nowrap inline-flex items-center gap-2"
                >
                  <i className="ri-add-line text-xl"></i>
                  Добавить преимущество
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {advantages.map((item) => (
                  <div
                    key={item.id}
                    className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm hover:shadow-lg transition-shadow border border-gray-100 dark:border-gray-700 p-6"
                  >
                    <div className="w-12 h-12 bg-slate-900 rounded-xl flex items-center justify-center mb-4">
                      <i className={`${item.icon} text-2xl text-white`}></i>
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">{item.title}</h3>
                    <p className="text-gray-700 dark:text-gray-300 mb-4">{item.description}</p>

                    <div className="flex gap-2">
                      <button
                        onClick={() => handleEditAdvantage(item)}
                        className="flex-1 bg-slate-900 hover:bg-slate-800 text-white py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <i className="ri-edit-line mr-1"></i>
                        Редактировать
                      </button>
                      <button
                        onClick={() => handleDeleteAdvantage(item.id)}
                        className="px-4 bg-red-50 dark:bg-red-900 hover:bg-red-100 dark:hover:bg-red-800 text-red-600 dark:text-red-400 py-2 rounded-lg transition-colors cursor-pointer"
                      >
                        <i className="ri-delete-bin-line"></i>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* Contacts Tab */}
          {activeTab === 'contacts' && (
            <>
              <div className="mb-8">
                <h2 className="text-3xl font-bold text-slate-900 dark:text-white">Контактная информация</h2>
                <p className="text-gray-600 dark:text-gray-400 mt-1">Управление контактами</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {contacts.map((contact) => (
                  <div
                    key={contact.id}
                    className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm hover:shadow-lg transition-shadow border border-gray-100 dark:border-gray-700 p-6"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">{contact.label}</h3>
                        <p className="text-gray-700 dark:text-gray-300">{contact.value}</p>
                      </div>
                      <button
                        onClick={() => handleEditContact(contact)}
                        className="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <i className="ri-edit-line mr-1"></i>
                        Изменить
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </main>

        {/* Project Modal */}
        {isProjectModalOpen && editingProject && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col">
              <div className="p-6 border-b border-gray-200 flex justify-between items-center">
                <h2 className="text-2xl font-bold text-slate-900">
                  {editingProject.id ? 'Редактировать проект' : 'Новый проект'}
                </h2>
                <button
                  onClick={() => setIsProjectModalOpen(false)}
                  className="w-8 h-8 flex items-center justify-center cursor-pointer hover:bg-gray-100 rounded-full transition-colors"
                >
                  <i className="ri-close-line text-xl text-gray-500"></i>
                </button>
              </div>

              <form onSubmit={handleSaveProject} className="flex-1 overflow-y-auto p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Название *
                    </label>
                    <input
                      type="text"
                      value={editingProject.title}
                      onChange={(e) => setEditingProject({ ...editingProject, title: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Категория *
                    </label>
                    <select
                      value={editingProject.category}
                      onChange={(e) => setEditingProject({ ...editingProject, category: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                      required
                    >
                      {categories.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Цена (₽) *
                    </label>
                    <input
                      type="number"
                      value={editingProject.price}
                      onChange={(e) => setEditingProject({ ...editingProject, price: parseFloat(e.target.value) })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Площадь (м²) *
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={editingProject.area}
                      onChange={(e) => setEditingProject({ ...editingProject, area: parseFloat(e.target.value) })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Размеры
                    </label>
                    <input
                      type="text"
                      value={editingProject.dimensions}
                      onChange={(e) => setEditingProject({ ...editingProject, dimensions: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                      placeholder="6м x 2.4м"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Помещения
                    </label>
                    <input
                      type="text"
                      value={editingProject.rooms}
                      onChange={(e) => setEditingProject({ ...editingProject, rooms: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                      placeholder="2 спальни, гостиная"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Фундамент
                    </label>
                    <input
                      type="text"
                      value={editingProject.foundation}
                      onChange={(e) => setEditingProject({ ...editingProject, foundation: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                      placeholder="Свайно-винтовой"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Стены
                    </label>
                    <input
                      type="text"
                      value={editingProject.walls}
                      onChange={(e) => setEditingProject({ ...editingProject, walls: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                      placeholder="Каркасная конструкция"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Кровля
                    </label>
                    <input
                      type="text"
                      value={editingProject.roof}
                      onChange={(e) => setEditingProject({ ...editingProject, roof: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                      placeholder="Двускатная"
                    />
                  </div>

                  <div className="flex items-center">
                    <label className="flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editingProject.is_featured}
                        onChange={(e) => setEditingProject({ ...editingProject, is_featured: e.target.checked })}
                        className="w-4 h-4 text-slate-900 border-gray-300 rounded focus:ring-slate-900 cursor-pointer"
                      />
                      <span className="ml-2 text-sm font-medium text-gray-700">
                        Избранный
                      </span>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Описание *
                  </label>
                  <textarea
                    value={editingProject.description}
                    onChange={(e) => setEditingProject({ ...editingProject, description: e.target.value })}
                    rows={3}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-sm font-medium text-gray-700">
                      Особенности
                    </label>
                    <button
                      type="button"
                      onClick={() => setEditingProject({ ...editingProject, features: [...editingProject.features, ''] })}
                      className="text-xs text-slate-900 hover:text-slate-700 font-medium cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-add-line mr-1"></i>
                      Добавить
                    </button>
                  </div>
                  <div className="space-y-2">
                    {editingProject.features.map((feature, index) => (
                      <div key={index} className="flex gap-2">
                        <input
                          type="text"
                          value={feature}
                          onChange={(e) => {
                            const newFeatures = [...editingProject.features];
                            newFeatures[index] = e.target.value;
                            setEditingProject({ ...editingProject, features: newFeatures });
                          }}
                          className="flex-1 px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                          placeholder="Особенность"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            const newFeatures = editingProject.features.filter((_, i) => i !== index);
                            setEditingProject({ ...editingProject, features: newFeatures });
                          }}
                          className="px-3 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg transition-colors cursor-pointer"
                        >
                          <i className="ri-delete-bin-line"></i>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Изображения
                  </label>
                  <MultiImageUploader
                    images={editingProject.images}
                    onImagesChange={(images) => setEditingProject({ ...editingProject, images })}
                    maxImages={10}
                  />
                </div>
              </form>

              <div className="p-4 border-t border-gray-200 flex gap-3">
                <button
                  onClick={handleSaveProject}
                  className="flex-1 bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap text-sm"
                >
                  {editingProject.id ? 'Сохранить' : 'Создать'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsProjectModalOpen(false)}
                  className="px-6 border-2 border-gray-300 text-gray-700 py-2.5 rounded-lg font-semibold hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap text-sm"
                >
                  Отмена
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Testimonial Modal */}
        {isTestimonialModalOpen && editingTestimonial && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
              <div className="p-6 border-b border-gray-200 flex justify-between items-center">
                <h2 className="text-2xl font-bold text-slate-900">
                  {editingTestimonial.id ? 'Редактировать отзыв' : 'Новый отзыв'}
                </h2>
                <button
                  onClick={() => setIsTestimonialModalOpen(false)}
                  className="w-8 h-8 flex items-center justify-center cursor-pointer hover:bg-gray-100 rounded-full transition-colors"
                >
                  <i className="ri-close-line text-xl text-gray-500"></i>
                </button>
              </div>

              <form onSubmit={handleSaveTestimonial} className="flex-1 overflow-y-auto p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Имя автора *
                    </label>
                    <input
                      type="text"
                      value={editingTestimonial.author_name}
                      onChange={(e) => setEditingTestimonial({ ...editingTestimonial, author_name: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Должность/Проект
                    </label>
                    <input
                      type="text"
                      value={editingTestimonial.author_position}
                      onChange={(e) => setEditingTestimonial({ ...editingTestimonial, author_position: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Рейтинг *
                    </label>
                    <select
                      value={editingTestimonial.rating}
                      onChange={(e) => setEditingTestimonial({ ...editingTestimonial, rating: parseInt(e.target.value) })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                      required
                    >
                      {[5, 4, 3, 2, 1].map((rating) => (
                        <option key={rating} value={rating}>
                          {rating} звезд
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Дата
                    </label>
                    <input
                      type="date"
                      value={editingTestimonial.date}
                      onChange={(e) => setEditingTestimonial({ ...editingTestimonial, date: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Фото автора
                  </label>
                  <ImageUploader
                    currentImage={editingTestimonial.author_avatar}
                    onUpload={(url) => setEditingTestimonial({ ...editingTestimonial, author_avatar: url })}
                    label="Загрузить фото"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Текст отзыва *
                  </label>
                  <textarea
                    value={editingTestimonial.text}
                    onChange={(e) => setEditingTestimonial({ ...editingTestimonial, text: e.target.value })}
                    rows={4}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    required
                  />
                </div>

                <div className="flex items-center">
                  <label className="flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingTestimonial.is_active}
                      onChange={(e) => setEditingTestimonial({ ...editingTestimonial, is_active: e.target.checked })}
                      className="w-4 h-4 text-slate-900 border-gray-300 rounded focus:ring-slate-900 cursor-pointer"
                    />
                    <span className="ml-2 text-sm font-medium text-gray-700">
                      Активен
                    </span>
                  </label>
                </div>
              </form>

              <div className="p-4 border-t border-gray-200 flex gap-3">
                <button
                  onClick={handleSaveTestimonial}
                  className="flex-1 bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap text-sm"
                >
                  {editingTestimonial.id ? 'Сохранить' : 'Создать'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsTestimonialModalOpen(false)}
                  className="px-6 border-2 border-gray-300 text-gray-700 py-2.5 rounded-lg font-semibold hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap text-sm"
                >
                  Отмена
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Portfolio Modal */}
        {isPortfolioModalOpen && editingPortfolio && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col">
              <div className="p-6 border-b border-gray-200 flex justify-between items-center">
                <h2 className="text-2xl font-bold text-slate-900">
                  {editingPortfolio.id ? 'Редактировать работу' : 'Новая работа'}
                </h2>
                <button
                  onClick={() => setIsPortfolioModalOpen(false)}
                  className="w-8 h-8 flex items-center justify-center cursor-pointer hover:bg-gray-100 rounded-full transition-colors"
                >
                  <i className="ri-close-line text-xl text-gray-500"></i>
                </button>
              </div>

              <form onSubmit={handleSavePortfolio} className="flex-1 overflow-y-auto p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Название *
                    </label>
                    <input
                      type="text"
                      value={editingPortfolio.title}
                      onChange={(e) => setEditingPortfolio({ ...editingPortfolio, title: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Категория
                    </label>
                    <input
                      type="text"
                      value={editingPortfolio.category}
                      onChange={(e) => setEditingPortfolio({ ...editingPortfolio, category: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Локация
                    </label>
                    <input
                      type="text"
                      value={editingPortfolio.location}
                      onChange={(e) => setEditingPortfolio({ ...editingPortfolio, location: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Площадь (м²)
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      value={editingPortfolio.area}
                      onChange={(e) => setEditingPortfolio({ ...editingPortfolio, area: parseFloat(e.target.value) })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Дата завершения
                    </label>
                    <input
                      type="date"
                      value={editingPortfolio.completion_date}
                      onChange={(e) => setEditingPortfolio({ ...editingPortfolio, completion_date: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    />
                  </div>

                  <div className="flex items-center gap-4">
                    <label className="flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editingPortfolio.is_featured}
                        onChange={(e) => setEditingPortfolio({ ...editingPortfolio, is_featured: e.target.checked })}
                        className="w-4 h-4 text-slate-900 border-gray-300 rounded focus:ring-slate-900 cursor-pointer"
                      />
                      <span className="ml-2 text-sm font-medium text-gray-700">
                        Избранное
                      </span>
                    </label>
                    <label className="flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={editingPortfolio.is_active}
                        onChange={(e) => setEditingPortfolio({ ...editingPortfolio, is_active: e.target.checked })}
                        className="w-4 h-4 text-slate-900 border-gray-300 rounded focus:ring-slate-900 cursor-pointer"
                      />
                      <span className="ml-2 text-sm font-medium text-gray-700">
                        Активно
                      </span>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Описание
                  </label>
                  <textarea
                    value={editingPortfolio.description}
                    onChange={(e) => setEditingPortfolio({ ...editingPortfolio, description: e.target.value })}
                    rows={3}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Главное изображение
                  </label>
                  <ImageUploader
                    currentImage={editingPortfolio.main_image}
                    onUpload={(url) => setEditingPortfolio({ ...editingPortfolio, main_image: url })}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Галерея изображений
                  </label>
                  <MultiImageUploader
                    images={editingPortfolio.images}
                    onImagesChange={(images) => setEditingPortfolio({ ...editingPortfolio, images })}
                    maxImages={15}
                  />
                </div>
              </form>

              <div className="p-4 border-t border-gray-200 flex gap-3">
                <button
                  onClick={handleSavePortfolio}
                  className="flex-1 bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap text-sm"
                >
                  {editingPortfolio.id ? 'Сохранить' : 'Создать'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsPortfolioModalOpen(false)}
                  className="px-6 border-2 border-gray-300 text-gray-700 py-2.5 rounded-lg font-semibold hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap text-sm"
                >
                  Отмена
                </button>
              </div>
            </div>
          </div>
        )}

        {/* FAQ Modal */}
        {isFAQModalOpen && editingFAQ && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
              <div className="p-6 border-b border-gray-200 flex justify-between items-center">
                <h2 className="text-2xl font-bold text-slate-900">
                  {editingFAQ.id ? 'Редактировать вопрос' : 'Новый вопрос'}
                </h2>
                <button
                  onClick={() => setIsFAQModalOpen(false)}
                  className="w-8 h-8 flex items-center justify-center cursor-pointer hover:bg-gray-100 rounded-full transition-colors"
                >
                  <i className="ri-close-line text-xl text-gray-500"></i>
                </button>
              </div>

              <form onSubmit={handleSaveFAQ} className="flex-1 overflow-y-auto p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Вопрос *
                  </label>
                  <input
                    type="text"
                    value={editingFAQ.question}
                    onChange={(e) => setEditingFAQ({ ...editingFAQ, question: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Ответ *
                  </label>
                  <textarea
                    value={editingFAQ.answer}
                    onChange={(e) => setEditingFAQ({ ...editingFAQ, answer: e.target.value })}
                    rows={5}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Категория
                  </label>
                  <input
                    type="text"
                    value={editingFAQ.category}
                    onChange={(e) => setEditingFAQ({ ...editingFAQ, category: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                  />
                </div>

                <div className="flex items-center">
                  <label className="flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingFAQ.is_active}
                      onChange={(e) => setEditingFAQ({ ...editingFAQ, is_active: e.target.checked })}
                      className="w-4 h-4 text-slate-900 border-gray-300 rounded focus:ring-slate-900 cursor-pointer"
                    />
                    <span className="ml-2 text-sm font-medium text-gray-700">
                      Активен
                    </span>
                  </label>
                </div>
              </form>

              <div className="p-4 border-t border-gray-200 flex gap-3">
                <button
                  onClick={handleSaveFAQ}
                  className="flex-1 bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap text-sm"
                >
                  {editingFAQ.id ? 'Сохранить' : 'Создать'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsFAQModalOpen(false)}
                  className="px-6 border-2 border-gray-300 text-gray-700 py-2.5 rounded-lg font-semibold hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap text-sm"
                >
                  Отмена
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Advantage Modal */}
        {isAdvantageModalOpen && editingAdvantage && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-hidden flex flex-col">
              <div className="p-6 border-b border-gray-200 flex justify-between items-center">
                <h2 className="text-2xl font-bold text-slate-900">
                  {editingAdvantage.id ? 'Редактировать преимущество' : 'Новое преимущество'}
                </h2>
                <button
                  onClick={() => setIsAdvantageModalOpen(false)}
                  className="w-8 h-8 flex items-center justify-center cursor-pointer hover:bg-gray-100 rounded-full transition-colors"
                >
                  <i className="ri-close-line text-xl text-gray-500"></i>
                </button>
              </div>

              <form onSubmit={handleSaveAdvantage} className="flex-1 overflow-y-auto p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Заголовок *
                  </label>
                  <input
                    type="text"
                    value={editingAdvantage.title}
                    onChange={(e) => setEditingAdvantage({ ...editingAdvantage, title: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Описание *
                  </label>
                  <textarea
                    value={editingAdvantage.description}
                    onChange={(e) => setEditingAdvantage({ ...editingAdvantage, description: e.target.value })}
                    rows={3}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Иконка (Remix Icon класс) *
                  </label>
                  <input
                    type="text"
                    value={editingAdvantage.icon}
                    onChange={(e) => setEditingAdvantage({ ...editingAdvantage, icon: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    placeholder="ri-star-line"
                    required
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Примеры: ri-star-line, ri-shield-check-line, ri-time-line
                  </p>
                </div>

                <div className="flex items-center">
                  <label className="flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingAdvantage.is_active}
                      onChange={(e) => setEditingAdvantage({ ...editingAdvantage, is_active: e.target.checked })}
                      className="w-4 h-4 text-slate-900 border-gray-300 rounded focus:ring-slate-900 cursor-pointer"
                    />
                    <span className="ml-2 text-sm font-medium text-gray-700">
                      Активно
                    </span>
                  </label>
                </div>
              </form>

              <div className="p-4 border-t border-gray-200 flex gap-3">
                <button
                  onClick={handleSaveAdvantage}
                  className="flex-1 bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap text-sm"
                >
                  {editingAdvantage.id ? 'Сохранить' : 'Создать'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsAdvantageModalOpen(false)}
                  className="px-6 border-2 border-gray-300 text-gray-700 py-2.5 rounded-lg font-semibold hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap text-sm"
                >
                  Отмена
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Contact Modal */}
        {isContactModalOpen && editingContact && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-hidden flex flex-col">
              <div className="p-6 border-b border-gray-200 flex justify-between items-center">
                <h2 className="text-2xl font-bold text-slate-900">
                  Редактировать контакт
                </h2>
                <button
                  onClick={() => setIsContactModalOpen(false)}
                  className="w-8 h-8 flex items-center justify-center cursor-pointer hover:bg-gray-100 rounded-full transition-colors"
                >
                  <i className="ri-close-line text-xl text-gray-500"></i>
                </button>
              </div>

              <form onSubmit={handleSaveContact} className="flex-1 overflow-y-auto p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Название *
                  </label>
                  <input
                    type="text"
                    value={editingContact.label}
                    onChange={(e) => setEditingContact({ ...editingContact, label: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Значение *
                  </label>
                  <input
                    type="text"
                    value={editingContact.value}
                    onChange={(e) => setEditingContact({ ...editingContact, value: e.target.value })}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-slate-900 focus:border-transparent"
                    required
                  />
                </div>

                <div className="flex items-center">
                  <label className="flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={editingContact.is_active}
                      onChange={(e) => setEditingContact({ ...editingContact, is_active: e.target.checked })}
                      className="w-4 h-4 text-slate-900 border-gray-300 rounded focus:ring-slate-900 cursor-pointer"
                    />
                    <span className="ml-2 text-sm font-medium text-gray-700">
                      Активен
                    </span>
                  </label>
                </div>
              </form>

              <div className="p-4 border-t border-gray-200 flex gap-3">
                <button
                  onClick={handleSaveContact}
                  className="flex-1 bg-slate-900 hover:bg-slate-800 text-white py-2.5 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap text-sm"
                >
                  Сохранить
                </button>
                <button
                  type="button"
                  onClick={() => setIsContactModalOpen(false)}
                  className="px-6 border-2 border-gray-300 text-gray-700 py-2.5 rounded-lg font-semibold hover:bg-gray-50 transition-colors cursor-pointer whitespace-nowrap text-sm"
                >
                  Отмена
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// FAQ Edit Modal
const FAQEditModal: React.FC<{ item: any; onClose: () => void; onSave: (data: any) => void }> = ({ item, onClose, onSave }) => {
  const [formData, setFormData] = useState(item);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-2xl max-h-[90vh] flex flex-col">
        <div className="p-4 border-b sticky top-0 bg-white">
          <h3 className="text-xl font-bold text-gray-900">
            {item.id ? 'Редактировать вопрос' : 'Добавить вопрос'}
          </h3>
        </div>

        <div className="p-4 overflow-y-auto flex-1">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Вопрос</label>
              <input
                type="text"
                value={formData.question}
                onChange={(e) => setFormData({ ...formData, question: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Ответ</label>
              <textarea
                value={formData.answer}
                onChange={(e) => setFormData({ ...formData, answer: e.target.value })}
                rows={6}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Порядок</label>
              <input
                type="number"
                value={formData.order_index}
                onChange={(e) => setFormData({ ...formData, order_index: parseInt(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              />
            </div>
          </div>
        </div>

        <div className="p-4 border-t flex gap-3 sticky bottom-0 bg-white">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 text-sm whitespace-nowrap cursor-pointer"
          >
            Отмена
          </button>
          <button
            onClick={() => onSave(formData)}
            className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm whitespace-nowrap cursor-pointer"
          >
            Сохранить
          </button>
        </div>
      </div>
    </div>
  );
};

// Testimonial Edit Modal
const TestimonialEditModal: React.FC<{ item: any; onClose: () => void; onSave: (data: any) => void }> = ({ item, onClose, onSave }) => {
  const [formData, setFormData] = useState(item);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-xl max-h-[90vh] flex flex-col">
        <div className="p-4 border-b sticky top-0 bg-white">
          <h3 className="text-xl font-bold text-gray-900">
            {item.id ? 'Редактировать отзыв' : 'Добавить отзыв'}
          </h3>
        </div>

        <div className="p-4 overflow-y-auto flex-1">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">ID видео VK</label>
              <input
                type="text"
                value={formData.video_id}
                onChange={(e) => setFormData({ ...formData, video_id: e.target.value })}
                placeholder="456240478"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Название</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Текст кнопки</label>
              <input
                type="text"
                value={formData.button_text}
                onChange={(e) => setFormData({ ...formData, button_text: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Действие кнопки</label>
              <select
                value={formData.button_action}
                onChange={(e) => setFormData({ ...formData, button_action: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
              >
                <option value="portfolio">Портфолио</option>
                <option value="consultation">Консультация</option>
              </select>
            </div>
          </div>
        </div>

        <div className="p-4 border-t flex gap-3 sticky bottom-0 bg-white">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 text-sm whitespace-nowrap cursor-pointer"
          >
            Отмена
          </button>
          <button
            onClick={() => onSave(formData)}
            className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 text-sm whitespace-nowrap cursor-pointer"
          >
            Сохранить
          </button>
        </div>
      </div>
    </div>
  );
};

// Portfolio Edit Modal
const PortfolioEditModal: React.FC<{ item: any; onClose: () => void; onSave: (data: any) => void }> = ({ item, onClose, onSave }) => {
  const [formData, setFormData] = useState(item);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-xl max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900">
              {item.id ? 'Редактировать видео' : 'Добавить видео'}
            </h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 cursor-pointer"
            >
              <i className="ri-close-line text-2xl"></i>
            </button>
          </div>

          <form onSubmit={(e) => {
            e.preventDefault();
            onSave(formData);
          }} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                ID видео VK *
              </label>
              <input
                type="text"
                value={formData.video_id}
                onChange={(e) => setFormData({ ...formData, video_id: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                placeholder="456239464"
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                Только цифры из ссылки VK видео
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Название видео *
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                placeholder="Модульный дом 60м² - полный обзор"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Текст кнопки *
              </label>
              <input
                type="text"
                value={formData.button_text}
                onChange={(e) => setFormData({ ...formData, button_text: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                placeholder="Смотреть проект"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Действие кнопки *
              </label>
              <select
                value={formData.button_action}
                onChange={(e) => setFormData({ ...formData, button_action: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent cursor-pointer"
                required
              >
                <option value="portfolio">Перейти в портфолио</option>
                <option value="consultation">Заказать консультацию</option>
                <option value="calculator">Открыть калькулятор</option>
              </select>
            </div>

            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="is_active"
                checked={formData.is_active}
                onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
                className="w-5 h-5 text-amber-600 border-gray-300 rounded focus:ring-amber-500 cursor-pointer"
              />
              <label htmlFor="is_active" className="text-sm font-medium text-gray-700 cursor-pointer">
                Показывать на сайте
              </label>
            </div>

            <div className="flex gap-4 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium transition-colors whitespace-nowrap cursor-pointer"
              >
                Отмена
              </button>
              <button
                type="submit"
                className="flex-1 px-6 py-3 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer"
              >
                {item.id ? 'Сохранить' : 'Добавить'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AdminPage;
