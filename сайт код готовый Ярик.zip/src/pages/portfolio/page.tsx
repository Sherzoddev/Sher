import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_PUBLIC_SUPABASE_URL,
  import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY
);

interface PortfolioItem {
  id: string;
  title: string;
  category: string;
  description: string;
  location?: string;
  area?: number;
  completion_date?: string;
  main_image: string;
  images?: any;
  features?: any;
  is_featured?: boolean;
}

const PortfolioPage: React.FC = () => {
  const [selectedProject, setSelectedProject] = useState<PortfolioItem | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [portfolioItems, setPortfolioItems] = useState<PortfolioItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [isFullscreenOpen, setIsFullscreenOpen] = useState(false);
  const [fullscreenImageIndex, setFullscreenImageIndex] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState('all');

  useEffect(() => {
    loadPortfolio();
  }, []);

  const loadPortfolio = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('portfolio_items')
      .select('*')
      .eq('is_active', true)
      .order('display_order', { ascending: true });

    if (!error && data) {
      setPortfolioItems(data);
    }
    setLoading(false);
  };

  const openFullscreen = (index: number) => {
    setFullscreenImageIndex(index);
    setIsFullscreenOpen(true);
  };

  const closeFullscreen = () => {
    setIsFullscreenOpen(false);
  };

  const nextFullscreenImage = () => {
    if (selectedProject) {
      setFullscreenImageIndex((prev) => 
        prev === selectedProject.images.length - 1 ? 0 : prev + 1
      );
    }
  };

  const prevFullscreenImage = () => {
    if (selectedProject) {
      setFullscreenImageIndex((prev) => 
        prev === 0 ? selectedProject.images.length - 1 : prev - 1
      );
    }
  };

  const categories = [
    { id: 'all', name: 'Все проекты' },
    { id: 'Модульные бани', name: 'Бани' },
    { id: 'Модульные дома', name: 'Дома' },
    { id: 'Хозпостройки', name: 'Хозпостройки' }
  ];

  const filteredItems = selectedCategory === 'all' 
    ? portfolioItems 
    : portfolioItems.filter(item => {
        if (selectedCategory === 'Хозпостройки') {
          return ['Хозпостройки', 'Беседки', 'Гриль-дома'].includes(item.category);
        }
        return item.category === selectedCategory;
      });

  if (loading) {
    return (
      <div className="min-h-screen bg-white dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-green-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Загрузка проектов...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300">
      {/* Hero Section */}
      <section className="py-20 dark:bg-gray-800 transition-colors duration-300" style={{ backgroundColor: '#222222' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-white mb-4">
              Наши работы
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Более 150 реализованных проектов по всей России. Каждый объект - это воплощение качества и надежности
            </p>
          </div>
        </div>
      </section>

      {/* Filter Section */}
      <section className="py-8 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-6 py-3 rounded-lg font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  selectedCategory === category.id
                    ? 'bg-green-600 dark:bg-green-600 text-white'
                    : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Grid */}
      <section className="py-16 bg-gray-50 dark:bg-gray-800 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {filteredItems.length === 0 ? (
            <div className="text-center py-12">
              <i className="ri-folder-open-line text-6xl text-gray-400 dark:text-gray-600 mb-4"></i>
              <p className="text-xl text-gray-600 dark:text-gray-400">Проекты не найдены</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredItems.map((item) => (
                <div key={item.id} className="bg-white dark:bg-gray-700 rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-all">
                  <div className="aspect-w-4 aspect-h-3">
                    {item.main_image ? (
                      <img
                        src={item.main_image}
                        alt={item.title}
                        className="w-full h-64 object-cover object-top"
                      />
                    ) : (
                      <div className="w-full h-64 bg-gray-200 dark:bg-gray-600 flex items-center justify-center">
                        <i className="ri-image-line text-4xl text-gray-400 dark:text-gray-500"></i>
                      </div>
                    )}
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                      {item.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 mb-4">
                      {item.description}
                    </p>
                    <div className="flex justify-between items-center mb-4">
                      {item.area && (
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          Площадь: {item.area} м²
                        </span>
                      )}
                      {item.location && (
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          {item.location}
                        </span>
                      )}
                    </div>
                    <Link 
                      to="/contacts"
                      className="block w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors whitespace-nowrap cursor-pointer text-center"
                    >
                      Подробнее
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-slate-900 dark:bg-black py-16 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Готовы начать свой проект?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Получите бесплатную консультацию и расчет стоимости вашего будущего дома или бани
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="tel:+79115098818"
              className="bg-green-600 text-white py-3 px-8 rounded-lg font-semibold hover:bg-green-700 transition-colors whitespace-nowrap cursor-pointer"
            >
              Получить консультацию
            </a>
            <Link 
              to="/calculator"
              className="border-2 border-white text-white py-3 px-8 rounded-lg font-semibold hover:bg-white hover:text-slate-900 transition-colors whitespace-nowrap cursor-pointer"
            >
              Рассчитать стоимость
            </Link>
          </div>
        </div>
      </section>

      {/* Project Modal */}
      {isModalOpen && selectedProject && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 rounded-3xl max-w-5xl w-full max-h-[90vh] overflow-y-auto transition-colors duration-300">
            <div className="p-8">
              {/* ... existing header code ... */}

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                <div>
                  {/* Image Carousel */}
                  <div className="relative mb-4">
                    <img
                      src={selectedProject.images[currentImageIndex]}
                      alt={`${selectedProject.title} - фото ${currentImageIndex + 1}`}
                      className="w-full h-96 object-cover object-top rounded-2xl cursor-pointer"
                      onClick={() => openFullscreen(currentImageIndex)}
                    />
                    
                    {/* Fullscreen Icon */}
                    <button
                      onClick={() => openFullscreen(currentImageIndex)}
                      className="absolute top-4 right-4 w-10 h-10 bg-white/90 dark:bg-gray-800/90 hover:bg-white dark:hover:bg-gray-800 rounded-full flex items-center justify-center cursor-pointer transition-all shadow-lg"
                      title="Открыть в полном экране"
                    >
                      <i className="ri-fullscreen-line text-xl text-gray-800 dark:text-white"></i>
                    </button>
                    
                    {/* ... existing navigation arrows code ... */}
                  </div>

                  {/* ... existing thumbnail navigation code ... */}
                </div>

                {/* ... existing project details code ... */}
              </div>

              {/* ... existing buttons code ... */}
            </div>
          </div>
        </div>
      )}

      {/* Fullscreen Image Viewer */}
      {isFullscreenOpen && selectedProject && (
        <div className="fixed inset-0 bg-black z-[100] flex items-center justify-center">
          {/* Close Button */}
          <button
            onClick={closeFullscreen}
            className="absolute top-4 right-4 w-12 h-12 bg-white/10 hover:bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center cursor-pointer transition-all z-10"
          >
            <i className="ri-close-line text-white text-2xl"></i>
          </button>

          {/* Image Counter */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-white/10 backdrop-blur-sm text-white px-6 py-3 rounded-full text-sm font-semibold z-10">
            {fullscreenImageIndex + 1} / {selectedProject.images.length}
          </div>

          {/* Main Image */}
          <img
            src={selectedProject.images[fullscreenImageIndex]}
            alt={`${selectedProject.title} - фото ${fullscreenImageIndex + 1}`}
            className="max-w-[95vw] max-h-[95vh] object-contain"
          />

          {/* Navigation Arrows */}
          {selectedProject.images.length > 1 && (
            <>
              <button
                onClick={prevFullscreenImage}
                className="absolute left-4 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/10 hover:bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center cursor-pointer transition-all"
              >
                <i className="ri-arrow-left-s-line text-3xl text-white"></i>
              </button>
              <button
                onClick={nextFullscreenImage}
                className="absolute right-4 top-1/2 -translate-y-1/2 w-14 h-14 bg-white/10 hover:bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center cursor-pointer transition-all"
              >
                <i className="ri-arrow-right-s-line text-3xl text-white"></i>
              </button>
            </>
          )}

          {/* Thumbnail Navigation */}
          {selectedProject.images.length > 1 && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 overflow-x-auto max-w-[90vw] pb-2">
              {selectedProject.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setFullscreenImageIndex(index)}
                  className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden cursor-pointer transition-all ${
                    fullscreenImageIndex === index 
                      ? 'ring-4 ring-white scale-105' 
                      : 'opacity-60 hover:opacity-100'
                  }`}
                >
                  <img
                    src={image}
                    alt={`Миниатюра ${index + 1}`}
                    className="w-full h-full object-cover object-top"
                  />
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default PortfolioPage;
