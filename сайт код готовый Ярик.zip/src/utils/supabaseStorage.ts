import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Supabase URL и Anon Key должны быть настроены в .env файле');
}

const supabase = createClient(supabaseUrl, supabaseAnonKey);

export const uploadImage = async (file: File, folder: string = 'portfolio'): Promise<string | null> => {
  try {
    console.log('🔄 Начинаем загрузку файла:', {
      fileName: file.name,
      fileSize: file.size,
      fileType: file.type,
      folder: folder,
      bucketName: 'images'
    });

    // Генерируем уникальное имя файла
    const fileExt = file.name.split('.').pop();
    const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
    const filePath = `${folder}/${fileName}`;

    console.log('📤 Загружаем файл по пути:', filePath);

    // Загружаем файл
    const { data, error } = await supabase.storage
      .from('images')
      .upload(filePath, file, {
        cacheControl: '3600',
        upsert: false
      });

    if (error) {
      console.error('❌ Ошибка загрузки файла:', {
        message: error.message,
        statusCode: error.statusCode,
        error: error
      });
      
      // Проверяем политики доступа
      if (error.message.includes('policy') || error.message.includes('permission')) {
        console.error('🔒 Проблема с политиками доступа!');
        console.log('💡 Выполните в SQL Editor:');
        console.log(`
CREATE POLICY "Allow public uploads" ON storage.objects
FOR INSERT TO public
WITH CHECK (bucket_id = 'images');

CREATE POLICY "Allow public deletes" ON storage.objects
FOR DELETE TO public
USING (bucket_id = 'images');
        `);
      }
      
      throw error;
    }

    console.log('✅ Файл успешно загружен:', data);

    // Получаем публичный URL
    const { data: urlData } = supabase.storage
      .from('images')
      .getPublicUrl(filePath);

    console.log('🔗 Публичный URL:', urlData.publicUrl);

    return urlData.publicUrl;
  } catch (error) {
    console.error('❌ Критическая ошибка при загрузке:', error);
    return null;
  }
};

export const deleteImage = async (imageUrl: string): Promise<boolean> => {
  try {
    console.log('🗑️ Удаляем изображение:', imageUrl);

    // Извлекаем путь к файлу из URL
    const urlParts = imageUrl.split('/storage/v1/object/public/images/');
    if (urlParts.length < 2) {
      console.error('❌ Неверный формат URL:', imageUrl);
      return false;
    }

    const filePath = urlParts[1];
    console.log('📍 Путь к файлу:', filePath);

    const { error } = await supabase.storage
      .from('images')
      .remove([filePath]);

    if (error) {
      console.error('❌ Ошибка удаления файла:', error);
      throw error;
    }

    console.log('✅ Файл успешно удалён');
    return true;
  } catch (error) {
    console.error('❌ Критическая ошибка при удалении:', error);
    return false;
  }
};
