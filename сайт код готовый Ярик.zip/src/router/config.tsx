import { RouteObject } from 'react-router-dom';
import HomePage from '../pages/home/page';
import OdnomodulnyeBaniPage from '../pages/odnomodulnye-bani/page';
import DvumodulnyePage from '../pages/dvumodulnye/page';
import ModulnyeDomaPage from '../pages/modulnye-doma/page';
import PortfolioPage from '../pages/portfolio/page';
import ContactsPage from '../pages/contacts/page';
import CalculatorPage from '../pages/calculator/page';
import CatalogPage from '../pages/catalog/page';
import GrillZonesPage from '../pages/grill-zones/page';
import KomplektaciyaPage from '../pages/komplektaciya/page';
import NotFoundPage from '../pages/NotFound';
import AdminPage from '../pages/admin/page';

const routes: RouteObject[] = [
  {
    path: '/',
    element: <HomePage />,
  },
  {
    path: '/catalog',
    element: <CatalogPage />,
  },
  {
    path: '/grill-zones',
    element: <GrillZonesPage />,
  },
  {
    path: '/odnomodulnye-bani',
    element: <OdnomodulnyeBaniPage />,
  },
  {
    path: '/dvumodulnye',
    element: <DvumodulnyePage />,
  },
  {
    path: '/modulnye-doma',
    element: <ModulnyeDomaPage />,
  },
  {
    path: '/komplektaciya',
    element: <KomplektaciyaPage />,
  },
  {
    path: '/portfolio',
    element: <PortfolioPage />,
  },
  {
    path: '/contacts',
    element: <ContactsPage />,
  },
  {
    path: '/calculator',
    element: <CalculatorPage />,
  },
  {
    path: '/admin',
    element: <AdminPage />,
  },
  {
    path: '*',
    element: <NotFoundPage />,
  },
];

export default routes;
